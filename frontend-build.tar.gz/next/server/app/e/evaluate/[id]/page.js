(()=>{var e={};e.id=1865,e.ids=[1865],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},55315:e=>{"use strict";e.exports=require("path")},17360:e=>{"use strict";e.exports=require("url")},22177:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>n.a,__next_app__:()=>p,originalPathname:()=>u,pages:()=>c,routeModule:()=>m,tree:()=>d}),s(11450),s(95271),s(35866);var a=s(23191),r=s(88716),i=s(37922),n=s.n(i),o=s(95231),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);s.d(t,l);let d=["",{children:["e",{children:["evaluate",{children:["[id]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,11450)),"/Users/yash/Documents/Projects/QSightsOrg2.0/frontend/app/e/evaluate/[id]/page.tsx"]}]},{}]},{}]},{metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,87421))).default(e)],apple:[async e=>(await Promise.resolve().then(s.bind(s,31228))).default(e)],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(s.bind(s,95271)),"/Users/yash/Documents/Projects/QSightsOrg2.0/frontend/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,35866,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,87421))).default(e)],apple:[async e=>(await Promise.resolve().then(s.bind(s,31228))).default(e)],openGraph:[],twitter:[],manifest:void 0}}],c=["/Users/yash/Documents/Projects/QSightsOrg2.0/frontend/app/e/evaluate/[id]/page.tsx"],u="/e/evaluate/[id]/page",p={require:s,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/e/evaluate/[id]/page",pathname:"/e/evaluate/[id]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},71479:(e,t,s)=>{Promise.resolve().then(s.bind(s,10190))},39222:(e,t,s)=>{Promise.resolve().then(s.bind(s,99413))},99598:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,12994,23)),Promise.resolve().then(s.t.bind(s,96114,23)),Promise.resolve().then(s.t.bind(s,9727,23)),Promise.resolve().then(s.t.bind(s,79671,23)),Promise.resolve().then(s.t.bind(s,41868,23)),Promise.resolve().then(s.t.bind(s,84759,23))},10190:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>ej});var a,r=s(10326),i=s(17577),n=s(35047),o=s(29492),l=s(2372),d=s(93217),c=s(56929),u=s(75901),p=s(69925),m=s(36562),h=s(59752);let x={data:""},g=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||x},f=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,y=/\/\*[^]*?\*\/|  +/g,b=/\n+/g,v=(e,t)=>{let s="",a="",r="";for(let i in e){let n=e[i];"@"==i[0]?"i"==i[1]?s=i+" "+n+";":a+="f"==i[1]?v(n,i):i+"{"+v(n,"k"==i[1]?"":t)+"}":"object"==typeof n?a+=v(n,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=n&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=v.p?v.p(i,n):i+":"+n+";")}return s+(t&&r?t+"{"+r+"}":r)+a},j={},w=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+w(e[s]);return t}return e},N=(e,t,s,a,r)=>{let i=w(e),n=j[i]||(j[i]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(i));if(!j[n]){let t=i!==e?e:(e=>{let t,s,a=[{}];for(;t=f.exec(e.replace(y,""));)t[4]?a.shift():t[3]?(s=t[3].replace(b," ").trim(),a.unshift(a[0][s]=a[0][s]||{})):a[0][t[1]]=t[2].replace(b," ").trim();return a[0]})(e);j[n]=v(r?{["@keyframes "+n]:t}:t,s?"":"."+n)}let o=s&&j.g?j.g:null;return s&&(j.g=j[n]),((e,t,s,a)=>{a?t.data=t.data.replace(a,e):-1===t.data.indexOf(e)&&(t.data=s?e+t.data:t.data+e)})(j[n],t,a,o),n},k=(e,t,s)=>e.reduce((e,a,r)=>{let i=t[r];if(i&&i.call){let e=i(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":v(e,""):!1===e?"":e}return e+a+(null==i?"":i)},"");function P(e){let t=this||{},s=e.call?e(t.p):e;return N(s.unshift?s.raw?k(s,[].slice.call(arguments,1),t.p):s.reduce((e,s)=>Object.assign(e,s&&s.call?s(t.p):s),{}):s,g(t.target),t.g,t.o,t.k)}P.bind({g:1});let S,E,_,O=P.bind({k:1});function C(e,t){let s=this||{};return function(){let a=arguments;function r(i,n){let o=Object.assign({},i),l=o.className||r.className;s.p=Object.assign({theme:E&&E()},o),s.o=/ *go\d+/.test(l),o.className=P.apply(s,a)+(l?" "+l:""),t&&(o.ref=n);let d=e;return e[0]&&(d=o.as||e,delete o.as),_&&d[0]&&_(o),S(d,o)}return t?t(r):r}}var T=e=>"function"==typeof e,A=(e,t)=>T(e)?e(t):e,$=(()=>{let e=0;return()=>(++e).toString()})(),M=(()=>{let e;return()=>e})(),Z="default",D=(e,t)=>{let{toastLimit:s}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,s)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return D(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},q=[],L={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},I={},z=(e,t=Z)=>{I[t]=D(I[t]||L,e),q.forEach(([e,s])=>{e===t&&s(I[t])})},R=e=>Object.keys(I).forEach(t=>z(e,t)),U=e=>Object.keys(I).find(t=>I[t].toasts.some(t=>t.id===e)),F=(e=Z)=>t=>{z(t,e)},H={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},G=(e={},t=Z)=>{let[s,a]=(0,i.useState)(I[t]||L),r=(0,i.useRef)(I[t]);(0,i.useEffect)(()=>(r.current!==I[t]&&a(I[t]),q.push([t,a]),()=>{let e=q.findIndex(([e])=>e===t);e>-1&&q.splice(e,1)}),[t]);let n=s.toasts.map(t=>{var s,a,r;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(s=e[t.type])?void 0:s.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||H[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...s,toasts:n}},Q=(e,t="blank",s)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||$()}),B=e=>(t,s)=>{let a=Q(t,e,s);return F(a.toasterId||U(a.id))({type:2,toast:a}),a.id},W=(e,t)=>B("blank")(e,t);W.error=B("error"),W.success=B("success"),W.loading=B("loading"),W.custom=B("custom"),W.dismiss=(e,t)=>{let s={type:3,toastId:e};t?F(t)(s):R(s)},W.dismissAll=e=>W.dismiss(void 0,e),W.remove=(e,t)=>{let s={type:4,toastId:e};t?F(t)(s):R(s)},W.removeAll=e=>W.remove(void 0,e),W.promise=(e,t,s)=>{let a=W.loading(t.loading,{...s,...null==s?void 0:s.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let r=t.success?A(t.success,e):void 0;return r?W.success(r,{id:a,...s,...null==s?void 0:s.success}):W.dismiss(a),e}).catch(e=>{let r=t.error?A(t.error,e):void 0;r?W.error(r,{id:a,...s,...null==s?void 0:s.error}):W.dismiss(a)}),e};var V=1e3,Y=(e,t="default")=>{let{toasts:s,pausedAt:a}=G(e,t),r=(0,i.useRef)(new Map).current,n=(0,i.useCallback)((e,t=V)=>{if(r.has(e))return;let s=setTimeout(()=>{r.delete(e),o({type:4,toastId:e})},t);r.set(e,s)},[]);(0,i.useEffect)(()=>{if(a)return;let e=Date.now(),r=s.map(s=>{if(s.duration===1/0)return;let a=(s.duration||0)+s.pauseDuration-(e-s.createdAt);if(a<0){s.visible&&W.dismiss(s.id);return}return setTimeout(()=>W.dismiss(s.id,t),a)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[s,a,t]);let o=(0,i.useCallback)(F(t),[t]),l=(0,i.useCallback)(()=>{o({type:5,time:Date.now()})},[o]),d=(0,i.useCallback)((e,t)=>{o({type:1,toast:{id:e,height:t}})},[o]),c=(0,i.useCallback)(()=>{a&&o({type:6,time:Date.now()})},[a,o]),u=(0,i.useCallback)((e,t)=>{let{reverseOrder:a=!1,gutter:r=8,defaultPosition:i}=t||{},n=s.filter(t=>(t.position||i)===(e.position||i)&&t.height),o=n.findIndex(t=>t.id===e.id),l=n.filter((e,t)=>t<o&&e.visible).length;return n.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+r,0)},[s]);return(0,i.useEffect)(()=>{s.forEach(e=>{if(e.dismissed)n(e.id,e.removeDelay);else{let t=r.get(e.id);t&&(clearTimeout(t),r.delete(e.id))}})},[s,n]),{toasts:s,handlers:{updateHeight:d,startPause:l,endPause:c,calculateOffset:u}}},J=O`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,X=O`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,K=O`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,ee=C("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${J} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${X} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${K} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,et=O`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,es=C("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${et} 1s linear infinite;
`,ea=O`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,er=O`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,ei=C("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${ea} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${er} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,en=C("div")`
  position: absolute;
`,eo=C("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,el=O`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ed=C("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${el} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,ec=({toast:e})=>{let{icon:t,type:s,iconTheme:a}=e;return void 0!==t?"string"==typeof t?i.createElement(ed,null,t):t:"blank"===s?null:i.createElement(eo,null,i.createElement(es,{...a}),"loading"!==s&&i.createElement(en,null,"error"===s?i.createElement(ee,{...a}):i.createElement(ei,{...a})))},eu=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,ep=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,em=C("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,eh=C("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ex=(e,t)=>{let s=e.includes("top")?1:-1,[a,r]=M()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[eu(s),ep(s)];return{animation:t?`${O(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${O(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},eg=i.memo(({toast:e,position:t,style:s,children:a})=>{let r=e.height?ex(e.position||t||"top-center",e.visible):{opacity:0},n=i.createElement(ec,{toast:e}),o=i.createElement(eh,{...e.ariaProps},A(e.message,e));return i.createElement(em,{className:e.className,style:{...r,...s,...e.style}},"function"==typeof a?a({icon:n,message:o}):i.createElement(i.Fragment,null,n,o))});a=i.createElement,v.p=void 0,S=a,E=void 0,_=void 0;var ef=({id:e,className:t,style:s,onHeightUpdate:a,children:r})=>{let n=i.useCallback(t=>{if(t){let s=()=>{a(e,t.getBoundingClientRect().height)};s(),new MutationObserver(s).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return i.createElement("div",{ref:n,className:t,style:s},r)},ey=(e,t)=>{let s=e.includes("top"),a=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:M()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(s?1:-1)}px)`,...s?{top:0}:{bottom:0},...a}},eb=P`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ev=({reverseOrder:e,position:t="top-center",toastOptions:s,gutter:a,children:r,toasterId:n,containerStyle:o,containerClassName:l})=>{let{toasts:d,handlers:c}=Y(s,n);return i.createElement("div",{"data-rht-toaster":n||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...o},className:l,onMouseEnter:c.startPause,onMouseLeave:c.endPause},d.map(s=>{let n=s.position||t,o=ey(n,c.calculateOffset(s,{reverseOrder:e,gutter:a,defaultPosition:t}));return i.createElement(ef,{id:s.id,key:s.id,onHeightUpdate:c.updateHeight,className:s.visible?eb:"",style:o},"custom"===s.type?A(s.message,s):r?r(s):i.createElement(eg,{toast:s,position:n}))}))};function ej(){let e=(0,n.useParams)(),t=(0,n.useSearchParams)();(0,n.useRouter)();let s=e.id,a=t.get("token"),[x,g]=(0,i.useState)(!0),[f,y]=(0,i.useState)(!1),[b,v]=(0,i.useState)(null),[j,w]=(0,i.useState)(null),[N,k]=(0,i.useState)({}),[P,S]=(0,i.useState)(0),[E,_]=(0,i.useState)(!1),O="https://prod.qsights.com/api".replace(/\/api\/?$/,""),C=(e,t,s)=>{k(a=>({...a,[e]:{...a[e],[t]:s}}))},T=()=>{if(!b)return 0;let e=b.subordinates.length*b.template_questions.length,t=0;return Object.values(N).forEach(e=>{t+=Object.keys(e).length}),Math.round(t/e*100)},A=async()=>{if(!b||!a)return;let e=b.subordinates.length*b.template_questions.length,t=0;if(Object.values(N).forEach(e=>{t+=Object.keys(e).length}),t<e){W.error("Please answer all questions before submitting");return}try{y(!0);let e=await fetch(`${O}/api/evaluation/triggered/${s}/submit?token=${a}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({responses:N})}),t=await e.json();t.success?(W.success("Evaluation submitted successfully!"),_(!0)):W.error(t.message||"Failed to submit evaluation")}catch(e){W.error("Failed to submit evaluation. Please try again.")}finally{y(!1)}},$=b?.subordinates[P],M=b?.template_questions||[];return x?r.jsx("div",{className:"min-h-screen bg-gray-50 flex items-center justify-center",children:(0,r.jsxs)("div",{className:"text-center",children:[r.jsx(o.Z,{className:"h-12 w-12 animate-spin text-purple-600 mx-auto"}),r.jsx("p",{className:"mt-4 text-gray-600",children:"Loading evaluation..."})]})}):j?r.jsx("div",{className:"min-h-screen bg-gray-50 flex items-center justify-center p-4",children:(0,r.jsxs)("div",{className:"bg-white rounded-xl shadow-lg p-8 max-w-md text-center",children:[r.jsx(l.Z,{className:"h-16 w-16 text-red-500 mx-auto mb-4"}),r.jsx("h1",{className:"text-2xl font-bold text-gray-900 mb-2",children:"Error"}),r.jsx("p",{className:"text-gray-600",children:j})]})}):E?r.jsx("div",{className:"min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4",children:(0,r.jsxs)("div",{className:"bg-white rounded-xl shadow-lg p-8 max-w-md text-center",children:[r.jsx("div",{className:"w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6",children:r.jsx(d.Z,{className:"h-12 w-12 text-green-600"})}),r.jsx("h1",{className:"text-2xl font-bold text-gray-900 mb-2",children:"Evaluation Complete!"}),r.jsx("p",{className:"text-gray-600 mb-6",children:"Thank you for completing the evaluation. Your feedback has been recorded."}),r.jsx("p",{className:"text-sm text-gray-500",children:"You may close this window."})]})}):(0,r.jsxs)("div",{className:"min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100",children:[r.jsx(ev,{position:"top-center"}),r.jsx("div",{className:"bg-white shadow-sm border-b",children:(0,r.jsxs)("div",{className:"max-w-4xl mx-auto px-4 py-6",children:[r.jsx("h1",{className:"text-2xl font-bold text-gray-900",children:b?.template_name}),(0,r.jsxs)("p",{className:"text-gray-600 mt-1",children:["Welcome, ",r.jsx("span",{className:"font-medium",children:b?.evaluator_name})]}),(0,r.jsxs)("div",{className:"mt-4",children:[(0,r.jsxs)("div",{className:"flex justify-between text-sm text-gray-600 mb-1",children:[r.jsx("span",{children:"Progress"}),(0,r.jsxs)("span",{children:[T(),"%"]})]}),r.jsx("div",{className:"h-2 bg-gray-200 rounded-full overflow-hidden",children:r.jsx("div",{className:"h-full bg-gradient-to-r from-purple-500 to-indigo-500 transition-all duration-300",style:{width:`${T()}%`}})})]})]})}),r.jsx("div",{className:"bg-white border-b",children:r.jsx("div",{className:"max-w-4xl mx-auto px-4",children:r.jsx("div",{className:"flex gap-2 overflow-x-auto py-3",children:b?.subordinates.map((e,t)=>{let s=Object.keys(N[e.id]||{}).length===M.length;return r.jsxs("button",{onClick:()=>S(t),className:`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition ${P===t?"bg-purple-100 text-purple-700 font-medium":"bg-gray-100 text-gray-600 hover:bg-gray-200"}`,children:[r.jsx(c.Z,{className:"h-4 w-4"}),r.jsx("span",{children:e.name}),s&&r.jsx(d.Z,{className:"h-4 w-4 text-green-500"})]},e.id)})})})}),(0,r.jsxs)("div",{className:"max-w-4xl mx-auto px-4 py-8",children:[$&&(0,r.jsxs)("div",{className:"bg-white rounded-xl shadow-lg p-6 mb-6",children:[(0,r.jsxs)("div",{className:"flex items-center gap-3 mb-6 pb-4 border-b",children:[r.jsx("div",{className:"w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center",children:r.jsx(c.Z,{className:"h-6 w-6 text-purple-600"})}),(0,r.jsxs)("div",{children:[r.jsx("h2",{className:"text-xl font-semibold text-gray-900",children:$.name}),r.jsx("p",{className:"text-sm text-gray-500",children:$.email})]})]}),r.jsx("div",{className:"space-y-8",children:M.map((e,t)=>(0,r.jsxs)("div",{className:"border-b pb-6 last:border-b-0",children:[(0,r.jsxs)("label",{className:"block text-lg font-medium text-gray-900 mb-2",children:[t+1,". ",e.question]}),e.description&&r.jsx("p",{className:"text-sm text-gray-500 mb-4",children:e.description}),"rating"===e.type&&(0,r.jsxs)("div",{className:"flex gap-2 mt-3",children:[[1,2,3,4,5].map(e=>{let s=N[$.id]?.[t]||0;return r.jsx("button",{onClick:()=>C($.id,t,e),className:`p-2 rounded-lg transition ${s>=e?"bg-yellow-100 text-yellow-500":"bg-gray-100 text-gray-300 hover:bg-gray-200"}`,children:r.jsx(u.Z,{className:`h-8 w-8 ${s>=e?"fill-current":""}`})},e)}),r.jsx("span",{className:"ml-4 self-center text-gray-500",children:N[$.id]?.[t]?`${N[$.id][t]} / 5`:"Select rating"})]}),"mcq"===e.type&&e.options&&r.jsx("div",{className:"space-y-2 mt-3",children:e.options.map((e,s)=>(0,r.jsxs)("label",{className:`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition ${N[$.id]?.[t]===e?"border-purple-500 bg-purple-50":"border-gray-200 hover:border-gray-300"}`,children:[r.jsx("input",{type:"radio",name:`q-${$.id}-${t}`,checked:N[$.id]?.[t]===e,onChange:()=>C($.id,t,e),className:"w-4 h-4 text-purple-600"}),r.jsx("span",{className:"text-gray-700",children:e})]},s))}),"text"===e.type&&r.jsx("textarea",{value:N[$.id]?.[t]||"",onChange:e=>C($.id,t,e.target.value),className:"w-full mt-3 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 resize-none",rows:3,placeholder:"Enter your feedback..."})]},t))})]}),(0,r.jsxs)("div",{className:"flex items-center justify-between",children:[(0,r.jsxs)("button",{onClick:()=>S(Math.max(0,P-1)),disabled:0===P,className:"flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 disabled:opacity-50 disabled:cursor-not-allowed",children:[r.jsx(p.Z,{className:"h-5 w-5"}),"Previous"]}),(0,r.jsxs)("span",{className:"text-gray-500",children:[P+1," of ",b?.subordinates.length]}),P<(b?.subordinates.length||0)-1?(0,r.jsxs)("button",{onClick:()=>S(P+1),className:"flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700",children:["Next",r.jsx(m.Z,{className:"h-5 w-5"})]}):r.jsx("button",{onClick:A,disabled:f||100>T(),className:"flex items-center gap-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed",children:f?(0,r.jsxs)(r.Fragment,{children:[r.jsx(o.Z,{className:"h-5 w-5 animate-spin"}),"Submitting..."]}):(0,r.jsxs)(r.Fragment,{children:[r.jsx(h.Z,{className:"h-5 w-5"}),"Submit Evaluation"]})})]})]})]})}},99413:(e,t,s)=>{"use strict";s.d(t,{default:()=>o});var a=s(10326),r=s(33136),i=s(53812);function n(){let{toasts:e}=(0,i.pm)();return a.jsx("div",{className:"fixed top-0 right-0 z-[10000] flex max-h-screen w-full flex-col-reverse p-4 sm:top-auto sm:right-0 sm:bottom-0 sm:flex-col md:max-w-[420px]",children:e.map(e=>{let t={default:null,success:a.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M5 13l4 4L19 7"})}),error:a.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})}),warning:a.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"})})};return(0,a.jsxs)("div",{className:`group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-lg border p-4 pr-8 shadow-lg transition-all ${{default:"bg-white border-gray-200",success:"bg-green-50 border-green-200",error:"bg-red-50 border-red-200",warning:"bg-yellow-50 border-yellow-200"}[e.variant||"default"]} animate-in slide-in-from-top-full sm:slide-in-from-bottom-full`,children:[(0,a.jsxs)("div",{className:"flex items-start space-x-3",children:[t[e.variant||"default"]&&a.jsx("div",{className:{default:"text-gray-600",success:"text-green-600",error:"text-red-600",warning:"text-yellow-600"}[e.variant||"default"],children:t[e.variant||"default"]}),(0,a.jsxs)("div",{className:"grid gap-1",children:[e.title&&a.jsx("div",{className:"text-sm font-semibold text-gray-900",children:e.title}),e.description&&a.jsx("div",{className:"text-sm text-gray-600",children:e.description})]})]}),e.action,a.jsx("button",{onClick:()=>e.onOpenChange?.(!1),className:"absolute right-2 top-2 rounded-md p-1 text-gray-400 opacity-0 transition-opacity hover:text-gray-600 focus:opacity-100 focus:outline-none group-hover:opacity-100",children:a.jsx("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:a.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]},e.id)})})}function o({children:e}){return(0,a.jsxs)(r.H,{children:[e,a.jsx(n,{})]})}},53812:(e,t,s)=>{"use strict";s.d(t,{Am:()=>c,pm:()=>u});var a=s(17577);let r=new Map,i=(e,t)=>{if(r.has(e))return;let s=setTimeout(()=>{r.delete(e),d({type:"REMOVE_TOAST",toastId:e})},t||3e3);r.set(e,s)},n=(e,t)=>{switch(t.type){case"ADD_TOAST":return{...e,toasts:[t.toast,...e.toasts].slice(0,3)};case"UPDATE_TOAST":return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case"DISMISS_TOAST":{let{toastId:s}=t;return s?i(s):e.toasts.forEach(e=>{i(e.id)}),{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,onOpenChange:!1}:e)}}case"REMOVE_TOAST":if(void 0===t.toastId)return{...e,toasts:[]};return{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)}}},o=[],l={toasts:[]};function d(e){l=n(l,e),o.forEach(e=>{e(l)})}function c({duration:e,...t}){let s=Math.random().toString(36).substr(2,9),a=()=>d({type:"DISMISS_TOAST",toastId:s});return d({type:"ADD_TOAST",toast:{...t,id:s,onOpenChange:e=>{e||a()}}}),i(s,e),{id:s,dismiss:a,update:e=>d({type:"UPDATE_TOAST",toast:{...e,id:s}})}}function u(){let[e,t]=a.useState(l);return a.useEffect(()=>(o.push(t),()=>{let e=o.indexOf(t);e>-1&&o.splice(e,1)}),[e]),{...e,toast:c,dismiss:e=>d({type:"DISMISS_TOAST",toastId:e})}}},33136:(e,t,s)=>{"use strict";s.d(t,{H:()=>n,a:()=>o});var a=s(10326),r=s(17577);let i=(0,r.createContext)(void 0);function n({children:e}){let[t,s]=(0,r.useState)(null),[n,o]=(0,r.useState)(!0),l=async()=>{try{let e=await fetch("/api/auth/me",{credentials:"include"});if(e.ok){let t=await e.json();s(t.user)}else s(null)}catch(e){s(null)}finally{o(!1)}},d=async()=>{o(!0),await l()};return a.jsx(i.Provider,{value:{currentUser:t,isLoading:n,refreshUser:d,clearUser:()=>{s(null)}},children:e})}function o(){let e=(0,r.useContext)(i);if(void 0===e)throw Error("useAuth must be used within an AuthProvider");return e}},35047:(e,t,s)=>{"use strict";var a=s(77389);s.o(a,"useParams")&&s.d(t,{useParams:function(){return a.useParams}}),s.o(a,"usePathname")&&s.d(t,{usePathname:function(){return a.usePathname}}),s.o(a,"useRouter")&&s.d(t,{useRouter:function(){return a.useRouter}}),s.o(a,"useSearchParams")&&s.d(t,{useSearchParams:function(){return a.useSearchParams}})},11450:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>a});let a=(0,s(68570).createProxy)(String.raw`/Users/yash/Documents/Projects/QSightsOrg2.0/frontend/app/e/evaluate/[id]/page.tsx#default`)},95271:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>l,metadata:()=>o});var a=s(19510),r=s(24414),i=s.n(r);s(67272);let n=(0,s(68570).createProxy)(String.raw`/Users/yash/Documents/Projects/QSightsOrg2.0/frontend/components/client-providers.tsx#default`),o={title:"QSights - Survey & Analytics Platform",description:"Professional survey and analytics platform"};function l({children:e}){return a.jsx("html",{lang:"en",children:a.jsx("body",{className:i().className,children:a.jsx(n,{children:e})})})}},31228:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>i}),s(19510);var a=s(66621);let r={runtime:"edge",size:{width:180,height:180},contentType:"image/png"};async function i(e){let{__metadata_id__:t,...s}=e.params,i=(0,a.fillMetadataSegment)(".",s,"apple-icon"),{generateImageMetadata:n}=r;function o(e,t){let s={alt:e.alt,type:e.contentType||"image/png",url:i+(t?"/"+t:"")+"?77e00b50769c8269"},{size:a}=e;return a&&(s.sizes=a.width+"x"+a.height),s}return n?(await n({params:s})).map((e,t)=>{let s=(e.id||t)+"";return o(e,s)}):[o(r,"")]}},87421:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>i}),s(19510);var a=s(66621);let r={runtime:"edge",size:{width:32,height:32},contentType:"image/png"};async function i(e){let{__metadata_id__:t,...s}=e.params,i=(0,a.fillMetadataSegment)(".",s,"icon"),{generateImageMetadata:n}=r;function o(e,t){let s={alt:e.alt,type:e.contentType||"image/png",url:i+(t?"/"+t:"")+"?7dfe1e3b4ba0e314"},{size:a}=e;return a&&(s.sizes=a.width+"x"+a.height),s}return n?(await n({params:s})).map((e,t)=>{let s=(e.id||t)+"";return o(e,s)}):[o(r,"")]}},67272:()=>{},2372:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(87926).Z)("AlertCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]])},93217:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(87926).Z)("CheckCircle",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["polyline",{points:"22 4 12 14.01 9 11.01",key:"6xbx8j"}]])},69925:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(87926).Z)("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},36562:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(87926).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},29492:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(87926).Z)("Loader2",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},59752:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(87926).Z)("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]])},75901:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(87926).Z)("Star",[["polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2",key:"8f66p6"}]])},56929:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(87926).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[9276,6668,235],()=>s(22177));module.exports=a})();