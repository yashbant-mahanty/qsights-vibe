<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class EvaluationTriggerController extends Controller
{
    /**
     * Trigger evaluations for selected evaluators
     */
    public function trigger(Request $request)
    {
        try {
            $user = $request->user();
            
            $validated = $request->validate([
                'template_id' => 'required|string',
                'template_name' => 'required|string|max:255',
                'template_questions' => 'required|array',
                'evaluator_ids' => 'required|array|min:1',
                'evaluator_ids.*' => 'uuid|exists:evaluation_staff,id',
                'program_id' => 'required|uuid',
                'email_subject' => 'nullable|string',
                'email_body' => 'nullable|string',
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date',
                'scheduled_trigger_at' => 'nullable|date',
            ]);
            
            $triggeredCount = 0;
            $emailsSent = 0;
            
            foreach ($validated['evaluator_ids'] as $evaluatorId) {
                // Check for duplicate active evaluation
                $existingActive = DB::table('evaluation_triggered')
                    ->where('evaluator_id', $evaluatorId)
                    ->where('template_id', $validated['template_id'])
                    ->where('program_id', $validated['program_id'])
                    ->where('is_active', true)
                    ->where(function($query) use ($validated) {
                        // Check if end_date hasn't passed
                        if (isset($validated['end_date'])) {
                            $query->where('end_date', '>=', now())
                                  ->orWhereNull('end_date');
                        }
                    })
                    ->whereNull('deleted_at')
                    ->exists();
                
                if ($existingActive) {
                    $evaluator = DB::table('evaluation_staff')->where('id', $evaluatorId)->first();
                    $skippedCount++;
                    $skippedEvaluators[] = $evaluator->name ?? 'Unknown';
                    \Log::info("Skipping evaluator {$evaluatorId} - active evaluation already exists");
                    continue; // Skip this evaluator
                }
                
                // Get evaluator details
                $evaluator = DB::table('evaluation_staff')
                    ->where('id', $evaluatorId)
                    ->whereNull('deleted_at')
                    ->first();
                    
                if (!$evaluator) {
                    continue;
                }
                
                // Get subordinates for this evaluator
                $subordinates = DB::table('evaluation_hierarchy as eh')
                    ->join('evaluation_staff as es', 'eh.staff_id', '=', 'es.id')
                    ->where('eh.reports_to_id', $evaluatorId)
                    ->where('eh.is_active', true)
                    ->whereNull('eh.deleted_at')
                    ->whereNull('es.deleted_at')
                    ->select('es.id', 'es.name', 'es.email', 'es.employee_id')
                    ->get();
                
                if ($subordinates->isEmpty()) {
                    continue;
                }
                
                // Create triggered evaluation record
                $triggeredId = Str::uuid()->toString();
                $accessToken = Str::random(64);
                
                DB::table('evaluation_triggered')->insert([
                    'id' => $triggeredId,
                    'program_id' => $validated['program_id'],
                    'template_id' => $validated['template_id'],
                    'template_name' => $validated['template_name'],
                    'template_questions' => json_encode($validated['template_questions']),
                    'evaluator_id' => $evaluatorId,
                    'evaluator_name' => $evaluator->name,
                    'evaluator_email' => $evaluator->email,
                    'subordinates' => json_encode($subordinates->toArray()),
                    'subordinates_count' => $subordinates->count(),
                    'access_token' => $accessToken,
                    'status' => 'pending',
                    'start_date' => $validated['start_date'] ?? null,
                    'end_date' => $validated['end_date'] ?? null,
                    'scheduled_trigger_at' => $validated['scheduled_trigger_at'] ?? null,
                    'email_subject' => $validated['email_subject'] ?? null,
                    'email_body' => $validated['email_body'] ?? null,
                    'is_active' => true,
                    'triggered_by' => $user->id,
                    'triggered_at' => now(),
                    'created_at' => now(),
                    'updated_at' => now()
                ]);
                
                $triggeredCount++;
                
                // Send email to evaluator
                try {
                    $evaluationUrl = config('app.frontend_url', 'https://prod.qsights.com') . 
                        '/e/evaluate/' . $triggeredId . '?token=' . $accessToken;
                    
                    // Prepare email subject and body with placeholders
                    $emailSubject = $validated['email_subject'] ?? ('Evaluation Request: ' . $validated['template_name']);
                    $emailBody = $validated['email_body'] ?? "Hello {evaluator_name},\n\nYou have been requested to complete evaluations for your team members.";
                    
                    // Replace placeholders
                    $subordinatesList = $subordinates->map(fn($s) => $s->name)->implode("\n- ");
                    $emailBody = str_replace([
                        '{evaluator_name}',
                        '{start_date}',
                        '{end_date}',
                        '{subordinates_list}'
                    ], [
                        $evaluator->name,
                        $validated['start_date'] ?? 'Not specified',
                        $validated['end_date'] ?? 'Not specified',
                        $subordinatesList
                    ], $emailBody);
                    
                    // Send via SendGrid API
                    $sendGridApiKey = config('services.sendgrid.api_key', env('SENDGRID_API_KEY'));
                    $from = config('mail.from.address', 'info@qsights.com');
                    $fromName = config('mail.from.name', 'QSights');
                    
                    $htmlBody = nl2br(e($emailBody)) . 
                        '<br><br><div style="text-align: center; margin: 30px 0;"><a href="' . $evaluationUrl . '" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">Start Evaluation →</a></div>';
                    
                    $response = Http::withHeaders([
                        'Authorization' => 'Bearer ' . $sendGridApiKey,
                        'Content-Type' => 'application/json'
                    ])->post('https://api.sendgrid.com/v3/mail/send', [
                        'personalizations' => [[
                            'to' => [['email' => $evaluator->email, 'name' => $evaluator->name]],
                            'subject' => $emailSubject
                        ]],
                        'from' => ['email' => $from, 'name' => $fromName],
                        'content' => [['type' => 'text/html', 'value' => $htmlBody]]
                    ]);
                    
                    if ($response->successful()) {
                        $emailsSent++;
                        
                        // Update email sent status
                        DB::table('evaluation_triggered')
                            ->where('id', $triggeredId)
                            ->update(['email_sent_at' => now()]);
                    }
                        
                } catch (\Exception $emailError) {
                    \Log::error('Failed to send evaluation email: ' . $emailError->getMessage());
                }
            }
            
            // Log audit
            $this->logAudit(
                'evaluation_trigger', 
                null, 
                'triggered', 
                "Triggered {$triggeredCount} evaluation(s), sent {$emailsSent} email(s)", 
                $user, 
                $validated['program_id']
            );
            
            return response()->json([
                'success' => true,
                'message' => "Evaluation triggered successfully. {$emailsSent} email(s) sent.",
                'triggered_count' => $triggeredCount,
                'emails_sent' => $emailsSent
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to trigger evaluation: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Get triggered evaluations list
     */
    public function index(Request $request)
    {
        try {
            $user = $request->user();
            $programId = $request->query('program_id', $user->program_id ?? null);
            
            $query = DB::table('evaluation_triggered')
                ->orderBy('triggered_at', 'desc');
                
            if ($programId) {
                $query->where('program_id', $programId);
            }
                
            $evaluations = $query->select(
                    'id', 
                    'template_name', 
                    'evaluator_name', 
                    'subordinates_count', 
                    'status', 
                    'triggered_at', 
                    'completed_at',
                    'email_sent_at',
                    'start_date',
                    'end_date',
                    'is_active',
                    'email_subject',
                    'email_body'
                )
                ->get();
            
            return response()->json([
                'success' => true,
                'evaluations' => $evaluations
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch triggered evaluations: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Get a single triggered evaluation (for taking)
     */
    public function show(Request $request, $id)
    {
        try {
            $token = $request->query('token');
            
            $evaluation = DB::table('evaluation_triggered')
                ->where('id', $id)
                ->first();
            
            if (!$evaluation) {
                return response()->json([
                    'success' => false,
                    'message' => 'Evaluation not found'
                ], 404);
            }
            
            // Verify access token
            if ($evaluation->access_token !== $token) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid access token'
                ], 403);
            }
            
            // Parse JSON fields
            $evaluation->template_questions = json_decode($evaluation->template_questions);
            $evaluation->subordinates = json_decode($evaluation->subordinates);
            
            return response()->json([
                'success' => true,
                'evaluation' => $evaluation
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch evaluation: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Submit evaluation responses
     */
    public function submit(Request $request, $id)
    {
        try {
            $token = $request->query('token');
            
            $evaluation = DB::table('evaluation_triggered')
                ->where('id', $id)
                ->first();
            
            if (!$evaluation) {
                return response()->json([
                    'success' => false,
                    'message' => 'Evaluation not found'
                ], 404);
            }
            
            // Verify access token
            if ($evaluation->access_token !== $token) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid access token'
                ], 403);
            }
            
            if ($evaluation->status === 'completed') {
                return response()->json([
                    'success' => false,
                    'message' => 'Evaluation already completed'
                ], 422);
            }
            
            $validated = $request->validate([
                'responses' => 'required|array'
            ]);
            
            // Store responses
            DB::table('evaluation_triggered')
                ->where('id', $id)
                ->update([
                    'responses' => json_encode($validated['responses']),
                    'status' => 'completed',
                    'completed_at' => now(),
                    'updated_at' => now()
                ]);
            
            return response()->json([
                'success' => true,
                'message' => 'Evaluation submitted successfully'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to submit evaluation: ' . $e->getMessage()
            ], 500);
        }
    }
    
    private function logAudit($entityType, $entityId, $action, $description, $user, $programId, $oldValues = null, $newValues = null)
    {
        try {
            DB::table('evaluation_audit_log')->insert([
                'id' => Str::uuid()->toString(),
                'entity_type' => $entityType,
                'entity_id' => $entityId,
                'action' => $action,
                'action_description' => $description,
                'user_id' => $user->id,
                'user_name' => $user->name,
                'user_email' => $user->email,
                'old_values' => $oldValues ? json_encode($oldValues) : null,
                'new_values' => $newValues ? json_encode($newValues) : null,
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
                'performed_at' => now(),
                'created_at' => now(),
                'updated_at' => now()
            ]);
        } catch (\Exception $e) {
            \Log::error('Failed to log audit: ' . $e->getMessage());
        }
    }

    /**
     * Update triggered evaluation
     */
    public function update(Request $request, $id)
    {
        try {
            $user = $request->user();
            
            $validated = $request->validate([
                'email_subject' => 'nullable|string|max:500',
                'email_body' => 'nullable|string',
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date'
            ]);
            
            $triggered = DB::table('evaluation_triggered')->where('id', $id)->first();
            
            if (!$triggered) {
                return response()->json(['success' => false, 'message' => 'Evaluation not found'], 404);
            }
            
            DB::table('evaluation_triggered')
                ->where('id', $id)
                ->update([
                    'start_date' => $validated['start_date'] ?? $triggered->start_date,
                    'end_date' => $validated['end_date'] ?? $triggered->end_date,
                    'updated_at' => now()
                ]);
            
            $this->logAudit('evaluation_triggered', $id, 'updated', 
                'Updated triggered evaluation details', 
                $user, 
                $triggered->program_id,
                ['start_date' => $triggered->start_date, 'end_date' => $triggered->end_date],
                $validated
            );
            
            return response()->json(['success' => true, 'message' => 'Evaluation updated successfully']);
            
        } catch (\Exception $e) {
            \Log::error('Failed to update triggered evaluation: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to update evaluation',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete triggered evaluation (cascade)
     */
    public function destroy(Request $request, $id)
    {
        try {
            $user = $request->user();
            
            $triggered = DB::table('evaluation_triggered')->where('id', $id)->first();
            
            if (!$triggered) {
                return response()->json(['success' => false, 'message' => 'Evaluation not found'], 404);
            }
            
            // Delete related responses first
            DB::table('evaluation_responses')->where('triggered_id', $id)->delete();
            
            // Delete the triggered evaluation
            DB::table('evaluation_triggered')->where('id', $id)->delete();
            
            $this->logAudit('evaluation_triggered', $id, 'deleted', 
                'Deleted triggered evaluation and related responses', 
                $user, 
                $triggered->program_id
            );
            
            return response()->json(['success' => true, 'message' => 'Evaluation deleted successfully']);
            
        } catch (\Exception $e) {
            \Log::error('Failed to delete triggered evaluation: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete evaluation',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Toggle active status
     */
    public function toggleActive(Request $request, $id)
    {
        try {
            $user = $request->user();
            
            $validated = $request->validate([
                'is_active' => 'required|boolean'
            ]);
            
            $triggered = DB::table('evaluation_triggered')->where('id', $id)->first();
            
            if (!$triggered) {
                return response()->json(['success' => false, 'message' => 'Evaluation not found'], 404);
            }
            
            DB::table('evaluation_triggered')
                ->where('id', $id)
                ->update([
                    'is_active' => $validated['is_active'],
                    'updated_at' => now()
                ]);
            
            $this->logAudit('evaluation_triggered', $id, 'status_changed', 
                'Changed active status to ' . ($validated['is_active'] ? 'active' : 'inactive'), 
                $user, 
                $triggered->program_id
            );
            
            return response()->json(['success' => true, 'message' => 'Status updated successfully']);
            
        } catch (\Exception $e) {
            \Log::error('Failed to toggle active status: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to update status',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Resend evaluation email
     */
    public function resend(Request $request, $id)
    {
        try {
            $user = $request->user();
            
            $triggered = DB::table('evaluation_triggered')->where('id', $id)->first();
            
            if (!$triggered) {
                return response()->json(['success' => false, 'message' => 'Evaluation not found'], 404);
            }
            
            // Generate new access token
            $newToken = Str::random(64);
            
            DB::table('evaluation_triggered')
                ->where('id', $id)
                ->update([
                    'access_token' => $newToken,
                    'email_sent_at' => now(),
                    'updated_at' => now()
                ]);
            
            // Send email
            $evaluationUrl = config('app.frontend_url', 'https://prod.qsights.com') . 
                '/e/evaluate/' . $id . '?token=' . $newToken;
            
            $emailSubject = 'Evaluation Reminder: ' . $triggered->template_name;
            $emailBody = "Hello {$triggered->evaluator_name},\n\nThis is a reminder to complete your pending evaluations.";
            
            $sendGridApiKey = config('services.sendgrid.api_key', env('SENDGRID_API_KEY'));
            $from = config('mail.from.address', 'info@qsights.com');
            $fromName = config('mail.from.name', 'QSights');
            
            $htmlBody = nl2br(e($emailBody)) . 
                '<br><br><div style="text-align: center; margin: 30px 0;"><a href="' . $evaluationUrl . '" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 14px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">Start Evaluation →</a></div>';
            
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $sendGridApiKey,
                'Content-Type' => 'application/json'
            ])->post('https://api.sendgrid.com/v3/mail/send', [
                'personalizations' => [[
                    'to' => [['email' => $triggered->evaluator_email, 'name' => $triggered->evaluator_name]],
                    'subject' => $emailSubject
                ]],
                'from' => ['email' => $from, 'name' => $fromName],
                'content' => [['type' => 'text/html', 'value' => $htmlBody]]
            ]);
            
            if ($response->successful()) {
                $this->logAudit('evaluation_triggered', $id, 'email_resent', 
                    'Resent evaluation email', 
                    $user, 
                    $triggered->program_id
                );
                
                return response()->json(['success' => true, 'message' => 'Email resent successfully']);
            } else {
                return response()->json(['success' => false, 'message' => 'Failed to send email'], 500);
            }
            
        } catch (\Exception $e) {
            \Log::error('Failed to resend email: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to resend email',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
