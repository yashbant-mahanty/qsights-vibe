import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'https://prod.qsights.com';

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('backendToken')?.value;
    
    const body = await request.json();
    
    const response = await fetch(`${BACKEND_URL}/api/activities/participant-counts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();
    
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    console.error('Error fetching participant counts:', error);
    return NextResponse.json(
      { error: 'Failed to fetch participant counts' },
      { status: 500 }
    );
  }
}
