<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Participant;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;

class ActivityController extends Controller
{
    /**
     * Display a listing of activities with filtering
     */
    public function index(Request $request)
    {
        // Auto-filter by program_id for program-scoped roles
        $user = $request->user();
        if ($user && in_array($user->role, ['program-admin', 'program-manager', 'program-moderator', 'evaluation-admin']) && $user->program_id) {
            // Force filter to user's program for these roles
            $request->merge(['program_id' => $user->program_id]);
        }
        
        $query = Activity::with(['program', 'questionnaire.sections.questions']);
        
        // Only exclude soft-deleted activities
        if (!$request->boolean('with_trashed')) {
            $query->whereNull('deleted_at');
        }
        
        $query->withCount([
            // Base participants count (all valid participants in this activity)
            'participants' => function ($query) {
                $query->where('participants.status', 'active')
                      ->whereNull('participants.deleted_at');
            },
            // Total response counts - from any valid participant
            'responses' => function ($query) {
                $query->whereNotNull('participant_id')
                      ->whereHas('participant', function($q) {
                          $q->where('status', 'active')
                            ->whereNull('deleted_at');
                      });
            },
            // Authenticated responses - from registered participants (is_guest=false)
            'responses as authenticated_responses_count' => function ($query) {
                $query->whereHas('participant', function($q) {
                    $q->where('is_guest', false)
                      ->where('status', 'active')
                      ->whereNull('deleted_at');
                });
            },
            // Guest/Anonymous responses - from participants marked as guest OR anonymous
            'responses as guest_responses_count' => function ($query) {
                $query->whereHas('participant', function($q) {
                    $q->where('status', 'active')
                      ->whereNull('deleted_at')
                      ->where(function($guestQ) {
                          // Either is_guest=true OR has participant_type=anonymous in additional_data
                          $guestQ->where('is_guest', true)
                                 ->orWhereRaw("additional_data IS NOT NULL AND additional_data->>'participant_type' = 'anonymous'");
                      });
                });
            },
            // Active participants (registered users, not guest)
            'participants as active_participants_count' => function ($query) {
                $query->where('participants.is_guest', false)
                      ->where('participants.status', 'active')
                      ->whereNull('participants.deleted_at');
            },
            // Anonymous participants (from anonymous link)
            'participants as anonymous_participants_count' => function ($query) {
                $query->where('participants.status', 'active')
                      ->whereNull('participants.deleted_at')
                      ->where(function($anonQ) {
                          // Either is_guest=true OR has participant_type=anonymous
                          $anonQ->where('participants.is_guest', true)
                                ->orWhereRaw("participants.additional_data IS NOT NULL AND participants.additional_data->>'participant_type' = 'anonymous'");
                      });
            },
            // Keep legacy counts for compatibility
            'participants as inactive_participants_count' => function ($query) {
                $query->where('participants.is_guest', false)
                      ->where('participants.status', 'inactive')
                      ->whereNull('participants.deleted_at');
            },
            'participants as guest_participants_count' => function ($query) {
                $query->where('participants.is_guest', true)
                      ->where('participants.status', 'active')
                      ->whereNull('participants.deleted_at');
            },
            // Authenticated participants count (non-guest, active)
            'participants as authenticated_participants_count' => function ($query) {
                $query->where('participants.is_guest', false)
                      ->where('participants.status', 'active')
                      ->whereNull('participants.deleted_at');
            },
            // Participants responded count - ONLY valid participants (registered OR anonymous with proper type)
            'responses as participants_responded_count' => function ($query) {
                $query->whereHas('participant', function($q) {
                    $q->where('status', 'active')
                      ->whereNull('deleted_at')
                      ->where(function($subQ) {
                          // Registered participants (not anonymous)
                          $subQ->where(function($registered) {
                              $registered->where('is_guest', false)
                                         ->where(function($notAnon) {
                                             $notAnon->whereNull('additional_data')
                                                     ->orWhereRaw("(additional_data IS NOT NULL AND (additional_data->>'participant_type' IS NULL OR additional_data->>'participant_type' != 'anonymous'))");
                                         });
                          })
                          // OR Anonymous participants (with proper type marking)
                          ->orWhereRaw("additional_data IS NOT NULL AND additional_data->>'participant_type' = 'anonymous'");
                      });
                })
                ->selectRaw('COUNT(DISTINCT participant_id)');
            },
        ]);

        // Filter by program
        if ($request->has('program_id')) {
            $query->byProgram($request->program_id);
        }

        // Filter by type
        if ($request->has('type')) {
            $query->byType($request->type);
        }

        // Filter by status (draft, upcoming, live, expired, closed, archived)
        if ($request->has('status')) {
            $status = $request->status;
            switch ($status) {
                case 'upcoming':
                    $query->upcoming();
                    break;
                case 'live':
                    $query->live();
                    break;
                case 'expired':
                    $query->expired();
                    break;
                case 'closed':
                    $query->closed();
                    break;
                case 'draft':
                    $query->draft();
                    break;
                case 'archived':
                    $query->archived();
                    break;
            }
        }

        // Filter by guest access
        if ($request->has('allow_guests')) {
            if ($request->boolean('allow_guests')) {
                $query->withGuests();
            } else {
                $query->where('allow_guests', false);
            }
        }

        // Filter by multilingual
        if ($request->has('is_multilingual')) {
            if ($request->boolean('is_multilingual')) {
                $query->multilingual();
            } else {
                $query->where('is_multilingual', false);
            }
        }

        // Search
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'ilike', "%{$search}%")
                  ->orWhere('description', 'ilike', "%{$search}%");
            });
        }

        // Include trashed
        if ($request->boolean('with_trashed')) {
            $query->withTrashed();
        }

        $activities = $query->paginate($request->input('per_page', 15));

        // Add computed status to each activity
        $transformedCollection = $activities->getCollection()->map(function ($activity) {
            $activity->computed_status = $activity->getComputedStatus();
            // Add participants count from program
            // participants_count already calculated by withCount as authenticated + guest
            
            // Add program name for display
            $activity->program_name = $activity->program ? $activity->program->name : null;
            
            // FORCE these fields to be included in JSON response by explicitly setting them
            // (makeVisible doesn't work for fields not in $hidden)
            $activity->enable_generated_links = (bool) $activity->enable_generated_links;
            $activity->allow_participant_reminders = (bool) $activity->allow_participant_reminders;
            
            // Make additional details fields visible
            $activity->makeVisible([
                'sender_email',
                'manager_name',
                'manager_email',
                'project_code',
                'configuration_date',
                'configuration_price',
                'subscription_price',
                'subscription_frequency',
                'tax_percentage',
                'number_of_participants',
                'questions_to_randomize',
                'enable_generated_links',
                'allow_participant_reminders',
            ]);
            
            return $activity;
        });
        
        $activities->setCollection($transformedCollection);

        return response()->json($activities);
    }

    /**
     * Store a newly created activity
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'program_id' => 'required|uuid|exists:programs,id',
            'questionnaire_id' => 'nullable|integer|exists:questionnaires,id',
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'type' => 'required|in:survey,poll,assessment',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'close_date' => 'nullable|date|after_or_equal:end_date',
            'status' => 'nullable|in:draft,upcoming,live,expired,closed,archived',
            'allow_guests' => 'nullable|boolean',
            'contact_us_enabled' => 'nullable|boolean',
            'enable_generated_links' => 'nullable|boolean',
            'is_multilingual' => 'nullable|boolean',
            'languages' => 'nullable|array',
            'languages.*' => 'string|max:10',
            'settings' => 'nullable|array',
            'time_limit_enabled' => 'nullable|boolean',
            'time_limit_minutes' => 'nullable|integer|min:1|max:1440',
            'pass_percentage' => 'nullable|numeric|min:0|max:100',
            'max_retakes' => 'nullable|integer|min:0',
            'registration_form_fields' => 'nullable|array',
            'registration_form_fields.*.name' => 'sometimes|required|string',
            'registration_form_fields.*.label' => 'sometimes|required|string',
            'registration_form_fields.*.type' => 'sometimes|required|string',
            'registration_form_fields.*.required' => 'sometimes|required|boolean',
            'registration_flow' => 'nullable|in:pre_submission,post_submission',
            // Additional details fields - all optional
            'sender_email' => 'nullable|email|max:255',
            'manager_name' => 'nullable|string|max:255',
            'manager_email' => 'nullable|email|max:255',
            'project_code' => 'nullable|string|max:255',
            'configuration_date' => 'nullable|date',
            'configuration_price' => 'nullable|numeric|min:0',
            'subscription_price' => 'nullable|numeric|min:0',
            'subscription_frequency' => 'nullable|in:one-time,monthly,quarterly,yearly',
            'tax_percentage' => 'nullable|numeric|min:0|max:100',
            'number_of_participants' => 'nullable|integer|min:0',
            'questions_to_randomize' => 'nullable|integer|min:0',
        ]);

        // Validate activity dates are within program date boundaries
        $program = \App\Models\Program::findOrFail($validated['program_id']);
        
        if ($program->start_date && $validated['start_date'] < $program->start_date) {
            return response()->json([
                'message' => 'Activity start date cannot be before program start date',
                'errors' => [
                    'start_date' => ['Activity start date (' . date('Y-m-d', strtotime($validated['start_date'])) . ') cannot be before program start date (' . date('Y-m-d', strtotime($program->start_date)) . ')']
                ]
            ], 422);
        }
        
        if ($program->end_date && $validated['end_date'] > $program->end_date) {
            return response()->json([
                'message' => 'Activity end date cannot be after program end date',
                'errors' => [
                    'end_date' => ['Activity end date (' . date('Y-m-d', strtotime($validated['end_date'])) . ') cannot be after program end date (' . date('Y-m-d', strtotime($program->end_date)) . ')']
                ]
            ], 422);
        }

        $activity = Activity::create([
            'id' => Str::uuid(),
            'program_id' => $validated['program_id'],
            'questionnaire_id' => $validated['questionnaire_id'] ?? null,
            'name' => $validated['name'],
            'description' => $validated['description'] ?? null,
            'type' => $validated['type'],
            'start_date' => $validated['start_date'],
            'end_date' => $validated['end_date'],
            'close_date' => $validated['close_date'] ?? null,
            'status' => $validated['status'] ?? 'draft',
            'allow_guests' => $validated['allow_guests'] ?? false,
            'contact_us_enabled' => $validated['contact_us_enabled'] ?? false,
            'enable_generated_links' => $validated['enable_generated_links'] ?? false,
            'is_multilingual' => $validated['is_multilingual'] ?? false,
            'languages' => $validated['languages'] ?? null,
            'settings' => $validated['settings'] ?? [],
            'time_limit_enabled' => $validated['time_limit_enabled'] ?? false,
            'time_limit_minutes' => $validated['time_limit_minutes'] ?? null,
            'pass_percentage' => $validated['pass_percentage'] ?? null,
            'max_retakes' => $validated['max_retakes'] ?? null,
            'registration_form_fields' => $validated['registration_form_fields'] ?? [],
            'registration_flow' => $validated['registration_flow'] ?? 'pre_submission',
            // Additional details fields - all optional
            'sender_email' => $validated['sender_email'] ?? null,
            'manager_name' => $validated['manager_name'] ?? null,
            'manager_email' => $validated['manager_email'] ?? null,
            'project_code' => $validated['project_code'] ?? null,
            'configuration_date' => $validated['configuration_date'] ?? null,
            'configuration_price' => $validated['configuration_price'] ?? null,
            'subscription_price' => $validated['subscription_price'] ?? null,
            'subscription_frequency' => $validated['subscription_frequency'] ?? null,
            'tax_percentage' => $validated['tax_percentage'] ?? null,
            'number_of_participants' => $validated['number_of_participants'] ?? null,
            'questions_to_randomize' => $validated['questions_to_randomize'] ?? null,
        ]);

        $activity->load(['program', 'questionnaire']);
        $activity->computed_status = $activity->getComputedStatus();
        
        // Make additional details fields visible
        $activity->makeVisible([
            'sender_email',
            'manager_name',
            'manager_email',
            'project_code',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
            'enable_generated_links',
        ]);

        return response()->json([
            'message' => 'Activity created successfully',
            'data' => $activity
        ], 201);
    }

    /**
     * Display the specified activity
     */
    public function show(string $id)
    {
        $activity = Activity::with(['program', 'questionnaire.sections.questions'])
            ->findOrFail($id);

        $activity->computed_status = $activity->getComputedStatus();
        
        // FORCE these fields to be included in JSON response
        $activity->enable_generated_links = (bool) $activity->enable_generated_links;
        $activity->allow_participant_reminders = (bool) $activity->allow_participant_reminders;
        
        // Ensure all additional fields are included in the response
        $activity->makeVisible([
            'sender_email',
            'manager_name',
            'manager_email',
            'project_code',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
            'enable_generated_links',
            'allow_participant_reminders',
        ]);

        return response()->json(['data' => $activity]);
    }

    /**
     * Update the specified activity
     */
    public function update(Request $request, string $id)
    {
        $activity = Activity::findOrFail($id);
        $user = $request->user();

        // Debug: Log incoming enable_generated_links value
        \Log::info('Activity Update Debug', [
            'activity_id' => $id,
            'enable_generated_links_in_request' => $request->input('enable_generated_links'),
            'enable_generated_links_type' => gettype($request->input('enable_generated_links')),
            'has_field' => $request->has('enable_generated_links'),
        ]);

        $validated = $request->validate([
            'program_id' => 'sometimes|required|uuid|exists:programs,id',
            'questionnaire_id' => 'nullable|integer|exists:questionnaires,id',
            'name' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'type' => 'sometimes|required|in:survey,poll,assessment',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'close_date' => 'nullable|date|after_or_equal:end_date',
            'status' => 'sometimes|in:draft,upcoming,live,expired,closed,archived',
            'allow_guests' => 'nullable|boolean',
            'contact_us_enabled' => 'nullable|boolean',
            'enable_generated_links' => 'nullable|boolean',
            'is_multilingual' => 'nullable|boolean',
            'languages' => 'nullable|array',
            'languages.*' => 'string|max:10',
            'settings' => 'nullable|array',
            'time_limit_enabled' => 'nullable|boolean',
            'time_limit_minutes' => 'nullable|integer|min:1|max:1440',
            'pass_percentage' => 'nullable|numeric|min:0|max:100',
            'max_retakes' => 'nullable|integer|min:0',
            'registration_form_fields' => 'nullable|array',
            'registration_form_fields.*.name' => 'required|string',
            'registration_form_fields.*.label' => 'required|string',
            'registration_form_fields.*.type' => 'required|string',
            'registration_form_fields.*.required' => 'required|boolean',
            'registration_flow' => 'nullable|in:pre_submission,post_submission',
            // Additional fields
            'sender_email' => 'nullable|email',
            'manager_name' => 'nullable|string|max:255',
            'manager_email' => 'nullable|email',
            'project_code' => 'nullable|string|max:100',
            'configuration_date' => 'nullable|date',
            'configuration_price' => 'nullable|numeric|min:0',
            'subscription_price' => 'nullable|numeric|min:0',
            'subscription_frequency' => 'nullable|string|in:one-time,monthly,quarterly,yearly',
            'tax_percentage' => 'nullable|numeric|min:0|max:100',
            'number_of_participants' => 'nullable|integer|min:0',
            'questions_to_randomize' => 'nullable|integer|min:0',
        ]);

        // Define locked fields after activity goes live or is approved (these can only be edited by super-admin)
        $lockedFields = [
            'start_date',
            'end_date',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
            'max_retakes',
        ];

        // Validate activity dates are within program date boundaries (if dates are being updated)
        if (isset($validated['program_id']) || isset($validated['start_date']) || isset($validated['end_date'])) {
            $programId = $validated['program_id'] ?? $activity->program_id;
            $startDate = $validated['start_date'] ?? $activity->start_date;
            $endDate = $validated['end_date'] ?? $activity->end_date;
            
            $program = \App\Models\Program::findOrFail($programId);
            
            if ($program->start_date && $startDate < $program->start_date) {
                return response()->json([
                    'message' => 'Activity start date cannot be before program start date',
                    'errors' => [
                        'start_date' => ['Activity start date (' . date('Y-m-d', strtotime($startDate)) . ') cannot be before program start date (' . date('Y-m-d', strtotime($program->start_date)) . ')']
                    ]
                ], 422);
            }
            
            if ($program->end_date && $endDate > $program->end_date) {
                return response()->json([
                    'message' => 'Activity end date cannot be after program end date',
                    'errors' => [
                        'end_date' => ['Activity end date (' . date('Y-m-d', strtotime($endDate)) . ') cannot be after program end date (' . date('Y-m-d', strtotime($program->end_date)) . ')']
                    ]
                ], 422);
            }
        }

        // Check if activity is live or approved, and user is NOT super-admin
        // Only super-admin can edit locked fields after activity goes live or gets approved
        $isLiveOrApproved = $activity->status === 'live' || $activity->approved_at;
        if ($isLiveOrApproved && $user->role !== 'super-admin') {
            // Remove locked fields from validated data for non-super-admin users
            foreach ($lockedFields as $field) {
                if (array_key_exists($field, $validated)) {
                    unset($validated[$field]);
                }
            }
            
            // Also prevent changes to settings that affect questions per page
            if (isset($validated['settings'])) {
                $validated['settings'] = array_merge(
                    $activity->settings ?? [],
                    array_diff_key($validated['settings'], ['questions_per_page' => null])
                );
            }
        }

        \Log::info('Before Update', [
            'enable_generated_links_in_validated' => $validated['enable_generated_links'] ?? 'NOT_PRESENT',
            'activity_enable_generated_links_before' => $activity->enable_generated_links,
        ]);

        $activity->update($validated);
        
        \Log::info('After Update', [
            'activity_enable_generated_links_after' => $activity->enable_generated_links,
            'activity_fresh_from_db' => $activity->fresh()->enable_generated_links,
        ]);

        $activity->load(['program', 'questionnaire']);
        $activity->computed_status = $activity->getComputedStatus();
        
        // Ensure all additional fields are included in the response
        $activity->makeVisible([
            'sender_email',
            'manager_name',
            'manager_email',
            'project_code',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
            'enable_generated_links',
        ]);

        return response()->json([
            'message' => 'Activity updated successfully',
            'data' => $activity
        ]);
    }

    /**
     * Soft delete the specified activity and cascade delete related data
     */
    public function destroy(string $id)
    {
        $activity = Activity::findOrFail($id);
        
        // Delete related data before soft-deleting the activity
        // Delete responses (and their answers)
        $activity->responses()->each(function ($response) {
            // Delete response answers if they exist
            if (method_exists($response, 'answers')) {
                $response->answers()->delete();
            }
            $response->delete();
        });
        
        // Delete notification templates
        $activity->notificationTemplates()->delete();
        
        // Delete approval requests related to this activity
        \App\Models\ActivityApprovalRequest::where('activity_id', $id)->delete();
        
        // Now soft delete the activity
        $activity->delete();

        return response()->json([
            'message' => 'Activity and all related data deleted successfully'
        ]);
    }

    /**
     * Assign or update questionnaire for activity
     */
    public function assignQuestionnaire(Request $request, string $id)
    {
        $activity = Activity::findOrFail($id);

        $validated = $request->validate([
            'questionnaire_id' => 'required|integer|exists:questionnaires,id',
        ]);

        $activity->update([
            'questionnaire_id' => $validated['questionnaire_id']
        ]);

        $activity->load(['program', 'questionnaire']);
        $activity->computed_status = $activity->getComputedStatus();
        
        // Make additional details fields visible
        $activity->makeVisible([
            'sender_email',
            'manager_name',
            'manager_email',
            'project_code',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
        ]);

        return response()->json([
            'message' => 'Questionnaire assigned successfully',
            'data' => $activity
        ]);
    }

    /**
     * Toggle participant reminders for an activity
     */
    public function toggleParticipantReminders(Request $request, string $id)
    {
        $validated = $request->validate([
            'allow_participant_reminders' => 'required|boolean'
        ]);

        $activity = Activity::findOrFail($id);
        $activity->update(['allow_participant_reminders' => $validated['allow_participant_reminders']]);

        return response()->json([
            'message' => 'Participant reminders setting updated successfully',
            'data' => $activity
        ]);
    }

    /**
     * Unassign questionnaire from activity
     */
    public function unassignQuestionnaire(string $id)
    {
        $activity = Activity::findOrFail($id);
        $activity->update(['questionnaire_id' => null]);
        $activity->load(['program', 'questionnaire']);
        
        // Make additional details fields visible
        $activity->makeVisible([
            'sender_email',
            'manager_name',
            'manager_email',
            'project_code',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
        ]);

        return response()->json([
            'message' => 'Questionnaire unassigned successfully',
            'data' => $activity
        ]);
    }

    /**
     * Archive activity
     */
    public function archive(string $id)
    {
        $activity = Activity::findOrFail($id);
        $activity->update(['status' => 'archived']);
        $activity->computed_status = $activity->getComputedStatus();
        
        // Make additional details fields visible
        $activity->makeVisible([
            'sender_email',
            'manager_name',
            'manager_email',
            'project_code',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
        ]);

        return response()->json([
            'message' => 'Activity archived successfully',
            'data' => $activity
        ]);
    }

    /**
     * Activate activity (set to upcoming or live based on dates)
     */
    public function activate(string $id)
    {
        $activity = Activity::findOrFail($id);
        
        $now = Carbon::now();
        $status = 'live';

        if ($activity->start_date && $now->lessThan($activity->start_date)) {
            $status = 'upcoming';
        }

        $activity->update(['status' => $status]);
        $activity->computed_status = $activity->getComputedStatus();
        
        // Make additional details fields visible
        $activity->makeVisible([
            'sender_email',
            'manager_name',
            'manager_email',
            'project_code',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
        ]);

        return response()->json([
            'message' => 'Activity activated successfully',
            'data' => $activity
        ]);
    }

    /**
     * Restore soft deleted activity
     */
    public function restore(string $id)
    {
        $activity = Activity::withTrashed()->findOrFail($id);
        $activity->restore();
        $activity->load(['program', 'questionnaire']);
        $activity->computed_status = $activity->getComputedStatus();
        
        // Make additional details fields visible
        $activity->makeVisible([
            'sender_email',
            'manager_name',
            'manager_email',
            'project_code',
            'configuration_date',
            'configuration_price',
            'subscription_price',
            'subscription_frequency',
            'tax_percentage',
            'number_of_participants',
            'questions_to_randomize',
        ]);

        return response()->json([
            'message' => 'Activity restored successfully',
            'data' => $activity
        ]);
    }

    /**
     * Permanently delete activity
     */
    public function forceDestroy(string $id)
    {
        $activity = Activity::withTrashed()->findOrFail($id);
        $activity->forceDelete();

        return response()->json([
            'message' => 'Activity permanently deleted'
        ]);
    }

    /**
     * Get activity statistics by status
     */
    public function statistics(Request $request)
    {
        $query = Activity::query();

        // Filter by program if provided
        if ($request->has('program_id')) {
            $query->byProgram($request->program_id);
        }

        $total = $query->count();
        $draft = (clone $query)->draft()->count();
        $upcoming = (clone $query)->upcoming()->count();
        $live = (clone $query)->live()->count();
        $expired = (clone $query)->expired()->count();
        $closed = (clone $query)->closed()->count();
        $archived = (clone $query)->archived()->count();
        $withGuests = (clone $query)->withGuests()->count();
        $multilingual = (clone $query)->multilingual()->count();

        return response()->json([
            'total' => $total,
            'by_status' => [
                'draft' => $draft,
                'upcoming' => $upcoming,
                'live' => $live,
                'expired' => $expired,
                'closed' => $closed,
                'archived' => $archived,
            ],
            'features' => [
                'allow_guests' => $withGuests,
                'is_multilingual' => $multilingual,
            ]
        ]);
    }


    /**
     * Get participants for an activity
     */
    public function getParticipants(string $id)
    {
        $activity = Activity::findOrFail($id);
        
        // Fetch participants with consistent logic matching event list
        // Include ALL active participants that can receive notifications:
        // 1. Registered participants (is_guest=false, not preview)
        // 2. Anonymous participants (participant_type='anonymous', not preview)
        // 3. Guests (is_guest=true, not preview) - these may need to receive notifications too
        // Exclude ONLY: Preview participants
        $participants = $activity->participants()
            ->select('participants.id', 'participants.name', 'participants.email', 'participants.phone', 
                     'participants.status', 'participants.is_guest', 'participants.is_preview', 'participants.additional_data', 'participants.created_at')
            ->withPivot('joined_at')
            ->where('is_preview', false) // Exclude preview participants only
            ->whereNotNull('email') // Must have email for notifications
            ->where('email', '!=', '') // Email must not be empty
            ->get()
            ->map(function ($participant) {
                // Determine participant type for display
                $additionalData = is_array($participant->additional_data) 
                    ? $participant->additional_data 
                    : ($participant->additional_data ? json_decode($participant->additional_data, true) : []);
                
                // Determine type: anonymous, guest, or registered
                if (isset($additionalData['participant_type']) && $additionalData['participant_type'] === 'anonymous') {
                    $participantType = 'anonymous';
                } elseif ($participant->is_guest) {
                    $participantType = 'guest';
                } else {
                    $participantType = 'registered';
                }
                
                return [
                    'id' => $participant->id,
                    'name' => $participant->name,
                    'email' => $participant->email,
                    'phone' => $participant->phone,
                    'status' => $participant->status,
                    'is_guest' => $participant->is_guest,
                    'type' => $participantType,
                    'joined_at' => $participant->pivot->joined_at,
                    'created_at' => $participant->created_at,
                ];
            });

        // Count breakdown
        $activeCount = $participants->where('status', 'active')->where('type', 'registered')->count();
        $anonymousCount = $participants->where('status', 'active')->where('type', 'anonymous')->count();
        $guestCount = $participants->where('status', 'active')->where('type', 'guest')->count();
        $inactiveCount = $participants->where('status', 'inactive')->count();

        return response()->json([
            'data' => $participants->values(),
            'count' => $participants->count(),
            'breakdown' => [
                'active' => $activeCount,
                'anonymous' => $anonymousCount,
                'guest' => $guestCount,
                'inactive' => $inactiveCount,
                'total' => $participants->count()
            ]
        ]);
    }

    /**
     * Add a new participant to an activity
     */
    public function addNewParticipant(Request $request, string $id)
    {
        // Base validation
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
        ]);

        $activity = Activity::findOrFail($id);
        $user = $request->user();

        // Check if this email is already associated with ANY participant in this activity
        $emailExistsInActivity = $activity->participants()
            ->where('email', $request->email)
            ->exists();
        
        if ($emailExistsInActivity) {
            return response()->json([
                'message' => 'A participant with this email has already been added to this event. Each email can only be used once per event.',
            ], 409);
        }

        $existingParticipant = Participant::withTrashed()
            ->where('email', $request->email)
            ->where('organization_id', $user->organization_id)
            ->first();

        if ($existingParticipant) {
            // If already in this activity, block duplicate add with a clear message
            if ($activity->participants()->where('participant_id', $existingParticipant->id)->exists()) {
                return response()->json([
                    'message' => 'Email already added to this activity',
                ], 409);
            }

            // Ensure participant is active and restored
            if ($existingParticipant->trashed()) {
                $existingParticipant->restore();
            }
            if ($existingParticipant->status === 'inactive') {
                $existingParticipant->status = 'active';
                $existingParticipant->save();
            }

            // Attach to program if missing
            if ($activity->program_id) {
                $existingParticipant->programs()->syncWithoutDetaching([$activity->program_id]);
            }

            // Attach to activity if not already present
            $activity->participants()->attach($existingParticipant->id, ['joined_at' => now()]);

            return response()->json([
                'message' => 'Existing participant added to activity',
                'data' => $existingParticipant
            ], 200);
        }

        // Build participant data with allowed fields
        $participantData = [
            'id' => Str::uuid(),
            'organization_id' => $user->organization_id,
            'name' => $request->name,
            'email' => $request->email,
            'status' => 'active',
            'is_guest' => false,
        ];

        // Add optional standard fields
        if ($request->has('phone')) {
            $participantData['phone'] = $request->phone;
        }
        if ($request->has('notes')) {
            $participantData['notes'] = $request->notes;
        }

        // Add custom fields from registration form if they exist in participant data
        if ($request->has('additional_data')) {
            $participantData['additional_data'] = $request->additional_data;
        }

        try {
            // Create new participant
            $participant = Participant::create($participantData);
        } catch (\Illuminate\Database\QueryException $e) {
            // Handle race/unique constraint gracefully using organization scope
            if ($e->getCode() === '23505') {
                $fallback = Participant::where('email', $request->email)
                    ->where('organization_id', $user->organization_id)
                    ->first();
                if ($fallback) {
                    if ($fallback->status === 'inactive') {
                        $fallback->status = 'active';
                        $fallback->save();
                    }
                    if ($activity->program_id) {
                        $fallback->programs()->syncWithoutDetaching([$activity->program_id]);
                    }
                    if (!$activity->participants()->where('participant_id', $fallback->id)->exists()) {
                        $activity->participants()->attach($fallback->id, ['joined_at' => now()]);
                    }
                    return response()->json([
                        'message' => 'Existing participant added to activity',
                        'data' => $fallback
                    ], 200);
                }
            }
            throw $e;
        }

        // Attach to program if activity has one
        if ($activity->program_id) {
            $participant->programs()->attach($activity->program_id, ['assigned_at' => now()]);
        }

        // Attach to activity
        $activity->participants()->attach($participant->id, ['joined_at' => now()]);

        return response()->json([
            'message' => 'Participant created and added to activity',
            'data' => $participant
        ], 201);
    }

    /**
     * Add existing participants from program to activity
     */
    public function addExistingParticipants(Request $request, string $id)
    {
        $validated = $request->validate([
            'participant_ids' => 'required|array',
            'participant_ids.*' => 'required|uuid|exists:participants,id',
        ]);

        $activity = Activity::findOrFail($id);
        $user = $request->user();

        $addedCount = 0;
        $alreadyAddedCount = 0;

        foreach ($validated['participant_ids'] as $participantId) {
            // Verify participant belongs to organization
            $participant = Participant::where('id', $participantId)
                ->where('organization_id', $user->organization_id)
                ->first();

            if (!$participant) {
                continue;
            }

            // Check if already in activity
            if ($activity->participants()->where('participant_id', $participantId)->exists()) {
                $alreadyAddedCount++;
                continue;
            }
            
            // Check if this email is already used by another participant in this activity
            $emailExistsInActivity = $activity->participants()
                ->where('email', $participant->email)
                ->where('id', '!=', $participantId)
                ->exists();
            
            if ($emailExistsInActivity) {
                $alreadyAddedCount++;
                continue;
            }

            // Add to activity
            $activity->participants()->attach($participantId, ['joined_at' => now()]);
            $addedCount++;
        }

        return response()->json([
            'message' => 'Participants added to activity',
            'added' => $addedCount,
            'already_added' => $alreadyAddedCount,
        ]);
    }

    /**
     * Remove a participant from an activity
     */
    public function removeParticipant(string $id, string $participantId)
    {
        $activity = Activity::findOrFail($id);
        
        // Check if participant is in the activity
        if (!$activity->participants()->where('participant_id', $participantId)->exists()) {
            return response()->json([
                'message' => 'Participant not found in this activity'
            ], 404);
        }

        // Remove participant from activity
        $activity->participants()->detach($participantId);

        return response()->json([
            'message' => 'Participant removed from activity'
        ]);
    }

    /**
     * Toggle participant status (active/inactive)
     */
    public function toggleParticipantStatus(string $participantId)
    {
        $participant = Participant::findOrFail($participantId);
        
        $participant->status = $participant->status === 'active' ? 'inactive' : 'active';
        $participant->save();

        return response()->json([
            'message' => 'Participant status toggled successfully',
            'data' => $participant
        ]);
    }

    /**
     * Update participant details
     */
    public function updateActivityParticipant(Request $request, string $id, string $participantId)
    {
        $activity = Activity::findOrFail($id);
        $participant = Participant::findOrFail($participantId);

        // Validate the request
        $validated = $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'email' => 'sometimes|required|email|unique:participants,email,' . $participantId,
            'phone' => 'nullable|string|max:20',
            'notes' => 'nullable|string',
            'status' => 'sometimes|in:active,inactive',
            'additional_data' => 'nullable|array',
        ]);

        $participant->update($validated);

        return response()->json([
            'message' => 'Participant updated successfully',
            'data' => $participant
        ]);
    }

    /**
     * Get available participants from program (not yet in activity)
     */
    public function getAvailableParticipants(Request $request, string $id)
    {
        $activity = Activity::findOrFail($id);
        $user = $request->user();

        // Get participants already in the activity
        $activityParticipantIds = $activity->participants()->pluck('participant_id')->toArray();

        // Build query for available participants
        $query = Participant::where('organization_id', $user->organization_id)
            ->where('status', 'active')
            ->whereNotIn('id', $activityParticipantIds);

        // If activity has a program, filter by program participants
        if ($activity->program_id) {
            $query->whereHas('programs', function ($q) use ($activity) {
                $q->where('programs.id', $activity->program_id);
            });
        }

        // Apply search filter
        if ($request->has('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        $participants = $query->select('id', 'name', 'email', 'phone', 'is_guest')
            ->orderBy('name')
            ->get();

        return response()->json([
            'data' => $participants,
            'count' => $participants->count()
        ]);
    }

    /**
     * Bulk import participants for an activity
     */
    public function importParticipants(Request $request, string $id)
    {
        $request->validate([
            'file' => 'required|file|mimes:csv,xlsx,xls'
        ]);

        try {
            $activity = Activity::findOrFail($id);
            $user = $request->user();
            
            $file = $request->file('file');
            $extension = $file->getClientOriginalExtension();
            
            // Read file content
            if ($extension === 'csv') {
                $data = array_map('str_getcsv', file($file->getRealPath()));
            } else {
                // Handle Excel files
                $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file->getRealPath());
                $data = $spreadsheet->getActiveSheet()->toArray();
            }
            
            // Get headers and data rows
            $headers = array_map('trim', array_shift($data));
            
            $successCount = 0;
            $skippedCount = 0;
            $skippedRows = [];
            
            foreach ($data as $index => $row) {
                $rowNumber = $index + 2; // +2 for 0-index and header row
                
                // Skip empty rows
                if (empty(array_filter($row))) {
                    continue;
                }
                
                // Map row data to headers
                $rowData = array_combine($headers, $row);
                
                // Validate required fields
                if (empty($rowData['name']) || empty($rowData['email'])) {
                    $skippedCount++;
                    $skippedRows[] = [
                        'rowNumber' => $rowNumber,
                        'reason' => 'Missing required fields (name and email)'
                    ];
                    continue;
                }
                
                // Check if this email is already associated with ANY participant in this activity
                $emailExistsInActivity = $activity->participants()
                    ->where('email', $rowData['email'])
                    ->exists();
                
                if ($emailExistsInActivity) {
                    $skippedCount++;
                    $skippedRows[] = [
                        'rowNumber' => $rowNumber,
                        'reason' => "A participant with email '{$rowData['email']}' has already been added to this event. Each email can only be used once per event."
                    ];
                    continue;
                }
                
                // Check for duplicate email
                $existingParticipant = Participant::where('email', $rowData['email'])
                    ->where('organization_id', $user->organization_id)
                    ->first();
                
                if ($existingParticipant) {
                    // Check if already in activity
                    if ($activity->participants()->where('participant_id', $existingParticipant->id)->exists()) {
                        $skippedCount++;
                        $skippedRows[] = [
                            'rowNumber' => $rowNumber,
                            'reason' => "Participant with email '{$rowData['email']}' already in activity"
                        ];
                        continue;
                    }
                    
                    // Add existing participant to activity
                    $activity->participants()->attach($existingParticipant->id, [
                        'joined_at' => now()
                    ]);
                    $successCount++;
                    continue;
                }
                
                // Create new participant with activity's registration fields
                $participantData = [
                    'id' => Str::uuid(),
                    'organization_id' => $user->organization_id,
                    'name' => $rowData['name'],
                    'email' => $rowData['email'],
                    'status' => 'active',
                ];
                
                // Add optional fields from registration form
                if ($activity->registration_form_fields) {
                    foreach ($activity->registration_form_fields as $field) {
                        $fieldName = $field['name'];
                        if (isset($rowData[$fieldName]) && !in_array($fieldName, ['name', 'email'])) {
                            $participantData[$fieldName] = $rowData[$fieldName];
                        }
                    }
                }
                
                try {
                    $participant = Participant::create($participantData);
                    
                    // Attach to activity
                    $activity->participants()->attach($participant->id, [
                        'joined_at' => now()
                    ]);
                    
                    // Attach to program if exists
                    if ($activity->program_id) {
                        $participant->programs()->attach($activity->program_id, [
                            'id' => Str::uuid()
                        ]);
                    }
                    
                    $successCount++;
                } catch (\Exception $e) {
                    $skippedCount++;
                    $skippedRows[] = [
                        'rowNumber' => $rowNumber,
                        'reason' => 'Failed to create participant: ' . $e->getMessage()
                    ];
                }
            }
            
            return response()->json([
                'message' => 'Import completed',
                'success_count' => $successCount,
                'skipped_count' => $skippedCount,
                'skipped_rows' => $skippedRows
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Import failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get activity links for sharing
     */
    public function getActivityLinks($id)
    {
        $activity = Activity::findOrFail($id);
        
        // CRITICAL: Use production URL as fallback - never localhost
        $frontendUrl = config('app.frontend_url', 'https://prod.qsights.com');
        
        // Generate encrypted tokens for each link type
        $registrationToken = $this->generateLinkToken($activity->id, 'registration');
        $previewToken = $this->generateLinkToken($activity->id, 'preview');
        $anonymousToken = $this->generateLinkToken($activity->id, 'anonymous');
        
        return response()->json([
            'links' => [
                'registration' => [
                    'url' => "{$frontendUrl}/activities/take/{$activity->id}?token=" . urlencode($registrationToken),
                    'label' => 'Registration Link',
                    'description' => 'For participants to register with name & email, then take the event'
                ],
                'preview' => [
                    'url' => "{$frontendUrl}/activities/take/{$activity->id}?token=" . urlencode($previewToken),
                    'label' => 'Preview Link',
                    'description' => 'Preview link for participants to take the event'
                ],
                'anonymous' => [
                    'url' => "{$frontendUrl}/activities/take/{$activity->id}?token=" . urlencode($anonymousToken),
                    'label' => 'Anonymous Link',
                    'description' => 'For guests to take the event anonymously (no name & email required)'
                ]
            ],
            'activity' => [
                'id' => $activity->id,
                'name' => $activity->name,
                'allow_guests' => $activity->allow_guests
            ]
        ]);
    }

    /**
     * Generate encrypted token for activity link
     */
    private function generateLinkToken($activityId, $type)
    {
        $payload = [
            'activity_id' => $activityId,
            'type' => $type,
            'timestamp' => time()
        ];
        
        return encrypt(json_encode($payload));
    }
    
    /**
     * Validate and decode activity link token
     */
    public function validateLinkToken(Request $request)
    {
        try {
            $token = $request->input('token');
            
            if (!$token) {
                return response()->json(['error' => 'Token is required'], 400);
            }
            
            $decrypted = decrypt($token);
            $payload = json_decode($decrypted, true);
            
            if (!isset($payload['activity_id']) || !isset($payload['type'])) {
                return response()->json(['error' => 'Invalid token format'], 400);
            }
            
            $activity = Activity::find($payload['activity_id']);
            
            if (!$activity) {
                return response()->json(['error' => 'Activity not found'], 404);
            }
            
            return response()->json([
                'valid' => true,
                'activity_id' => $payload['activity_id'],
                'type' => $payload['type']
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Invalid or expired token',
                'message' => $e->getMessage()
            ], 400);
        }
    }
    /**
     * Get landing page configuration
     */
    public function getLandingConfig($id)
    {
        $activity = Activity::findOrFail($id);
        
        return response()->json([
            'config' => $activity->landing_config ?? $this->getDefaultLandingConfig(),
            'templates' => $this->getPredefinedTemplates()
        ]);
    }
    
    /**
     * Save landing page configuration
     */
    public function saveLandingConfig(Request $request, $id)
    {
        $activity = Activity::findOrFail($id);
        
        // Frontend sends { config: {...} }, so extract the config object
        $configData = $request->input('config');
        
        // If config is not provided, try to use all request data (backward compatibility)
        if (!$configData) {
            $configData = $request->all();
            // Remove Laravel-specific fields if they exist
            unset($configData['_token'], $configData['_method']);
        }
        
        \Log::info('Saving landing config for activity ' . $id, ['config' => $configData]);
        
        // Save the entire configuration
        $activity->landing_config = $configData;
        $activity->save();
        
        return response()->json([
            'message' => 'Landing page configuration saved successfully',
            'config' => $activity->landing_config
        ]);
    }
    
    /**
     * Get predefined landing page templates
     */
    private function getPredefinedTemplates(): array
    {
        return [
            [
                'name' => 'Modern Professional',
                'description' => 'Clean blue professional theme',
                'config' => [
                    'bannerBackgroundColor' => '#3B82F6',
                    'backgroundColor' => '#FFFFFF',
                    'footerBackgroundColor' => '#F9FAFB',
                    'loginButtonColor' => '#3B82F6',
                    'activityCardHeaderColor' => '#3B82F6',
                    'bannerTextColor' => '#FFFFFF',
                    'loginBoxAlignment' => 'center',
                    'leftContentEnabled' => false
                ]
            ],
            [
                'name' => 'Gradient Blue',
                'description' => 'Eye-catching gradient design',
                'config' => [
                    'bannerBackgroundColor' => '#0EA5E9',
                    'backgroundColor' => '#F0F9FF',
                    'footerBackgroundColor' => '#0284C7',
                    'loginButtonColor' => '#0EA5E9',
                    'activityCardHeaderColor' => '#0284C7',
                    'bannerTextColor' => '#FFFFFF',
                    'loginBoxAlignment' => 'center',
                    'leftContentEnabled' => false
                ]
            ],
            [
                'name' => 'Minimal White',
                'description' => 'Minimalist black and white',
                'config' => [
                    'bannerBackgroundColor' => '#000000',
                    'backgroundColor' => '#FFFFFF',
                    'footerBackgroundColor' => '#F3F4F6',
                    'loginButtonColor' => '#000000',
                    'activityCardHeaderColor' => '#1F2937',
                    'bannerTextColor' => '#FFFFFF',
                    'loginBoxAlignment' => 'center',
                    'leftContentEnabled' => false
                ]
            ],
            [
                'name' => 'Split Screen',
                'description' => 'Left content panel with right-aligned form',
                'config' => [
                    'bannerBackgroundColor' => '#0EA5E9',
                    'backgroundColor' => '#F8FAFC',
                    'footerBackgroundColor' => '#F1F5F9',
                    'loginButtonColor' => '#F97316',
                    'activityCardHeaderColor' => '#0EA5E9',
                    'bannerTextColor' => '#FFFFFF',
                    'loginBoxAlignment' => 'right',
                    'leftContentEnabled' => true,
                    'leftContentBackgroundColor' => '#0EA5E9',
                    'leftContentTitle' => 'Welcome to Our Survey',
                    'leftContentTitleColor' => '#FFFFFF',
                    'leftContentDescription' => 'Your feedback helps us improve. Thank you for participating!',
                    'leftContentDescriptionColor' => '#E0F2FE'
                ]
            ]
        ];
    }
    
    /**
     * Get default landing config
     */
    private function getDefaultLandingConfig(): array
    {
        return [
            'template' => 'modern',
            'title' => 'Welcome',
            'subtitle' => 'Please register to continue',
            'description' => 'Enter your details below to get started',
            'primaryColor' => '#3B82F6',
            'secondaryColor' => '#1E40AF',
            'backgroundColor' => '#F3F4F6',
            'buttonText' => 'Register',
            'buttonColor' => '#3B82F6',
            'titleColor' => '#111827',
            'subtitleColor' => '#6B7280',
            'titleSize' => 'large',
            'logoSize' => 'medium',
            'showLogo' => true,
            'showTitle' => true,
            'showSubtitle' => true,
            'showDescription' => true
        ];
    }

    /**
     * Get notification statistics for an activity
     */
    public function getNotificationStats($id)
    {
        $activity = Activity::findOrFail($id);
        
        // Get all notifications for participants of this activity
        $participants = $activity->participants()
            ->where('status', 'active')
            ->whereNull('deleted_at')
            ->with(['notifications' => function($query) {
                $query->whereNull('deleted_at')
                      ->orderBy('sent_at', 'desc');
            }])
            ->get();
        
        // Initialize counters
        $emailStats = [
            'sent' => 0,
            'delivered' => 0,
            'opened' => 0,
            'clicked' => 0,
            'bounced' => 0,
            'dropped' => 0,
        ];
        
        $smsStats = [
            'sent' => 0,
            'delivered' => 0,
            'failed' => 0,
        ];
        
        $details = [];
        
        foreach ($participants as $participant) {
            $participantDetail = [
                'participant_id' => $participant->participant_id,
                'name' => $participant->name,
                'email' => $participant->email,
                'phone' => $participant->phone_number,
                'email_sent' => false,
                'email_delivered' => false,
                'email_opened' => false,
                'email_clicked' => false,
                'email_bounced' => false,
                'sms_sent' => false,
                'sms_delivered' => false,
                'sms_failed' => false,
                'notifications' => []
            ];
            
            foreach ($participant->notifications as $notification) {
                // Parse SendGrid metadata for email tracking
                $metadata = $notification->metadata ?? [];
                
                if ($notification->type === 'email') {
                    $participantDetail['email_sent'] = true;
                    $emailStats['sent']++;
                    
                    // Check SendGrid webhook data from metadata
                    if (isset($metadata['sendgrid_events'])) {
                        foreach ($metadata['sendgrid_events'] as $event) {
                            switch ($event) {
                                case 'delivered':
                                    $participantDetail['email_delivered'] = true;
                                    break;
                                case 'open':
                                    $participantDetail['email_opened'] = true;
                                    break;
                                case 'click':
                                    $participantDetail['email_clicked'] = true;
                                    break;
                                case 'bounce':
                                    $participantDetail['email_bounced'] = true;
                                    break;
                                case 'dropped':
                                    $emailStats['dropped']++;
                                    break;
                            }
                        }
                    } else {
                        // If no webhook data, assume delivered if sent successfully
                        if ($notification->status === 'sent') {
                            $participantDetail['email_delivered'] = true;
                        }
                    }
                    
                    if ($participantDetail['email_delivered']) $emailStats['delivered']++;
                    if ($participantDetail['email_opened']) $emailStats['opened']++;
                    if ($participantDetail['email_clicked']) $emailStats['clicked']++;
                    if ($participantDetail['email_bounced']) $emailStats['bounced']++;
                    
                } elseif ($notification->type === 'sms') {
                    $participantDetail['sms_sent'] = true;
                    $smsStats['sent']++;
                    
                    if ($notification->status === 'sent') {
                        $participantDetail['sms_delivered'] = true;
                        $smsStats['delivered']++;
                    } elseif ($notification->status === 'failed') {
                        $participantDetail['sms_failed'] = true;
                        $smsStats['failed']++;
                    }
                }
                
                $participantDetail['notifications'][] = [
                    'id' => $notification->id,
                    'type' => $notification->type,
                    'event' => $notification->event,
                    'subject' => $notification->subject,
                    'status' => $notification->status,
                    'sent_at' => $notification->sent_at,
                    'metadata' => $metadata
                ];
            }
            
            $details[] = $participantDetail;
        }
        
        return response()->json([
            'email' => $emailStats,
            'sms' => $smsStats,
            'details' => $details,
            'total_participants' => $participants->count()
        ]);
    }

    /**
     * Get participant counts for activities (lightweight endpoint for real-time updates)
     */
    public function getParticipantCounts(Request $request)
    {
        $activityIds = $request->input('activity_ids', []);
        
        if (empty($activityIds)) {
            return response()->json(['data' => []]);
        }

        $activities = Activity::whereIn('id', $activityIds)
            ->withCount([
                'participants as active_participants_count' => function ($query) {
                    $query->where('is_guest', false)
                          ->where('is_preview', false) // Exclude preview participants
                          ->where('status', 'active')
                          ->whereNull('deleted_at')
                          ->where(function($q) {
                              $q->whereNull('additional_data')
                                ->orWhereRaw("(additional_data IS NOT NULL AND (additional_data->>'participant_type' IS NULL OR additional_data->>'participant_type' != 'anonymous'))");
                          });
                },
                'participants as anonymous_participants_count' => function ($query) {
                    $query->where('is_preview', false) // Exclude preview participants
                          ->where('status', 'active')
                          ->whereNull('deleted_at')
                          ->whereRaw("additional_data IS NOT NULL AND additional_data->>'participant_type' = 'anonymous'");
                },
            ])
            ->get(['id', 'active_participants_count', 'anonymous_participants_count']);

        $counts = $activities->mapWithKeys(function ($activity) {
            return [
                $activity->id => [
                    'active' => $activity->active_participants_count,
                    'anonymous' => $activity->anonymous_participants_count,
                ]
            ];
        });

        return response()->json(['data' => $counts]);
    }
}
