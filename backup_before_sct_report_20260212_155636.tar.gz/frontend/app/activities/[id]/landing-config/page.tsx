"use client";

import React, { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import RoleBasedLayout from "@/components/role-based-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  ArrowLeft,
  Save,
  Eye,
  Image as ImageIcon,
  Upload,
  X,
  Palette,
  Type,
  Layout,
  Loader2,
  RefreshCw,
  Plus,
  Code,
  Monitor,
  Tablet,
  Smartphone,
  FileText,
} from "lucide-react";
import { activitiesApi } from "@/lib/api";
import { toast } from "@/components/ui/toast";
import S3ImageUpload from "@/components/S3ImageUpload";

interface LandingPageConfig {
  // Logo
  logoUrl: string;
  logoSize: string; // small, medium, large
  
  // Banner Title (appears in banner area)
  bannerTitle: string;
  bannerTitleColor: string;
  bannerTitleSize: string;
  bannerTitlePosition: string; // left, center, right
  
  // Top Banner
  bannerEnabled: boolean; // Enable/disable banner display
  bannerImageUrl: string;
  bannerImagePosition: string;
  bannerHeight: string;
  bannerBackgroundColor: string;
  bannerPaddingLeft: string; // Left padding for banner content
  bannerPaddingRight: string; // Right padding for banner content
  bannerText: string;
  bannerTextColor: string;
  bannerTextSize: string; // small, medium, large, xlarge
  bannerTextPosition: string;
  bannerShowOnInnerPages: boolean;
  
  // Footer
  footerEnabled: boolean;
  footerText: string;
  footerTextUrl: string; // URL to make footer text clickable/hyperlinked
  footerLinkText: string; // Display text for hyperlink within footer (e.g., "BioQuest Solutions")
  footerLinkUrl: string; // URL for the hyperlink
  footerLinkTarget: string; // _blank or _self
  footerTextColor: string;
  footerTextPosition: string;
  footerBackgroundColor: string;
  footerHeight: string;
  footerLogoUrl: string;
  footerLogoPosition: string;
  footerLogoSize: string;
  
  // Logo Position
  logoPosition: string;
  
  // Overall Background
  backgroundColor: string;
  backgroundImageUrl: string;
  backgroundStyle: string; // solid, gradient, image
  gradientFrom: string;
  gradientTo: string;
  
  // Post-Landing Content Header
  hideContentHeader: boolean;
  contentHeaderType: string; // "event" (show title/description), "logo", "custom"
  contentHeaderLogoUrl: string;
  contentHeaderLogoSize: string; // small, medium, large
  contentHeaderBackgroundStyle: string; // solid, gradient
  contentHeaderBackgroundColor: string;
  contentHeaderGradientFrom: string;
  contentHeaderGradientTo: string;
  contentHeaderCustomTitle: string;
  contentHeaderCustomSubtitle: string;
  
  // Content Header Display Controls (NEW)
  showContentHeaderTitle: boolean;
  showContentHeaderStartDate: boolean;
  showContentHeaderEndDate: boolean;
  showContentHeaderQuestions: boolean;
  
  // Background Image Opacity
  backgroundImageOpacity: number;
  
  // Left Content Block
  leftContentEnabled: boolean;
  leftContentTitle: string;
  leftContentTitleColor: string;
  leftContentDescription: string;
  leftContentDescriptionColor: string;
  leftContentImageUrl: string;
  leftContentImagePosition: string;
  leftContentBackgroundColor: string;
  
  // Split Screen Background Images
  splitScreenLeftBackgroundImageUrl: string;
  splitScreenLeftBackgroundPosition: string; // behind, above, below
  splitScreenLeftBackgroundVerticalPosition: string; // above, below (relative to title/description)
  splitScreenLeftBackgroundOpacity: number;
  splitScreenLeftBackgroundColor: string;
  splitScreenRightBackgroundImageUrl: string;
  splitScreenRightBackgroundOpacity: number;
  splitScreenRightBackgroundColor: string;
  
  // Full Page Background Image (for non-split templates)
  fullPageBackgroundImageUrl: string;
  fullPageBackgroundOpacity: number;
  fullPageBackgroundColor: string;
  
  // Features/Benefits Section
  featuresEnabled: boolean;
  features: Array<{
    icon: string;
    title: string;
    description: string;
    color: string;
  }>;
  
  // Login Box Customization
  activityCardHeaderColor: string; // Color of the card header where activity name appears
  loginBoxTitle: string;
  loginBoxSubtitle: string;
  loginBoxBackgroundColor: string;
  loginBoxBorderColor: string;
  loginBoxAlignment: string; // "left" | "center" | "right"
  loginBoxBannerLogoUrl: string;
  loginBoxShowTitle: boolean; // Toggle to show/hide survey title in login box
  loginBoxBackgroundImageUrl: string; // Background image for login box
  loginBoxBackgroundOpacity: number; // Opacity of background image (0-100)
  loginButtonColor: string;
  loginButtonText: string;
  
  // Login Box Logo/Text Configuration
  loginBoxContentType: string; // "logo" | "text" | "event" (logo, custom text, or event name/description)
  loginBoxLogoUrl: string;
  loginBoxLogoHorizontalPosition: string; // left, center, right
  loginBoxLogoVerticalPosition: string; // top, bottom
  loginBoxCustomTitle: string;
  loginBoxCustomSubtitle: string;
  
  // Thank You Page
  thankYouTitle: string;
  thankYouMessage: string;
  thankYouSubMessage: string;
  thankYouIconColor: string;
  thankYouShowConfirmation: boolean;
  thankYouShowBanner: boolean; // Display top banner on Thank You page
  thankYouShowFooter: boolean; // Display footer on Thank You page
  enableTakeEventAgainButton: boolean; // NEW: Kiosk mode - allow new participants on same device
  
  // Post Session Registration Page
  postSessionRegTitle: string;
  postSessionRegSubtitle: string;
  postSessionRegDescription: string;
  postSessionRegButtonText: string;
  postSessionRegBackgroundColor: string;
  postSessionRegBackgroundImageUrl: string;
  postSessionRegBackgroundOpacity: number;
  postSessionRegFormBackgroundColor: string;
  postSessionRegFormBorderColor: string;
  postSessionRegButtonColor: string;
  postSessionRegTitleColor: string;
  postSessionRegDescriptionColor: string;
  
  // Additional Branding
  accentColor: string;
  fontFamily: string;
  borderRadius: string; // rounded, square, pill
  
  // Custom CSS
  customCss: string;
  
  // CSS & Fonts - Typography
  cssTypography: {
    primaryFontFamily: string;
    customGoogleFontUrl: string;
    fontWeight: string;
    baseFontSize: string;
    lineHeight: string;
  };
  
  // CSS & Fonts - Headings
  cssHeadings: {
    h1Size: string;
    h2Size: string;
    h3Size: string;
    headingFontWeight: string;
    headingColor: string;
    letterSpacing: string;
  };
  
  // CSS & Fonts - Buttons
  cssButtons: {
    buttonFontFamily: string;
    buttonFontSize: string;
    buttonBorderRadius: string;
    buttonHoverOpacity: number;
    buttonDisabledOpacity: number;
  };
  
  // CSS & Fonts - Scope Control
  cssScopeControl: {
    applyToLandingPage: boolean;
    applyToPostLandingPage: boolean;
    applyToThankYouPage: boolean;
    applyToLoggedInParticipants: boolean;
    applyToAnonymousUsers: boolean;
  };
  
  // CSS & Fonts - Theme Preset
  cssThemePreset: string;
}

const defaultConfig: LandingPageConfig = {
  logoUrl: "",
  logoSize: "medium",
  bannerTitle: "Welcome",
  bannerTitleColor: "#1F2937",
  bannerTitleSize: "large",
  bannerTitlePosition: "center",
  bannerImageUrl: "",
  bannerImagePosition: "center",
  bannerHeight: "200px",
  bannerBackgroundColor: "#3B82F6",
  bannerPaddingLeft: "48px",
  bannerPaddingRight: "48px",
  bannerText: "",
  bannerTextColor: "#FFFFFF",
  bannerTextSize: "medium",
  bannerTextPosition: "left",
  bannerEnabled: true,
  bannerShowOnInnerPages: false,
  footerEnabled: true,
  footerText: "© 2025 All rights reserved.",
  footerTextUrl: "",
  footerLinkText: "",
  footerLinkUrl: "",
  footerLinkTarget: "_blank",
  footerTextColor: "#6B7280",
  footerTextPosition: "left",
  footerBackgroundColor: "#F9FAFB",
  footerHeight: "80px",
  footerLogoUrl: "",
  footerLogoPosition: "left",
  footerLogoSize: "medium",
  backgroundColor: "#FFFFFF",
  backgroundImageUrl: "",
  backgroundStyle: "solid",
  gradientFrom: "#F3F4F6",
  gradientTo: "#DBEAFE",
  hideContentHeader: false,
  contentHeaderType: "event", // Default to showing event title/description
  contentHeaderLogoUrl: "",
  contentHeaderLogoSize: "medium",
  contentHeaderBackgroundStyle: "gradient",
  contentHeaderBackgroundColor: "#3B82F6",
  contentHeaderGradientFrom: "#3B82F6",
  contentHeaderGradientTo: "#7C3AED",
  contentHeaderCustomTitle: "",
  contentHeaderCustomSubtitle: "",
  showContentHeaderTitle: true,
  showContentHeaderStartDate: true,
  showContentHeaderEndDate: true,
  showContentHeaderQuestions: true,
  backgroundImageOpacity: 100,
  leftContentEnabled: true,
  leftContentTitle: "Professional Survey Platform",
  leftContentTitleColor: "#1F2937",
  leftContentDescription: "Create and manage surveys with advanced analytics and insights.",
  leftContentDescriptionColor: "#6B7280",
  leftContentImageUrl: "",
  leftContentImagePosition: "top",
  leftContentBackgroundColor: "#FFFFFF",
  splitScreenLeftBackgroundImageUrl: "",
  splitScreenLeftBackgroundPosition: "behind",
  splitScreenLeftBackgroundVerticalPosition: "full",
  splitScreenLeftBackgroundOpacity: 100,
  splitScreenLeftBackgroundColor: "#FFFFFF",
  splitScreenRightBackgroundImageUrl: "",
  splitScreenRightBackgroundOpacity: 100,
  splitScreenRightBackgroundColor: "#F3F4F6",
  fullPageBackgroundImageUrl: "",
  fullPageBackgroundOpacity: 100,
  fullPageBackgroundColor: "#FFFFFF",
  featuresEnabled: true,
  features: [
    { icon: "check", title: "Easy to Use", description: "Simple and intuitive interface", color: "#10B981" },
    { icon: "shield", title: "Secure", description: "Your data is protected", color: "#3B82F6" },
    { icon: "clock", title: "Quick", description: "Get started in minutes", color: "#F59E0B" },
    { icon: "users", title: "Collaborative", description: "Work with your team", color: "#8B5CF6" },
  ],
  activityCardHeaderColor: "#3B82F6",
  loginBoxTitle: "Sign In",
  loginBoxSubtitle: "Enter your credentials to continue",
  loginBoxBackgroundColor: "#FFFFFF",
  loginBoxBorderColor: "#E5E7EB",
  loginBoxAlignment: "center",
  loginBoxBannerLogoUrl: "",
  loginBoxShowTitle: true,
  loginBoxBackgroundImageUrl: "",
  loginBoxBackgroundOpacity: 50,
  loginButtonColor: "#3B82F6",
  loginButtonText: "Sign In",
  loginBoxContentType: "event",
  loginBoxLogoUrl: "",
  loginBoxLogoHorizontalPosition: "center",
  loginBoxLogoVerticalPosition: "top",
  loginBoxCustomTitle: "",
  loginBoxCustomSubtitle: "",
  logoPosition: "left",
  thankYouTitle: "Thank you!",
  thankYouMessage: "Your response has been submitted",
  thankYouSubMessage: "We appreciate your participation",
  thankYouIconColor: "#10B981",
  thankYouShowConfirmation: true,
  thankYouShowBanner: true, // Display banner on Thank You page by default
  thankYouShowFooter: true, // Display footer on Thank You page by default
  enableTakeEventAgainButton: false, // Disabled by default
  // Post Session Registration defaults
  postSessionRegTitle: "Complete Your Registration",
  postSessionRegSubtitle: "One more step to finish!",
  postSessionRegDescription: "Please provide your details below to complete your participation.",
  postSessionRegButtonText: "Submit Registration",
  postSessionRegBackgroundColor: "#F3F4F6",
  postSessionRegBackgroundImageUrl: "",
  postSessionRegBackgroundOpacity: 100,
  postSessionRegFormBackgroundColor: "#FFFFFF",
  postSessionRegFormBorderColor: "#E5E7EB",
  postSessionRegButtonColor: "#3B82F6",
  postSessionRegTitleColor: "#1F2937",
  postSessionRegDescriptionColor: "#6B7280",
  accentColor: "#3B82F6",
  fontFamily: "system",
  borderRadius: "rounded",
  customCss: "",
  // CSS & Fonts defaults
  cssTypography: {
    primaryFontFamily: "system",
    customGoogleFontUrl: "",
    fontWeight: "normal",
    baseFontSize: "16px",
    lineHeight: "1.5",
  },
  cssHeadings: {
    h1Size: "2.25rem",
    h2Size: "1.875rem",
    h3Size: "1.5rem",
    headingFontWeight: "bold",
    headingColor: "#1F2937",
    letterSpacing: "normal",
  },
  cssButtons: {
    buttonFontFamily: "inherit",
    buttonFontSize: "14px",
    buttonBorderRadius: "8px",
    buttonHoverOpacity: 90,
    buttonDisabledOpacity: 50,
  },
  cssScopeControl: {
    applyToLandingPage: true,
    applyToPostLandingPage: true,
    applyToThankYouPage: true,
    applyToLoggedInParticipants: true,
    applyToAnonymousUsers: true,
  },
  cssThemePreset: "default",
};

export default function LandingPageConfigPage() {
  const router = useRouter();
  const params = useParams();
  const activityId = params.id as string;
  
  const [config, setConfig] = useState<LandingPageConfig>(defaultConfig);
  const [templates, setTemplates] = useState<any[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("landing-page");
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");

  useEffect(() => {
    loadConfig();
  }, [activityId]);

  const loadConfig = async () => {
    try {
      setLoading(true);
      const response = await activitiesApi.getLandingPageConfig(activityId);
      
      // Define fallback templates
      const fallbackTemplates = [
        {
          name: "Modern Professional",
          description: "Clean blue professional theme",
          config: { bannerBackgroundColor: "#3B82F6", backgroundColor: "#FFFFFF", footerBackgroundColor: "#F9FAFB", loginButtonColor: "#3B82F6", activityCardHeaderColor: "#3B82F6", loginBoxAlignment: "center", leftContentEnabled: false }
        },
        {
          name: "Gradient Blue",
          description: "Eye-catching gradient design",
          config: { bannerBackgroundColor: "#0EA5E9", backgroundColor: "#F0F9FF", footerBackgroundColor: "#0284C7", loginButtonColor: "#0EA5E9", activityCardHeaderColor: "#0284C7", loginBoxAlignment: "center", leftContentEnabled: false }
        },
        {
          name: "Minimal White",
          description: "Minimalist black and white",
          config: { bannerBackgroundColor: "#000000", backgroundColor: "#FFFFFF", footerBackgroundColor: "#F3F4F6", loginButtonColor: "#000000", activityCardHeaderColor: "#1F2937", loginBoxAlignment: "center", leftContentEnabled: false }
        },
        {
          name: "Split Screen",
          description: "Left content panel with right-aligned form",
          config: { 
            bannerBackgroundColor: "#0EA5E9", 
            backgroundColor: "#F8FAFC", 
            footerBackgroundColor: "#F1F5F9", 
            loginButtonColor: "#F97316", 
            activityCardHeaderColor: "#0EA5E9",
            loginBoxAlignment: "right",
            leftContentEnabled: true,
            leftContentBackgroundColor: "#0EA5E9",
            leftContentTitle: "Welcome to Our Survey",
            leftContentTitleColor: "#FFFFFF",
            leftContentDescription: "Your feedback helps us improve. Thank you for participating!",
            leftContentDescriptionColor: "#E0F2FE"
          }
        }
      ];
      
      // Extract templates if available, otherwise use fallback
      const loadedTemplates = response.templates && Array.isArray(response.templates) ? response.templates : fallbackTemplates;
      setTemplates(loadedTemplates);
      
      // Extract config - API returns { config: {...}, templates: [...] }
      let data = response.config || response;
      console.log("Loaded config from API:", data);
      
      // Check if config is nested (old format: { config: {...} })
      if (data && data.config && typeof data.config === 'object') {
        console.log("Detected nested config structure, extracting inner config");
        data = data.config;
      }
      
      if (data && Object.keys(data).length > 0) {
        // Merge with default config to ensure all fields are present
        let mergedConfig = { ...defaultConfig, ...data };
        console.log("Merged config:", mergedConfig);
        
        // Clean any blob URLs from the config
        mergedConfig = cleanBlobUrls(mergedConfig);
        
        setConfig(mergedConfig);
        
        // Detect which template is currently applied by comparing key properties
        // First try exact match
        let detectedTemplateIndex = loadedTemplates.findIndex((template: any) => {
          const templateConfig = template.config;
          return (
            templateConfig.bannerBackgroundColor === mergedConfig.bannerBackgroundColor &&
            templateConfig.backgroundColor === mergedConfig.backgroundColor &&
            templateConfig.footerBackgroundColor === mergedConfig.footerBackgroundColor &&
            templateConfig.loginButtonColor === mergedConfig.loginButtonColor &&
            templateConfig.activityCardHeaderColor === mergedConfig.activityCardHeaderColor &&
            templateConfig.leftContentEnabled === mergedConfig.leftContentEnabled
          );
        });
        
        // If no exact match, try "close match" - match 4+ out of 6 properties
        // This helps when user makes small customizations but still uses a template base
        if (detectedTemplateIndex === -1) {
          detectedTemplateIndex = loadedTemplates.findIndex((template: any) => {
            const templateConfig = template.config;
            let matchCount = 0;
            
            if (templateConfig.backgroundColor === mergedConfig.backgroundColor) matchCount++;
            if (templateConfig.footerBackgroundColor === mergedConfig.footerBackgroundColor) matchCount++;
            if (templateConfig.loginButtonColor === mergedConfig.loginButtonColor) matchCount++;
            if (templateConfig.activityCardHeaderColor === mergedConfig.activityCardHeaderColor) matchCount++;
            if (templateConfig.leftContentEnabled === mergedConfig.leftContentEnabled) matchCount++;
            
            // Consider it a match if 4+ properties match (excluding banner which users often customize)
            return matchCount >= 4;
          });
        }
        
        if (detectedTemplateIndex !== -1) {
          console.log("Detected applied template:", detectedTemplateIndex);
          setSelectedTemplate(detectedTemplateIndex);
        }
      } else {
        console.log("Using default config");
        setConfig(defaultConfig);
      }
    } catch (err) {
      console.error("Failed to load landing page config:", err);
      // If no config exists, use default and show templates
      const fallbackTemplates = [
        {
          name: "Modern Professional",
          description: "Clean blue professional theme",
          config: { bannerBackgroundColor: "#3B82F6", backgroundColor: "#FFFFFF", footerBackgroundColor: "#F9FAFB", loginButtonColor: "#3B82F6", activityCardHeaderColor: "#3B82F6", loginBoxAlignment: "center", leftContentEnabled: false }
        },
        {
          name: "Gradient Blue",
          description: "Eye-catching gradient design",
          config: { bannerBackgroundColor: "#0EA5E9", backgroundColor: "#F0F9FF", footerBackgroundColor: "#0284C7", loginButtonColor: "#0EA5E9", activityCardHeaderColor: "#0284C7", loginBoxAlignment: "center", leftContentEnabled: false }
        },
        {
          name: "Minimal White",
          description: "Minimalist black and white",
          config: { bannerBackgroundColor: "#000000", backgroundColor: "#FFFFFF", footerBackgroundColor: "#F3F4F6", loginButtonColor: "#000000", activityCardHeaderColor: "#1F2937", loginBoxAlignment: "center", leftContentEnabled: false }
        },
        {
          name: "Split Screen",
          description: "Left content panel with right-aligned form",
          config: { 
            bannerBackgroundColor: "#0EA5E9", 
            backgroundColor: "#F8FAFC", 
            footerBackgroundColor: "#F1F5F9", 
            loginButtonColor: "#F97316", 
            activityCardHeaderColor: "#0EA5E9",
            loginBoxAlignment: "right",
            leftContentEnabled: true,
            leftContentBackgroundColor: "#0EA5E9",
            leftContentTitle: "Welcome to Our Survey",
            leftContentTitleColor: "#FFFFFF",
            leftContentDescription: "Your feedback helps us improve. Thank you for participating!",
            leftContentDescriptionColor: "#E0F2FE"
          }
        }
      ];
      
      setConfig(defaultConfig);
      setTemplates(fallbackTemplates);
      
      // Check if default config matches any template
      // First try exact match
      let detectedTemplateIndex = fallbackTemplates.findIndex((template: any) => {
        const templateConfig = template.config;
        return (
          templateConfig.bannerBackgroundColor === defaultConfig.bannerBackgroundColor &&
          templateConfig.backgroundColor === defaultConfig.backgroundColor &&
          templateConfig.footerBackgroundColor === defaultConfig.footerBackgroundColor &&
          templateConfig.loginButtonColor === defaultConfig.loginButtonColor &&
          templateConfig.activityCardHeaderColor === defaultConfig.activityCardHeaderColor &&
          templateConfig.leftContentEnabled === defaultConfig.leftContentEnabled
        );
      });
      
      // If no exact match, try "close match" - match 4+ out of 6 properties
      if (detectedTemplateIndex === -1) {
        detectedTemplateIndex = fallbackTemplates.findIndex((template: any) => {
          const templateConfig = template.config;
          let matchCount = 0;
          
          if (templateConfig.backgroundColor === defaultConfig.backgroundColor) matchCount++;
          if (templateConfig.footerBackgroundColor === defaultConfig.footerBackgroundColor) matchCount++;
          if (templateConfig.loginButtonColor === defaultConfig.loginButtonColor) matchCount++;
          if (templateConfig.activityCardHeaderColor === defaultConfig.activityCardHeaderColor) matchCount++;
          if (templateConfig.leftContentEnabled === defaultConfig.leftContentEnabled) matchCount++;
          
          return matchCount >= 4;
        });
      }
      
      if (detectedTemplateIndex !== -1) {
        console.log("Default config matches template:", detectedTemplateIndex);
        setSelectedTemplate(detectedTemplateIndex);
      }
    } finally {
      setLoading(false);
    }
  };

  const applyTemplate = (templateConfig: any, index: number) => {
    console.log("Applying template:", index, templateConfig);
    const newConfig = { ...defaultConfig, ...templateConfig };
    console.log("New config:", newConfig);
    setConfig(newConfig);
    setSelectedTemplate(index);
    toast({ 
      title: "Template Applied", 
      description: "Template has been applied successfully! Click Save Configuration to keep changes.",
      variant: "success",
      duration: 4000
    });
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      console.log("Saving config:", config);
      await activitiesApi.saveLandingPageConfig(activityId, config);
      
      // Reload the preview iframe to show updated landing page
      const iframe = document.querySelector('iframe[title="Landing Page Preview"]') as HTMLIFrameElement;
      if (iframe) {
        iframe.src = `/activities/take/${activityId}?preview=true&t=${Date.now()}`; // Force reload with timestamp
      }
      
      toast({ title: "Success", description: "Landing page configuration saved successfully! Preview updated.", variant: "success", duration: 3000 });
    } catch (err) {
      console.error("Failed to save config:", err);
      toast({ title: "Error", description: "Failed to save configuration. Please try again.", variant: "error", duration: 4000 });
    } finally {
      setSaving(false);
    }
  };

  const handlePreview = () => {
    window.open(`/activities/take/${activityId}?preview=true`, '_blank');
  };

  const handleReset = () => {
    if (confirm("Reset to default configuration? This will discard all changes.")) {
      setConfig(defaultConfig);
    }
  };

  const updateConfig = (key: string, value: any) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  // Helper function to detect and clean blob URLs
  const cleanBlobUrls = (configData: any) => {
    const cleaned = { ...configData };
    let hadBlobUrls = false;
    const imageFields = [
      'logoUrl',
      'bannerImageUrl',
      'footerLogoUrl',
      'splitScreenLeftBackgroundImageUrl',
      'splitScreenRightBackgroundImageUrl',
      'fullPageBackgroundImageUrl',
      'loginBoxLogoUrl',
      'backgroundImageUrl',
      'contentHeaderLogoUrl',
      'leftContentImageUrl',
      'loginBoxBackgroundImageUrl',
      'loginBoxBannerLogoUrl'
    ];

    imageFields.forEach(field => {
      if (cleaned[field] && typeof cleaned[field] === 'string' && cleaned[field].startsWith('blob:')) {
        console.warn(`Removing invalid blob URL from ${field}:`, cleaned[field]);
        cleaned[field] = '';
        hadBlobUrls = true;
      }
    });

    if (hadBlobUrls) {
      toast({
        title: "Temporary Images Removed",
        description: "Some images were using temporary URLs and have been cleared. Please re-upload them using the Upload buttons.",
        variant: "warning",
        duration: 8000,
      });
    }

    return cleaned;
  };

  const handleImageUpload = async (field: string, file: File) => {
    toast({
      title: "Not Supported",
      description: "Direct file upload is not available. Please use an image URL from S3 or external source.",
      variant: "warning",
      duration: 5000,
    });
  };

  const addFeature = () => {
    setConfig(prev => ({
      ...prev,
      features: [...prev.features, { icon: "check", title: "", description: "", color: "#3B82F6" }]
    }));
  };

  const removeFeature = (index: number) => {
    setConfig(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  };

  const updateFeature = (index: number, field: string, value: string) => {
    setConfig(prev => ({
      ...prev,
      features: prev.features.map((f, i) => i === index ? { ...f, [field]: value } : f)
    }));
  };

  if (loading) {
    return (
      <RoleBasedLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-gray-600">Loading configuration...</p>
          </div>
        </div>
      </RoleBasedLayout>
    );
  }

  return (
    <RoleBasedLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={() => router.push("/activities")}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Landing Page Configuration</h1>
              <p className="text-sm text-gray-500">Customize the participant login experience</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              onClick={handleReset}
              className="flex items-center space-x-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reset</span>
            </Button>
            <Button
              variant="outline"
              onClick={handlePreview}
              className="flex items-center space-x-2"
            >
              <Eye className="w-4 h-4" />
              <span>Preview</span>
            </Button>
            <Button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white"
            >
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Save Configuration</span>
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8">
            {[
              { id: "landing-page", label: "Design for Landing Page", icon: Layout, description: "Configure the initial landing and login experience" },
              { id: "post-landing", label: "Post Landing Page", icon: Palette, description: "Customize the page shown after login" },
              { id: "post-session-reg", label: "Post Session Registration", icon: FileText, description: "Configure the post-submission registration page" },
              { id: "thank-you", label: "Thank You Page", icon: Type, description: "Configure the completion message" },
              { id: "css-fonts", label: "CSS & Fonts", icon: Code, description: "Advanced styling and typography controls" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                title={tab.description}
                className={`flex items-center space-x-2 pb-4 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-blue-600 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Configuration Content */}
        <div>
          {/* Landing Page Tab */}
          {activeTab === "landing-page" && (
            <>
              {/* Tab Info - Full Width */}
              <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 className="text-sm font-semibold text-blue-900 mb-1">Design for Landing Page</h3>
                <p className="text-sm text-blue-700">Configure all aspects of the participant's first landing and login experience, including branding, layout, and interactive elements.</p>
              </div>

              {/* Predefined Templates and Live Preview in 2 columns */}
              <div className="grid lg:grid-cols-2 gap-6 mb-6">
                {/* Left: Predefined Templates */}
                <div>
                  {templates.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle>Predefined Templates</CardTitle>
                        <p className="text-sm text-gray-500">
                          Choose a template to quickly set up your landing page. Click on any template to apply it.
                        </p>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 gap-4">
                          {templates.map((template: any, index: number) => (
                <div
                  key={index}
                  className={`relative border-2 rounded-lg overflow-hidden cursor-pointer hover:shadow-xl transition-all group ${
                    selectedTemplate === index 
                      ? 'border-blue-600 ring-4 ring-blue-300 shadow-lg' 
                      : 'border-gray-300 hover:border-blue-500'
                  }`}
                  onClick={() => applyTemplate(template.config, index)}
                >
                  {/* Applied Indicator Badge */}
                  {selectedTemplate === index && (
                    <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-full shadow-lg animate-in fade-in zoom-in duration-300">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span className="text-xs font-bold">APPLIED</span>
                    </div>
                  )}
                  
                  {/* Template Preview Image */}
                  <div 
                    className="relative h-48 overflow-hidden flex"
                    style={{ backgroundColor: template.config.backgroundColor || "#F9FAFB" }}
                  >
                    {/* Left content panel (for split-screen template) */}
                    {template.config.leftContentEnabled && (
                      <div 
                        className="w-1/2 h-full flex items-center justify-center p-2"
                        style={{ backgroundColor: template.config.leftContentBackgroundColor || "#0EA5E9" }}
                      >
                        <div className="text-center">
                          <div className="w-8 h-8 bg-white/20 rounded-full mx-auto mb-2"></div>
                          <div className="h-1 bg-white/40 rounded w-16 mx-auto mb-1"></div>
                          <div className="h-1 bg-white/30 rounded w-12 mx-auto"></div>
                        </div>
                      </div>
                    )}
                    
                    {/* Main content area */}
                    <div className={`relative ${template.config.leftContentEnabled ? 'w-1/2' : 'w-full'} h-full`}>
                      {/* Mini banner */}
                      <div 
                        className="w-full h-12" 
                        style={{ backgroundColor: template.config.bannerBackgroundColor || "#3B82F6" }}
                      />
                      {/* Mini card */}
                      <div className={`absolute top-16 ${template.config.leftContentEnabled ? 'left-1/2 transform -translate-x-1/2' : 'left-1/2 transform -translate-x-1/2'} w-32 bg-white rounded shadow-md p-2`}>
                        <div 
                          className="w-full h-6 rounded mb-2 flex items-center justify-center"
                          style={{ backgroundColor: template.config.activityCardHeaderColor || template.config.bannerBackgroundColor || "#3B82F6" }}
                        >
                          <span className="text-white text-[8px] font-bold">Activity</span>
                        </div>
                        <div className="space-y-1">
                          <div className="h-2 bg-gray-200 rounded w-full"></div>
                          <div className="h-2 bg-gray-200 rounded w-3/4"></div>
                        </div>
                        <div 
                          className="w-full h-4 rounded mt-2 flex items-center justify-center"
                          style={{ backgroundColor: template.config.loginButtonColor || "#3B82F6" }}
                        >
                          <span className="text-white text-[6px]">Start</span>
                        </div>
                      </div>
                      {/* Mini footer */}
                      <div 
                        className="absolute bottom-0 w-full h-6" 
                        style={{ backgroundColor: template.config.footerBackgroundColor || "#F9FAFB" }}
                      />
                    </div>
                  </div>
                  
                  {/* Template Info */}
                  <div className={`p-4 transition-colors ${selectedTemplate === index ? 'bg-blue-50' : 'bg-white'}`}>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className={`font-semibold text-sm ${selectedTemplate === index ? 'text-blue-900' : 'text-gray-900'}`}>
                        {template.name}
                      </h3>
                      {selectedTemplate === index ? (
                        <div className="flex items-center gap-1 text-xs px-2.5 py-1 bg-blue-600 text-white rounded-md font-semibold">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          <span>Active</span>
                        </div>
                      ) : (
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="text-xs text-blue-600 font-medium">Click to apply →</span>
                        </div>
                      )}
                    </div>
                    <p className={`text-xs mb-3 ${selectedTemplate === index ? 'text-blue-700' : 'text-gray-600'}`}>
                      {template.description}
                    </p>
                    <div className="flex gap-2">
                      <div
                        className="w-6 h-6 rounded border shadow-sm"
                        style={{ backgroundColor: template.config.bannerBackgroundColor }}
                        title="Banner Color"
                      />
                      <div
                        className="w-6 h-6 rounded border shadow-sm"
                        style={{ backgroundColor: template.config.backgroundColor }}
                        title="Background Color"
                      />
                      <div
                        className="w-6 h-6 rounded border shadow-sm"
                        style={{ backgroundColor: template.config.loginButtonColor }}
                        title="Button Color"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>

    {/* Right: Live Preview */}
    <div>
      <Card className="border-2 border-gray-200 lg:sticky lg:top-6">
        <CardHeader className="bg-gray-50">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium text-gray-700">Live Preview</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={handlePreview}
              className="text-xs"
            >
              <Eye className="w-3 h-3 mr-1" />
              Full Screen
            </Button>
          </div>
          <div className="flex items-center gap-1 mt-3 p-1 bg-gray-200 rounded-lg">
            <button
              onClick={() => setPreviewDevice("desktop")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                previewDevice === "desktop"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              Desktop
            </button>
            <button
              onClick={() => setPreviewDevice("tablet")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                previewDevice === "tablet"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <Tablet className="w-3.5 h-3.5" />
              Tablet
            </button>
            <button
              onClick={() => setPreviewDevice("mobile")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                previewDevice === "mobile"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              Mobile
            </button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div 
            className="bg-gray-100 relative overflow-hidden flex justify-center"
            style={{ 
              height: previewDevice === "mobile" ? "500px" : previewDevice === "tablet" ? "450px" : "400px",
              padding: previewDevice !== "desktop" ? "16px" : "0"
            }}
          >
            {previewDevice === "desktop" ? (
              <div
                style={{
                  width: "100%",
                  height: "400px",
                  overflow: "hidden",
                  position: "relative",
                }}
              >
                <iframe
                  src={`/activities/take/${activityId}?preview=true`}
                  className="border-0"
                  title="Landing Page Preview"
                  style={{ 
                    transform: 'scale(0.4)',
                    transformOrigin: 'top left',
                    width: '250%',
                    height: '1000px',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                  }}
                />
              </div>
            ) : (
              <div
                style={{
                  width: previewDevice === "mobile" ? "375px" : "768px",
                  height: previewDevice === "mobile" ? "467px" : "400px",
                  border: "8px solid #1F2937",
                  borderRadius: "24px",
                  overflow: "hidden",
                  boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                }}
              >
                <iframe
                  src={`/activities/take/${activityId}?preview=true`}
                  className="w-full h-full border-0"
                  title="Landing Page Preview"
                />
              </div>
            )}
          </div>
          <div className="p-3 bg-gray-50 border-t text-center">
            <p className="text-xs text-gray-500">Preview updates when you click Save Configuration</p>
          </div>
        </CardContent>
      </Card>
    </div>
  </div>

  {/* Configuration Sections in 2 columns */}
  <div className="grid lg:grid-cols-2 gap-6">
<Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Top Banner Configuration</CardTitle>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={config.bannerEnabled !== false}
                          onChange={(e) => updateConfig("bannerEnabled", e.target.checked)}
                          className="w-4 h-4 text-blue-600"
                        />
                        <span className="text-sm text-gray-600">Enable</span>
                      </label>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Configure logo and banner text displayed at the top</p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Logo Section */}
                    <div className="space-y-4">
                      <h4 className="font-semibold text-sm text-gray-900">Logo</h4>
                      <div>
                        <Label>Logo Image</Label>
                        <p className="text-xs text-gray-500 mt-1">Upload logo to S3 storage or enter an image URL</p>
                        <div className="mt-2 space-y-3">
                          <S3ImageUpload
                            value={config.logoUrl || ""}
                            onChange={(url) => updateConfig("logoUrl", url)}
                            onRemove={() => updateConfig("logoUrl", "")}
                            folder="landing-logos"
                            maxSize={5}
                            accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp"
                            placeholder="Click to upload logo (PNG, JPG, GIF, SVG, WebP)"
                          />
                          <div>
                            <Label className="text-xs text-gray-600">Or enter Image URL</Label>
                            <div className="flex gap-2 mt-1">
                              <Input
                                type="url"
                                value={config.logoUrl || ""}
                                onChange={(e) => updateConfig("logoUrl", e.target.value)}
                                placeholder="https://example.com/logo.png"
                                className="flex-1"
                              />
                              {config.logoUrl && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => updateConfig("logoUrl", "")}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                            <p className="text-xs text-gray-500 mt-1">Direct URL to your logo image (S3, CDN, or any public URL)</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Logo Size</Label>
                          <select
                            value={config.logoSize}
                            onChange={(e) => updateConfig("logoSize", e.target.value)}
                            className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                          >
                            <option value="small">Small</option>
                            <option value="medium">Medium</option>
                            <option value="large">Large</option>
                          </select>
                        </div>
                        <div>
                          <Label>Logo Position</Label>
                          <select
                            value={config.logoPosition || "left"}
                            onChange={(e) => updateConfig("logoPosition", e.target.value)}
                            className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                          >
                            <option value="left">Left</option>
                            <option value="center">Center</option>
                            <option value="right">Right</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-6">
                      <h4 className="font-semibold text-sm text-gray-900 mb-4">Banner Text / Title</h4>
                      <div className="space-y-4">
                        <div>
                          <Label>Banner Text</Label>
                          <Input
                            value={config.bannerText}
                            onChange={(e) => updateConfig("bannerText", e.target.value)}
                            placeholder="Welcome to Our Survey"
                            className="mt-2"
                          />
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <Label>Text Color</Label>
                            <div className="flex items-center space-x-2 mt-2">
                              <input
                                type="color"
                                value={config.bannerTextColor}
                                onChange={(e) => updateConfig("bannerTextColor", e.target.value)}
                                className="h-10 w-20"
                              />
                              <Input
                                value={config.bannerTextColor}
                                onChange={(e) => updateConfig("bannerTextColor", e.target.value)}
                                placeholder="#FFFFFF"
                              />
                            </div>
                          </div>
                          <div>
                            <Label>Text Size</Label>
                            <select
                              value={config.bannerTextSize || "medium"}
                              onChange={(e) => updateConfig("bannerTextSize", e.target.value)}
                              className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                            >
                              <option value="small">Small</option>
                              <option value="medium">Medium</option>
                              <option value="large">Large</option>
                              <option value="xlarge">Extra Large</option>
                            </select>
                          </div>
                          <div>
                            <Label>Text Position</Label>
                            <select
                              value={config.bannerTextPosition || "left"}
                              onChange={(e) => updateConfig("bannerTextPosition", e.target.value)}
                              className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                            >
                              <option value="left">Left</option>
                              <option value="center">Center</option>
                              <option value="right">Right</option>
                            </select>
                          </div>
                        </div>

                        <div>
                          <Label>Banner Image</Label>
                          <p className="text-xs text-gray-500 mt-1">Upload banner image to S3 storage or enter an image URL</p>
                          <div className="mt-2 space-y-3">
                            <S3ImageUpload
                              value={config.bannerImageUrl || ""}
                              onChange={(url) => updateConfig("bannerImageUrl", url)}
                              onRemove={() => updateConfig("bannerImageUrl", "")}
                              folder="landing-banners"
                              maxSize={15}
                              accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp"
                              placeholder="Click to upload banner image (PNG, JPG, GIF, SVG, WebP)"
                            />
                            <div>
                              <Label className="text-xs text-gray-600">Or enter Image URL</Label>
                              <Input
                                type="url"
                                value={config.bannerImageUrl || ""}
                                onChange={(e) => updateConfig("bannerImageUrl", e.target.value)}
                                placeholder="https://example.com/banner.png"
                                className="mt-1"
                              />
                              <p className="text-xs text-gray-500 mt-1">Direct URL to your banner image (S3, CDN, or any public URL)</p>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Banner Height</Label>
                            <Input
                              value={config.bannerHeight}
                              onChange={(e) => updateConfig("bannerHeight", e.target.value)}
                              placeholder="200px"
                              className="mt-2"
                            />
                          </div>
                          <div>
                            <Label>Background Color</Label>
                            <div className="flex items-center space-x-2 mt-2">
                              <input
                                type="color"
                                value={config.bannerBackgroundColor}
                                onChange={(e) => updateConfig("bannerBackgroundColor", e.target.value)}
                                className="h-10 w-20"
                              />
                              <Input
                                value={config.bannerBackgroundColor}
                                onChange={(e) => updateConfig("bannerBackgroundColor", e.target.value)}
                              />
                            </div>
                          </div>
                        </div>

                        <div>
                          <Label>Banner Image Position</Label>
                          <select
                            value={config.bannerImagePosition || "center"}
                            onChange={(e) => updateConfig("bannerImagePosition", e.target.value)}
                            className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                          >
                            <option value="left">Left</option>
                            <option value="center">Center</option>
                            <option value="right">Right</option>
                          </select>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Banner Padding Left</Label>
                            <Input
                              value={config.bannerPaddingLeft || "24px"}
                              onChange={(e) => updateConfig("bannerPaddingLeft", e.target.value)}
                              placeholder="24px"
                              className="mt-2"
                            />
                            <p className="text-xs text-gray-500 mt-1">Left spacing for banner content</p>
                          </div>
                          <div>
                            <Label>Banner Padding Right</Label>
                            <Input
                              value={config.bannerPaddingRight || "24px"}
                              onChange={(e) => updateConfig("bannerPaddingRight", e.target.value)}
                              placeholder="24px"
                              className="mt-2"
                            />
                            <p className="text-xs text-gray-500 mt-1">Right spacing for banner content</p>
                          </div>
                        </div>

                        <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <label className="flex items-center space-x-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={config.bannerShowOnInnerPages || false}
                              onChange={(e) => updateConfig("bannerShowOnInnerPages", e.target.checked)}
                              className="w-4 h-4 text-blue-600"
                            />
                            <div>
                              <span className="text-sm font-medium text-gray-900">Show banner on inner pages</span>
                              <p className="text-xs text-gray-600 mt-0.5">Enable this to display the banner on survey/assessment/poll pages (not just landing page)</p>
                            </div>
                          </label>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Left Content Panel</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Content displayed on the left side panel (split screen template)</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Title</Label>
                      <Input
                        value={config.leftContentTitle}
                        onChange={(e) => updateConfig("leftContentTitle", e.target.value)}
                        placeholder="Event title (from event details)"
                        className="mt-2"
                      />
                      <p className="text-xs text-gray-500 mt-1">Defaults to event title</p>
                    </div>
                    <div>
                      <Label>Title Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.leftContentTitleColor}
                          onChange={(e) => updateConfig("leftContentTitleColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.leftContentTitleColor}
                          onChange={(e) => updateConfig("leftContentTitleColor", e.target.value)}
                          placeholder="#1F2937"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Description</Label>
                      <textarea
                        value={config.leftContentDescription}
                        onChange={(e) => updateConfig("leftContentDescription", e.target.value)}
                        placeholder="Event description (from event details)"
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg min-h-[100px]"
                      />
                      <p className="text-xs text-gray-500 mt-1">Defaults to event description</p>
                    </div>
                    <div>
                      <Label>Description Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.leftContentDescriptionColor}
                          onChange={(e) => updateConfig("leftContentDescriptionColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.leftContentDescriptionColor}
                          onChange={(e) => updateConfig("leftContentDescriptionColor", e.target.value)}
                          placeholder="#6B7280"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Footer</CardTitle>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={config.footerEnabled !== false}
                          onChange={(e) => updateConfig("footerEnabled", e.target.checked)}
                          className="w-4 h-4 text-blue-600"
                        />
                        <span className="text-sm text-gray-600">Enable</span>
                      </label>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Footer Text</Label>
                      <Input
                        value={config.footerText}
                        onChange={(e) => updateConfig("footerText", e.target.value)}
                        placeholder="© 2025 All rights reserved"
                        className="mt-2"
                        disabled={config.footerEnabled === false}
                      />
                    </div>
                    <div>
                      <Label>Footer Text URL (Optional)</Label>
                      <Input
                        type="url"
                        value={config.footerTextUrl || ""}
                        onChange={(e) => updateConfig("footerTextUrl", e.target.value)}
                        placeholder="https://yoursite.com"
                        className="mt-2"
                        disabled={config.footerEnabled === false}
                      />
                      <p className="text-xs text-gray-500 mt-1">Make entire footer text clickable by adding a link URL</p>
                    </div>
                    
                    {/* Footer Hyperlink Configuration */}
                    <div className="border-t pt-4 mt-4">
                      <Label className="text-sm font-semibold">Footer Hyperlink (Optional)</Label>
                      <p className="text-xs text-gray-500 mt-1 mb-3">Add a hyperlink for specific words/phrases within your footer text</p>
                      
                      <div className="space-y-3">
                        <div>
                          <Label className="text-xs">Link Display Text</Label>
                          <Input
                            value={config.footerLinkText || ""}
                            onChange={(e) => updateConfig("footerLinkText", e.target.value)}
                            placeholder="e.g., BioQuest Solutions"
                            className="mt-1"
                            disabled={config.footerEnabled === false}
                          />
                          <p className="text-xs text-gray-500 mt-1">Text to be hyperlinked (will be styled in QSights color)</p>
                        </div>
                        <div>
                          <Label className="text-xs">Link URL</Label>
                          <Input
                            type="url"
                            value={config.footerLinkUrl || ""}
                            onChange={(e) => updateConfig("footerLinkUrl", e.target.value)}
                            placeholder="https://example.com"
                            className="mt-1"
                            disabled={config.footerEnabled === false}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Open Link In</Label>
                          <select
                            value={config.footerLinkTarget || "_blank"}
                            onChange={(e) => updateConfig("footerLinkTarget", e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            disabled={config.footerEnabled === false}
                          >
                            <option value="_blank">New Tab (_blank)</option>
                            <option value="_self">Same Tab (_self)</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Footer Text Position</Label>
                      <select
                        value={config.footerTextPosition || "left"}
                        onChange={(e) => updateConfig("footerTextPosition", e.target.value)}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        disabled={config.footerEnabled === false}
                      >
                        <option value="left">Left</option>
                        <option value="center">Center</option>
                        <option value="right">Right</option>
                      </select>
                    </div>
                    <div>
                      <Label>Footer Logo</Label>
                      <p className="text-xs text-gray-500 mt-1">Upload footer logo to S3 storage or enter an image URL</p>
                      <div className="mt-2 space-y-3">
                        <S3ImageUpload
                          value={config.footerLogoUrl || ""}
                          onChange={(url) => updateConfig("footerLogoUrl", url)}
                          onRemove={() => updateConfig("footerLogoUrl", "")}
                          folder="landing-logos"
                          maxSize={5}
                          accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp"
                          placeholder="Click to upload footer logo (PNG, JPG, GIF, SVG, WebP)"
                        />
                        <div>
                          <Label className="text-xs text-gray-600">Or enter Logo URL</Label>
                          <div className="flex gap-2 mt-1">
                            <Input
                              type="url"
                              value={config.footerLogoUrl || ""}
                              onChange={(e) => updateConfig("footerLogoUrl", e.target.value)}
                              placeholder="https://example.com/footer-logo.png"
                              className="flex-1"
                              disabled={config.footerEnabled === false}
                            />
                            {config.footerLogoUrl && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateConfig("footerLogoUrl", "")}
                                disabled={config.footerEnabled === false}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <Label>Footer Logo Size</Label>
                      <select
                        value={config.footerLogoSize || "medium"}
                        onChange={(e) => updateConfig("footerLogoSize", e.target.value)}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        disabled={config.footerEnabled === false}
                      >
                        <option value="small">Small</option>
                        <option value="medium">Medium</option>
                        <option value="large">Large</option>
                      </select>
                    </div>
                    <div>
                      <Label>Footer Logo Position</Label>
                      <select
                        value={config.footerLogoPosition || "left"}
                        onChange={(e) => updateConfig("footerLogoPosition", e.target.value)}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        disabled={config.footerEnabled === false}
                      >
                        <option value="left">Left</option>
                        <option value="center">Center</option>
                        <option value="right">Right</option>
                      </select>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label>Text Color</Label>
                        <div className="flex items-center space-x-2 mt-2">
                          <input
                            type="color"
                            value={config.footerTextColor}
                            onChange={(e) => updateConfig("footerTextColor", e.target.value)}
                            className="h-10 w-20"
                            disabled={config.footerEnabled === false}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Background Color</Label>
                        <div className="flex items-center space-x-2 mt-2">
                          <input
                            type="color"
                            value={config.footerBackgroundColor}
                            onChange={(e) => updateConfig("footerBackgroundColor", e.target.value)}
                            className="h-10 w-20"
                            disabled={config.footerEnabled === false}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Height</Label>
                        <Input
                          value={config.footerHeight}
                          onChange={(e) => updateConfig("footerHeight", e.target.value)}
                          placeholder="80px"
                          className="mt-2"
                          disabled={config.footerEnabled === false}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Set Background Image - All Templates */}
                <Card>
                  <CardHeader>
                    <CardTitle>Set Background Image</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">
                      Configure background images based on template selection
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    {/* Split Screen Template - Left and Right Background Images */}
                    <div className={`space-y-6 p-4 rounded-lg border-2 ${config.loginBoxAlignment === "right" ? "border-blue-300 bg-blue-50" : "border-gray-200 bg-gray-50"}`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-base font-semibold text-gray-900">Split Screen Template Background</h3>
                          <p className="text-xs text-gray-600 mt-0.5">For templates with login box on right side</p>
                        </div>
                        {config.loginBoxAlignment === "right" && (
                          <span className="px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded-full">Currently Active</span>
                        )}
                      </div>

                      <div className="space-y-6">
                        {/* Left Side Background */}
                        <div>
                          <Label>Left Side Background Color</Label>
                          <p className="text-xs text-gray-500 mt-1">Background color for left content panel</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <input
                              type="color"
                              value={config.splitScreenLeftBackgroundColor || "#FFFFFF"}
                              onChange={(e) => updateConfig("splitScreenLeftBackgroundColor", e.target.value)}
                              className="h-10 w-20"
                            />
                            <Input
                              value={config.splitScreenLeftBackgroundColor || "#FFFFFF"}
                              onChange={(e) => updateConfig("splitScreenLeftBackgroundColor", e.target.value)}
                              placeholder="#FFFFFF"
                            />
                          </div>
                        </div>

                        {/* Left Side Background Image */}
                        <div>
                          <Label>Left Side Background Image (Optional)</Label>
                          <p className="text-xs text-gray-500 mt-1">Upload to S3 or enter URL for left content panel background</p>
                          <div className="mt-2 space-y-3">
                            <S3ImageUpload
                              value={config.splitScreenLeftBackgroundImageUrl || ""}
                              onChange={(url) => updateConfig("splitScreenLeftBackgroundImageUrl", url)}
                              onRemove={() => updateConfig("splitScreenLeftBackgroundImageUrl", "")}
                              folder="landing-backgrounds"
                              maxSize={15}
                              accept="image/png,image/jpeg,image/gif,image/webp"
                              placeholder="Click to upload left background (PNG, JPG, GIF, WebP)"
                            />
                            
                            <div>
                              <Label className="text-xs text-gray-600">Or enter Image URL</Label>
                              <div className="flex gap-2 mt-1">
                                <Input
                                  type="url"
                                  value={config.splitScreenLeftBackgroundImageUrl || ""}
                                  onChange={(e) => updateConfig("splitScreenLeftBackgroundImageUrl", e.target.value)}
                                  placeholder="https://example.com/left-background.jpg"
                                  className="flex-1"
                                />
                                {config.splitScreenLeftBackgroundImageUrl && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => updateConfig("splitScreenLeftBackgroundImageUrl", "")}
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                )}
                              </div>
                            </div>

                            {config.splitScreenLeftBackgroundImageUrl && (
                              <>
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <Label>Image Layer Position</Label>
                                    <p className="text-xs text-gray-500 mt-1">Z-index relative to content</p>
                                    <select
                                      value={config.splitScreenLeftBackgroundPosition || "behind"}
                                      onChange={(e) => updateConfig("splitScreenLeftBackgroundPosition", e.target.value)}
                                      className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                                    >
                                      <option value="behind">Behind Content</option>
                                      <option value="above">Above Content</option>
                                    </select>
                                  </div>

                                  <div>
                                    <Label>Vertical Position</Label>
                                    <p className="text-xs text-gray-500 mt-1">Relative to title & description</p>
                                    <select
                                      value={config.splitScreenLeftBackgroundVerticalPosition || "full"}
                                      onChange={(e) => updateConfig("splitScreenLeftBackgroundVerticalPosition", e.target.value)}
                                      className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                                    >
                                      <option value="below">Below (After Description)</option>
                                      <option value="full">Full as Background</option>
                                    </select>
                                  </div>
                                </div>
                                
                                <div>
                                  <Label>Image Opacity</Label>
                                  <p className="text-xs text-gray-500 mt-1">Adjust transparency (0-100%)</p>
                                  <div className="flex items-center gap-3 mt-2">
                                    <input
                                      type="range"
                                      min="0"
                                      max="100"
                                      value={config.splitScreenLeftBackgroundOpacity ?? 100}
                                      onChange={(e) => updateConfig("splitScreenLeftBackgroundOpacity", parseInt(e.target.value))}
                                      className="flex-1"
                                    />
                                    <span className="text-sm font-medium text-gray-700 w-12 text-right">{config.splitScreenLeftBackgroundOpacity ?? 100}%</span>
                                  </div>
                                </div>
                              </>
                            )}
                          </div>
                        </div>

                        {/* Right Side Background */}
                        <div>
                          <Label>Right Side Background Color</Label>
                          <p className="text-xs text-gray-500 mt-1">Background color for right login panel</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <input
                              type="color"
                              value={config.splitScreenRightBackgroundColor || "#F3F4F6"}
                              onChange={(e) => updateConfig("splitScreenRightBackgroundColor", e.target.value)}
                              className="h-10 w-20"
                            />
                            <Input
                              value={config.splitScreenRightBackgroundColor || "#F3F4F6"}
                              onChange={(e) => updateConfig("splitScreenRightBackgroundColor", e.target.value)}
                              placeholder="#F3F4F6"
                            />
                          </div>
                        </div>

                        {/* Right Side Background Image */}
                        <div>
                          <Label>Right Side Background Image (Optional)</Label>
                          <p className="text-xs text-gray-500 mt-1">Upload to S3 or enter URL for right login panel background</p>
                          <div className="mt-2 space-y-3">
                            <S3ImageUpload
                              value={config.splitScreenRightBackgroundImageUrl || ""}
                              onChange={(url) => updateConfig("splitScreenRightBackgroundImageUrl", url)}
                              onRemove={() => updateConfig("splitScreenRightBackgroundImageUrl", "")}
                              folder="landing-backgrounds"
                              maxSize={15}
                              accept="image/png,image/jpeg,image/gif,image/webp"
                              placeholder="Click to upload right background (PNG, JPG, GIF, WebP)"
                            />
                            
                            <div>
                              <Label className="text-xs text-gray-600">Or enter Image URL</Label>
                              <div className="flex gap-2 mt-1">
                                <Input
                                  type="url"
                                  value={config.splitScreenRightBackgroundImageUrl || ""}
                                  onChange={(e) => updateConfig("splitScreenRightBackgroundImageUrl", e.target.value)}
                                  placeholder="https://example.com/right-background.jpg"
                                  className="flex-1"
                                />
                                {config.splitScreenRightBackgroundImageUrl && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => updateConfig("splitScreenRightBackgroundImageUrl", "")}
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                )}
                              </div>
                            </div>
                            
                            {config.splitScreenRightBackgroundImageUrl && (
                              <div>
                                <Label>Image Opacity</Label>
                                <p className="text-xs text-gray-500 mt-1">Adjust transparency (0-100%)</p>
                                <div className="flex items-center gap-3 mt-2">
                                  <input
                                    type="range"
                                    min="0"
                                    max="100"
                                    value={config.splitScreenRightBackgroundOpacity ?? 100}
                                    onChange={(e) => updateConfig("splitScreenRightBackgroundOpacity", parseInt(e.target.value))}
                                    className="flex-1"
                                  />
                                  <span className="text-sm font-medium text-gray-700 w-12 text-right">{config.splitScreenRightBackgroundOpacity ?? 100}%</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="p-3 bg-blue-100 border border-blue-200 rounded-lg">
                          <p className="text-sm text-blue-900 font-medium mb-1">💡 Split Screen Tips</p>
                          <ul className="text-xs text-blue-700 space-y-1 list-disc list-inside">
                            <li>Images cover full height from header to footer</li>
                            <li>Use high-resolution images (min 1920px wide)</li>
                            <li>Left image vertical position controls alignment relative to event title</li>
                            <li>Right image: behind login form</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Other Templates - Full Page Background */}
                    <div className={`space-y-6 p-4 rounded-lg border-2 ${config.loginBoxAlignment !== "right" ? "border-blue-300 bg-blue-50" : "border-gray-200 bg-gray-50"}`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-base font-semibold text-gray-900">Other Templates Background</h3>
                          <p className="text-xs text-gray-600 mt-0.5">For centered login, modern, gradient, and minimal templates</p>
                        </div>
                        {config.loginBoxAlignment !== "right" && (
                          <span className="px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded-full">Currently Active</span>
                        )}
                      </div>

                      <div className="space-y-6">
                        {/* Full Page Background Color */}
                        <div>
                          <Label>Full Page Background Color</Label>
                          <p className="text-xs text-gray-500 mt-1">Background color for the entire page</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <input
                              type="color"
                              value={config.fullPageBackgroundColor || "#F9FAFB"}
                              onChange={(e) => updateConfig("fullPageBackgroundColor", e.target.value)}
                              className="h-10 w-20"
                            />
                            <Input
                              value={config.fullPageBackgroundColor || "#F9FAFB"}
                              onChange={(e) => updateConfig("fullPageBackgroundColor", e.target.value)}
                              placeholder="#F9FAFB"
                            />
                          </div>
                        </div>

                        {/* Full Page Background Image for Other Templates */}
                        <div>
                          <Label>Full Page Background Image (Optional)</Label>
                          <p className="text-xs text-gray-500 mt-1">Upload to S3 or enter URL for full page background</p>
                          <div className="mt-2 space-y-3">
                            <S3ImageUpload
                              value={config.fullPageBackgroundImageUrl || ""}
                              onChange={(url) => updateConfig("fullPageBackgroundImageUrl", url)}
                              onRemove={() => updateConfig("fullPageBackgroundImageUrl", "")}
                              folder="landing-backgrounds"
                              maxSize={15}
                              accept="image/png,image/jpeg,image/gif,image/webp"
                              placeholder="Click to upload full page background (PNG, JPG, GIF, WebP)"
                            />
                            
                            <div>
                              <Label className="text-xs text-gray-600">Or enter Image URL</Label>
                              <div className="flex gap-2 mt-1">
                                <Input
                                  type="url"
                                  value={config.fullPageBackgroundImageUrl || ""}
                                  onChange={(e) => updateConfig("fullPageBackgroundImageUrl", e.target.value)}
                                  placeholder="https://example.com/background.jpg"
                                  className="flex-1"
                                />
                                {config.fullPageBackgroundImageUrl && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => updateConfig("fullPageBackgroundImageUrl", "")}
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                )}
                              </div>
                            </div>
                            
                            {config.fullPageBackgroundImageUrl && (
                              <div>
                                <Label>Image Opacity</Label>
                                <p className="text-xs text-gray-500 mt-1">Adjust transparency (0-100%)</p>
                                <div className="flex items-center gap-3 mt-2">
                                  <input
                                    type="range"
                                    min="0"
                                    max="100"
                                    value={config.fullPageBackgroundOpacity ?? 100}
                                    onChange={(e) => updateConfig("fullPageBackgroundOpacity", parseInt(e.target.value))}
                                    className="flex-1"
                                  />
                                  <span className="text-sm font-medium text-gray-700 w-12 text-right">{config.fullPageBackgroundOpacity ?? 100}%</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="p-3 bg-blue-100 border border-blue-200 rounded-lg">
                          <p className="text-sm text-blue-900 font-medium mb-1">💡 Full Page Background Tips</p>
                          <ul className="text-xs text-blue-700 space-y-1 list-disc list-inside">
                            <li>Image covers entire page from header to footer</li>
                            <li>Use high-resolution images (min 1920px wide)</li>
                            <li>Displays behind all content with CSS cover</li>
                            <li>Header and footer remain visible over background</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Login Box Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle>Login Box Configuration</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Customize logo or text displayed in the login box</p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <Label>Content Type</Label>
                      <select
                        value={config.loginBoxContentType || "event"}
                        onChange={(e) => updateConfig("loginBoxContentType", e.target.value)}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                      >
                        <option value="event">Event Name & Description</option>
                        <option value="logo">Logo</option>
                        <option value="text">Custom Text</option>
                      </select>
                      <p className="text-xs text-gray-500 mt-1">Choose what to display in the login box</p>
                    </div>

                    <div>
                      <Label>Login Box Header Background Color</Label>
                      <p className="text-xs text-gray-500 mt-1">Background color for the header area where logo/text is displayed</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.activityCardHeaderColor || "#3B82F6"}
                          onChange={(e) => updateConfig("activityCardHeaderColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.activityCardHeaderColor || "#3B82F6"}
                          onChange={(e) => updateConfig("activityCardHeaderColor", e.target.value)}
                          placeholder="#3B82F6"
                        />
                      </div>
                    </div>

                    {/* Logo Configuration */}
                    {config.loginBoxContentType === "logo" && (
                      <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-medium text-sm">Logo Settings</h4>
                        
                        <div>
                          <Label>Logo Image</Label>
                          <p className="text-xs text-gray-500 mt-1">Upload to S3 or enter URL for login box logo</p>
                          
                          <div className="mt-2">
                            <S3ImageUpload
                              value={config.loginBoxLogoUrl || ""}
                              onChange={(url) => updateConfig("loginBoxLogoUrl", url)}
                              onRemove={() => updateConfig("loginBoxLogoUrl", "")}
                              folder="landing-logos"
                              maxSize={10}
                              accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp"
                              placeholder="Click to upload logo (PNG, JPG, GIF, SVG, WebP)"
                            />
                          </div>
                          
                          <div className="mt-2">
                            <Label className="text-xs text-gray-600">Or enter Image URL</Label>
                            <div className="flex gap-2 mt-1">
                              <Input
                                type="url"
                                value={config.loginBoxLogoUrl || ""}
                                onChange={(e) => updateConfig("loginBoxLogoUrl", e.target.value)}
                                placeholder="https://example.com/logo.png"
                                className="flex-1"
                              />
                              {config.loginBoxLogoUrl && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => updateConfig("loginBoxLogoUrl", "")}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Horizontal Position</Label>
                            <select
                              value={config.loginBoxLogoHorizontalPosition || "center"}
                              onChange={(e) => updateConfig("loginBoxLogoHorizontalPosition", e.target.value)}
                              className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                            >
                              <option value="left">Left</option>
                              <option value="center">Center</option>
                              <option value="right">Right</option>
                            </select>
                          </div>
                          <div>
                            <Label>Vertical Position</Label>
                            <select
                              value={config.loginBoxLogoVerticalPosition || "top"}
                              onChange={(e) => updateConfig("loginBoxLogoVerticalPosition", e.target.value)}
                              className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                            >
                              <option value="top">Top</option>
                              <option value="bottom">Bottom</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Custom Text Configuration */}
                    {config.loginBoxContentType === "text" && (
                      <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-medium text-sm">Custom Text Settings</h4>
                        
                        <div>
                          <Label>Title</Label>
                          <Input
                            value={config.loginBoxCustomTitle || ""}
                            onChange={(e) => updateConfig("loginBoxCustomTitle", e.target.value)}
                            placeholder="Enter custom title"
                            className="mt-2"
                          />
                        </div>
                        
                        <div>
                          <Label>Subtitle</Label>
                          <textarea
                            value={config.loginBoxCustomSubtitle || ""}
                            onChange={(e) => updateConfig("loginBoxCustomSubtitle", e.target.value)}
                            placeholder="Enter custom subtitle/description"
                            className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg min-h-[80px]"
                          />
                        </div>
                      </div>
                    )}

                    {config.loginBoxContentType === "event" && (
                      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm text-blue-900">
                          <strong>Event Name & Description</strong> will be displayed from the event details.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {/* Post Landing Page Tab */}
          {activeTab === "post-landing" && (
            <>
              {/* Tab Info */}
                <div className="mb-6 p-4 bg-qsights-light border border-purple-200 rounded-lg">
                  <h3 className="text-sm font-semibold text-purple-900 mb-1">Post Landing Page</h3>
                  <p className="text-sm text-purple-700">Configure the page shown after participants log in but before they start the activity. This includes background styling and layout controls.</p>
                </div>

              <div className="grid lg:grid-cols-2 gap-6">

                {/* Header / Top Banner */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Header / Top Banner</CardTitle>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={config.bannerEnabled !== false}
                          onChange={(e) => updateConfig("bannerEnabled", e.target.checked)}
                          className="w-4 h-4 text-blue-600"
                        />
                        <span className="text-sm text-gray-600">Enable</span>
                      </label>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Banner configuration for post-login pages</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Banner Image</Label>
                      <p className="text-xs text-gray-500 mt-1">Upload banner image to S3 storage or enter an image URL</p>
                      <div className="mt-2 space-y-3">
                        <S3ImageUpload
                          value={config.bannerImageUrl || ""}
                          onChange={(url) => updateConfig("bannerImageUrl", url)}
                          onRemove={() => updateConfig("bannerImageUrl", "")}
                          folder="landing-banners"
                          maxSize={15}
                          accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp"
                          placeholder="Click to upload banner image (PNG, JPG, GIF, SVG, WebP)"
                          className={config.bannerEnabled === false ? "opacity-50 pointer-events-none" : ""}
                        />
                        <div>
                          <Label className="text-xs text-gray-600">Or enter Image URL</Label>
                          <Input
                            type="url"
                            value={config.bannerImageUrl || ""}
                            onChange={(e) => updateConfig("bannerImageUrl", e.target.value)}
                            placeholder="https://example.com/banner.png"
                            className="mt-1"
                            disabled={config.bannerEnabled === false}
                          />
                          <p className="text-xs text-gray-500 mt-1">Direct URL to your banner image (S3, CDN, or any public URL)</p>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Banner Background Color</Label>
                        <div className="flex items-center space-x-2 mt-2">
                          <input
                            type="color"
                            value={config.bannerBackgroundColor}
                            onChange={(e) => updateConfig("bannerBackgroundColor", e.target.value)}
                            className="h-10 w-20"
                            disabled={config.bannerEnabled === false}
                          />
                          <Input
                            value={config.bannerBackgroundColor}
                            onChange={(e) => updateConfig("bannerBackgroundColor", e.target.value)}
                            disabled={config.bannerEnabled === false}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Banner Height</Label>
                        <Input
                          value={config.bannerHeight}
                          onChange={(e) => updateConfig("bannerHeight", e.target.value)}
                          placeholder="200px"
                          className="mt-2"
                          disabled={config.bannerEnabled === false}
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Banner Text</Label>
                      <Input
                        value={config.bannerText || ""}
                        onChange={(e) => updateConfig("bannerText", e.target.value)}
                        placeholder="Optional banner text"
                        className="mt-2"
                        disabled={config.bannerEnabled === false}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Text Color</Label>
                        <div className="flex items-center space-x-2 mt-2">
                          <input
                            type="color"
                            value={config.bannerTextColor}
                            onChange={(e) => updateConfig("bannerTextColor", e.target.value)}
                            className="h-10 w-20"
                            disabled={config.bannerEnabled === false}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Text Position</Label>
                        <select
                          value={config.bannerTextPosition || "left"}
                          onChange={(e) => updateConfig("bannerTextPosition", e.target.value)}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                          disabled={config.bannerEnabled === false}
                        >
                          <option value="left">Left</option>
                          <option value="center">Center</option>
                          <option value="right">Right</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Banner Padding Left</Label>
                        <Input
                          value={config.bannerPaddingLeft || "24px"}
                          onChange={(e) => updateConfig("bannerPaddingLeft", e.target.value)}
                          placeholder="24px"
                          className="mt-2"
                          disabled={config.bannerEnabled === false}
                        />
                        <p className="text-xs text-gray-500 mt-1">Left spacing for banner content</p>
                      </div>
                      <div>
                        <Label>Banner Padding Right</Label>
                        <Input
                          value={config.bannerPaddingRight || "24px"}
                          onChange={(e) => updateConfig("bannerPaddingRight", e.target.value)}
                          placeholder="24px"
                          className="mt-2"
                          disabled={config.bannerEnabled === false}
                        />
                        <p className="text-xs text-gray-500 mt-1">Right spacing for banner content</p>
                      </div>
                    </div>
                    <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <label className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={config.bannerShowOnInnerPages || false}
                          onChange={(e) => updateConfig("bannerShowOnInnerPages", e.target.checked)}
                          className="w-4 h-4 text-blue-600"
                        />
                        <div>
                          <span className="text-sm font-medium text-gray-900">Show banner on inner pages</span>
                          <p className="text-xs text-gray-600 mt-0.5">Enable this to display the banner on survey/assessment/poll pages (not just landing page)</p>
                        </div>
                      </label>
                    </div>
                  </CardContent>
                </Card>

                {/* Background Styling */}
                <Card>
                  <CardHeader>
                    <CardTitle>Background Styling</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Configure the background for post-login pages</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Style Type</Label>
                      <select
                        value={config.backgroundStyle}
                        onChange={(e) => updateConfig("backgroundStyle", e.target.value)}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                      >
                        <option value="solid">Solid Color</option>
                        <option value="gradient">Gradient</option>
                        <option value="image">Background Image</option>
                      </select>
                    </div>

                    {config.backgroundStyle === "solid" && (
                      <div>
                        <Label>Background Color</Label>
                        <div className="flex items-center space-x-2 mt-2">
                          <input
                            type="color"
                            value={config.backgroundColor}
                            onChange={(e) => updateConfig("backgroundColor", e.target.value)}
                            className="h-10 w-20"
                          />
                          <Input
                            value={config.backgroundColor}
                            onChange={(e) => updateConfig("backgroundColor", e.target.value)}
                          />
                        </div>
                      </div>
                    )}

                    {config.backgroundStyle === "gradient" && (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Gradient From</Label>
                          <div className="flex items-center space-x-2 mt-2">
                            <input
                              type="color"
                              value={config.gradientFrom}
                              onChange={(e) => updateConfig("gradientFrom", e.target.value)}
                              className="h-10 w-20"
                            />
                            <Input
                              value={config.gradientFrom}
                              onChange={(e) => updateConfig("gradientFrom", e.target.value)}
                            />
                          </div>
                        </div>
                        <div>
                          <Label>Gradient To</Label>
                          <div className="flex items-center space-x-2 mt-2">
                            <input
                              type="color"
                              value={config.gradientTo}
                              onChange={(e) => updateConfig("gradientTo", e.target.value)}
                              className="h-10 w-20"
                            />
                            <Input
                              value={config.gradientTo}
                              onChange={(e) => updateConfig("gradientTo", e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {config.backgroundStyle === "image" && (
                      <div>
                        <Label>Background Image</Label>
                        <p className="text-xs text-gray-500 mt-1">Upload to S3 or enter URL for background image</p>
                        <div className="mt-2 space-y-3">
                          <S3ImageUpload
                            value={config.backgroundImageUrl || ""}
                            onChange={(url) => updateConfig("backgroundImageUrl", url)}
                            onRemove={() => updateConfig("backgroundImageUrl", "")}
                            folder="landing-backgrounds"
                            maxSize={15}
                            accept="image/png,image/jpeg,image/gif,image/webp"
                            placeholder="Click to upload background (PNG, JPG, GIF, WebP)"
                          />
                          
                          {/* URL Input */}
                          <div>
                            <Label className="text-xs text-gray-600">Or enter Image URL</Label>
                            <div className="flex gap-2 mt-1">
                              <Input
                                type="url"
                                value={config.backgroundImageUrl || ""}
                                onChange={(e) => updateConfig("backgroundImageUrl", e.target.value)}
                                placeholder="https://example.com/background.jpg"
                                className="flex-1"
                              />
                              {config.backgroundImageUrl && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => updateConfig("backgroundImageUrl", "")}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          </div>
                          
                          {/* Image Opacity */}
                          <div className="mt-4">
                            <Label>Image Opacity</Label>
                            <p className="text-xs text-gray-500 mt-1">Adjust background image transparency (0-100%)</p>
                            <div className="flex items-center gap-3 mt-2">
                              <input
                                type="range"
                                min="0"
                                max="100"
                                value={config.backgroundImageOpacity ?? 100}
                                onChange={(e) => updateConfig("backgroundImageOpacity", parseInt(e.target.value))}
                                className="flex-1"
                              />
                              <span className="text-sm font-medium text-gray-700 w-12 text-right">
                                {config.backgroundImageOpacity ?? 100}%
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Content Header Configuration */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Content Header</CardTitle>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={config.hideContentHeader === true}
                          onChange={(e) => updateConfig("hideContentHeader", e.target.checked)}
                          className="w-4 h-4 text-blue-600"
                        />
                        <span className="text-sm text-gray-600">Hide</span>
                      </label>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Configure what displays in the activity header section</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Header Content Type</Label>
                      <select
                        value={config.contentHeaderType || "event"}
                        onChange={(e) => updateConfig("contentHeaderType", e.target.value)}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                      >
                        <option value="event">Event Title & Description</option>
                        <option value="logo">Logo</option>
                        <option value="custom">Custom Text</option>
                      </select>
                      <p className="text-xs text-gray-500 mt-2">Choose what to display in the header section with START DATE, END DATE, and QUESTIONS</p>
                    </div>

                    {config.contentHeaderType === "logo" && (
                      <div className="space-y-4">
                        <div>
                          <Label>Logo Image</Label>
                          <p className="text-xs text-gray-500 mt-1">Upload to S3 or enter URL for content header logo</p>
                          <div className="mt-2 space-y-3">
                            <S3ImageUpload
                              value={config.contentHeaderLogoUrl || ""}
                              onChange={(url) => updateConfig("contentHeaderLogoUrl", url)}
                              onRemove={() => updateConfig("contentHeaderLogoUrl", "")}
                              folder="landing-logos"
                              maxSize={10}
                              accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp"
                              placeholder="Click to upload logo (PNG, JPG, GIF, SVG, WebP)"
                            />
                            
                            {/* URL Input */}
                            <div>
                              <Label className="text-xs text-gray-600">Or enter Logo URL</Label>
                              <div className="flex gap-2 mt-1">
                                <Input
                                  type="url"
                                  value={config.contentHeaderLogoUrl || ""}
                                  onChange={(e) => updateConfig("contentHeaderLogoUrl", e.target.value)}
                                  placeholder="https://example.com/logo.png"
                                  className="flex-1"
                                />
                                {config.contentHeaderLogoUrl && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => updateConfig("contentHeaderLogoUrl", "")}
                                  >
                                    <X className="w-4 h-4" />
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Logo Size */}
                        <div>
                          <Label>Logo Size</Label>
                          <select
                            value={config.contentHeaderLogoSize || "medium"}
                            onChange={(e) => updateConfig("contentHeaderLogoSize", e.target.value)}
                            className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                          >
                            <option value="small">Small (80px height)</option>
                            <option value="medium">Medium (120px height)</option>
                            <option value="large">Large (160px height)</option>
                          </select>
                        </div>
                      </div>
                    )}

                    {/* Header Background Styling - for all header types */}
                    <div className="border-t border-gray-200 pt-4 mt-4">
                      <Label className="text-base font-semibold">Header Background</Label>
                      <p className="text-xs text-gray-500 mt-1">Configure background color for the content header section</p>
                      
                      <div className="mt-3">
                        <Label>Background Style</Label>
                        <select
                          value={config.contentHeaderBackgroundStyle || "gradient"}
                          onChange={(e) => updateConfig("contentHeaderBackgroundStyle", e.target.value)}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        >
                          <option value="solid">Solid Color</option>
                          <option value="gradient">Gradient</option>
                        </select>
                      </div>

                      {config.contentHeaderBackgroundStyle === "solid" && (
                        <div className="mt-3">
                          <Label>Background Color</Label>
                          <div className="flex items-center space-x-2 mt-2">
                            <input
                              type="color"
                              value={config.contentHeaderBackgroundColor || "#3B82F6"}
                              onChange={(e) => updateConfig("contentHeaderBackgroundColor", e.target.value)}
                              className="h-10 w-20"
                            />
                            <Input
                              value={config.contentHeaderBackgroundColor || "#3B82F6"}
                              onChange={(e) => updateConfig("contentHeaderBackgroundColor", e.target.value)}
                            />
                          </div>
                        </div>
                      )}

                      {(config.contentHeaderBackgroundStyle === "gradient" || !config.contentHeaderBackgroundStyle) && (
                        <div className="grid grid-cols-2 gap-4 mt-3">
                          <div>
                            <Label>Gradient From</Label>
                            <div className="flex items-center space-x-2 mt-2">
                              <input
                                type="color"
                                value={config.contentHeaderGradientFrom || "#3B82F6"}
                                onChange={(e) => updateConfig("contentHeaderGradientFrom", e.target.value)}
                                className="h-10 w-20"
                              />
                              <Input
                                value={config.contentHeaderGradientFrom || "#3B82F6"}
                                onChange={(e) => updateConfig("contentHeaderGradientFrom", e.target.value)}
                                className="flex-1"
                              />
                            </div>
                          </div>
                          <div>
                            <Label>Gradient To</Label>
                            <div className="flex items-center space-x-2 mt-2">
                              <input
                                type="color"
                                value={config.contentHeaderGradientTo || "#7C3AED"}
                                onChange={(e) => updateConfig("contentHeaderGradientTo", e.target.value)}
                                className="h-10 w-20"
                              />
                              <Input
                                value={config.contentHeaderGradientTo || "#7C3AED"}
                                onChange={(e) => updateConfig("contentHeaderGradientTo", e.target.value)}
                                className="flex-1"
                              />
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {config.contentHeaderType === "custom" && (
                      <div className="space-y-4">
                        <div>
                          <Label>Custom Title</Label>
                          <Input
                            value={config.contentHeaderCustomTitle || ""}
                            onChange={(e) => updateConfig("contentHeaderCustomTitle", e.target.value)}
                            placeholder="Enter custom title"
                            className="mt-2"
                          />
                        </div>
                        <div>
                          <Label>Custom Subtitle</Label>
                          <Input
                            value={config.contentHeaderCustomSubtitle || ""}
                            onChange={(e) => updateConfig("contentHeaderCustomSubtitle", e.target.value)}
                            placeholder="Enter custom subtitle/description"
                            className="mt-2"
                          />
                        </div>
                      </div>
                    )}

                    {config.contentHeaderType === "event" && (
                      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <p className="text-sm text-blue-900">
                          <strong>Event Title & Description</strong> will be automatically displayed from the activity details.
                        </p>
                      </div>
                    )}
                    
                    {/* Selective Display Controls - NEW */}
                    {!config.hideContentHeader && (
                      <div className="border-t border-gray-200 pt-4 mt-4">
                        <Label className="text-base font-semibold mb-3 block">Display Controls</Label>
                        <p className="text-xs text-gray-500 mb-4">Select which elements to show in the content header</p>
                        
                        <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
                          <label className="flex items-center space-x-3 cursor-pointer hover:bg-white p-2 rounded transition-colors">
                            <input
                              type="checkbox"
                              checked={config.showContentHeaderTitle !== false}
                              onChange={(e) => updateConfig("showContentHeaderTitle", e.target.checked)}
                              className="w-4 h-4 text-blue-600 rounded"
                            />
                            <div>
                              <span className="text-sm font-medium text-gray-900">Show Title</span>
                              <p className="text-xs text-gray-500">Display event title or custom title/logo</p>
                            </div>
                          </label>
                          
                          <label className="flex items-center space-x-3 cursor-pointer hover:bg-white p-2 rounded transition-colors">
                            <input
                              type="checkbox"
                              checked={config.showContentHeaderStartDate !== false}
                              onChange={(e) => updateConfig("showContentHeaderStartDate", e.target.checked)}
                              className="w-4 h-4 text-blue-600 rounded"
                            />
                            <div>
                              <span className="text-sm font-medium text-gray-900">Show Start Date</span>
                              <p className="text-xs text-gray-500">Display activity start date</p>
                            </div>
                          </label>
                          
                          <label className="flex items-center space-x-3 cursor-pointer hover:bg-white p-2 rounded transition-colors">
                            <input
                              type="checkbox"
                              checked={config.showContentHeaderEndDate !== false}
                              onChange={(e) => updateConfig("showContentHeaderEndDate", e.target.checked)}
                              className="w-4 h-4 text-blue-600 rounded"
                            />
                            <div>
                              <span className="text-sm font-medium text-gray-900">Show End Date</span>
                              <p className="text-xs text-gray-500">Display activity end date</p>
                            </div>
                          </label>
                          
                          <label className="flex items-center space-x-3 cursor-pointer hover:bg-white p-2 rounded transition-colors">
                            <input
                              type="checkbox"
                              checked={config.showContentHeaderQuestions !== false}
                              onChange={(e) => updateConfig("showContentHeaderQuestions", e.target.checked)}
                              className="w-4 h-4 text-blue-600 rounded"
                            />
                            <div>
                              <span className="text-sm font-medium text-gray-900">Show Questions Count</span>
                              <p className="text-xs text-gray-500">Display total number of questions</p>
                            </div>
                          </label>
                        </div>
                        
                        {/* Warning when all options disabled */}
                        {!config.showContentHeaderTitle && !config.showContentHeaderStartDate && 
                         !config.showContentHeaderEndDate && !config.showContentHeaderQuestions && (
                          <div className="mt-3 p-3 bg-yellow-50 border border-yellow-300 rounded-lg">
                            <p className="text-sm text-yellow-800">
                              ⚠️ <strong>Warning:</strong> All display options are disabled. Consider enabling at least one element or hide the entire header.
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Footer Configuration */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Footer Configuration</CardTitle>
                      <label className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={config.footerEnabled !== false}
                          onChange={(e) => updateConfig("footerEnabled", e.target.checked)}
                          className="w-4 h-4 text-blue-600"
                        />
                        <span className="text-sm text-gray-600">Enable</span>
                      </label>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Footer configuration for post-login pages</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Footer Text</Label>
                      <Input
                        value={config.footerText}
                        onChange={(e) => updateConfig("footerText", e.target.value)}
                        placeholder="© 2025 All rights reserved"
                        className="mt-2"
                        disabled={config.footerEnabled === false}
                      />
                    </div>
                    <div>
                      <Label>Footer Text URL (Optional)</Label>
                      <Input
                        type="url"
                        value={config.footerTextUrl || ""}
                        onChange={(e) => updateConfig("footerTextUrl", e.target.value)}
                        placeholder="https://yoursite.com"
                        className="mt-2"
                        disabled={config.footerEnabled === false}
                      />
                      <p className="text-xs text-gray-500 mt-1">Make entire footer text clickable by adding a link URL</p>
                    </div>
                    
                    {/* Footer Hyperlink Configuration */}
                    <div className="border-t pt-4 mt-4">
                      <Label className="text-sm font-semibold">Footer Hyperlink (Optional)</Label>
                      <p className="text-xs text-gray-500 mt-1 mb-3">Add a hyperlink for specific words/phrases within your footer text</p>
                      
                      <div className="space-y-3">
                        <div>
                          <Label className="text-xs">Link Display Text</Label>
                          <Input
                            value={config.footerLinkText || ""}
                            onChange={(e) => updateConfig("footerLinkText", e.target.value)}
                            placeholder="e.g., BioQuest Solutions"
                            className="mt-1"
                            disabled={config.footerEnabled === false}
                          />
                          <p className="text-xs text-gray-500 mt-1">Text to be hyperlinked (will be styled in QSights color)</p>
                        </div>
                        <div>
                          <Label className="text-xs">Link URL</Label>
                          <Input
                            type="url"
                            value={config.footerLinkUrl || ""}
                            onChange={(e) => updateConfig("footerLinkUrl", e.target.value)}
                            placeholder="https://example.com"
                            className="mt-1"
                            disabled={config.footerEnabled === false}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Open Link In</Label>
                          <select
                            value={config.footerLinkTarget || "_blank"}
                            onChange={(e) => updateConfig("footerLinkTarget", e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            disabled={config.footerEnabled === false}
                          >
                            <option value="_blank">New Tab (_blank)</option>
                            <option value="_self">Same Tab (_self)</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Footer Text Position</Label>
                      <select
                        value={config.footerTextPosition || "left"}
                        onChange={(e) => updateConfig("footerTextPosition", e.target.value)}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        disabled={config.footerEnabled === false}
                      >
                        <option value="left">Left</option>
                        <option value="center">Center</option>
                        <option value="right">Right</option>
                      </select>
                    </div>
                    <div>
                      <Label>Footer Logo</Label>
                      <p className="text-xs text-gray-500 mt-1">Upload to S3 or enter URL for footer logo</p>
                      <div className="mt-2 space-y-3">
                        <S3ImageUpload
                          value={config.footerLogoUrl || ""}
                          onChange={(url) => updateConfig("footerLogoUrl", url)}
                          onRemove={() => updateConfig("footerLogoUrl", "")}
                          folder="landing-logos"
                          maxSize={10}
                          accept="image/png,image/jpeg,image/gif,image/svg+xml,image/webp"
                          placeholder="Click to upload footer logo (PNG, JPG, GIF, SVG, WebP)"
                        />
                        <div>
                          <Label className="text-xs text-gray-600">Or enter Logo URL</Label>
                          <div className="flex gap-2 mt-1">
                            <Input
                              type="url"
                              value={config.footerLogoUrl || ""}
                              onChange={(e) => updateConfig("footerLogoUrl", e.target.value)}
                              placeholder="https://example.com/footer-logo.png"
                              className="flex-1"
                              disabled={config.footerEnabled === false}
                            />
                            {config.footerLogoUrl && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateConfig("footerLogoUrl", "")}
                                disabled={config.footerEnabled === false}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Footer Logo Size</Label>
                        <select
                          value={config.footerLogoSize || "medium"}
                          onChange={(e) => updateConfig("footerLogoSize", e.target.value)}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                          disabled={config.footerEnabled === false}
                        >
                          <option value="small">Small</option>
                          <option value="medium">Medium</option>
                          <option value="large">Large</option>
                        </select>
                      </div>
                      <div>
                        <Label>Footer Logo Position</Label>
                        <select
                          value={config.footerLogoPosition || "left"}
                          onChange={(e) => updateConfig("footerLogoPosition", e.target.value)}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                          disabled={config.footerEnabled === false}
                        >
                          <option value="left">Left</option>
                          <option value="center">Center</option>
                          <option value="right">Right</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label>Text Color</Label>
                        <div className="flex items-center space-x-2 mt-2">
                          <input
                            type="color"
                            value={config.footerTextColor}
                            onChange={(e) => updateConfig("footerTextColor", e.target.value)}
                            className="h-10 w-20"
                            disabled={config.footerEnabled === false}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Background Color</Label>
                        <div className="flex items-center space-x-2 mt-2">
                          <input
                            type="color"
                            value={config.footerBackgroundColor}
                            onChange={(e) => updateConfig("footerBackgroundColor", e.target.value)}
                            className="h-10 w-20"
                            disabled={config.footerEnabled === false}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Height</Label>
                        <Input
                          value={config.footerHeight}
                          onChange={(e) => updateConfig("footerHeight", e.target.value)}
                          placeholder="80px"
                          className="mt-2"
                          disabled={config.footerEnabled === false}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {/* Post Session Registration Tab */}
          {activeTab === "post-session-reg" && (
            <>
              {/* Tab Info */}
              <div className="mb-6 p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                <h3 className="text-sm font-semibold text-indigo-900 mb-1">Post Session Registration Page</h3>
                <p className="text-sm text-indigo-700">Configure the registration page shown after participants complete their questionnaire but before final submission. This is used for triggered email flows where participants answer first and register later.</p>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                {/* Page Content Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle>Page Content</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Customize the text and messages shown on the registration page</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Page Title</Label>
                      <p className="text-xs text-gray-500 mt-1">Main heading shown at the top of the registration form</p>
                      <Input
                        value={config.postSessionRegTitle}
                        onChange={(e) => updateConfig("postSessionRegTitle", e.target.value)}
                        placeholder="Complete Your Registration"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Subtitle</Label>
                      <p className="text-xs text-gray-500 mt-1">Secondary heading below the title</p>
                      <Input
                        value={config.postSessionRegSubtitle}
                        onChange={(e) => updateConfig("postSessionRegSubtitle", e.target.value)}
                        placeholder="One more step to finish!"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Description</Label>
                      <p className="text-xs text-gray-500 mt-1">Explanatory text shown above the form fields</p>
                      <textarea
                        value={config.postSessionRegDescription}
                        onChange={(e) => updateConfig("postSessionRegDescription", e.target.value)}
                        placeholder="Please provide your details below to complete your participation."
                        className="w-full mt-2 p-2 border border-gray-300 rounded-md min-h-[80px]"
                      />
                    </div>
                    <div>
                      <Label>Submit Button Text</Label>
                      <p className="text-xs text-gray-500 mt-1">Text displayed on the submit button</p>
                      <Input
                        value={config.postSessionRegButtonText}
                        onChange={(e) => updateConfig("postSessionRegButtonText", e.target.value)}
                        placeholder="Submit Registration"
                        className="mt-2"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Color Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle>Colors & Styling</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Customize colors for text and UI elements</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Title Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegTitleColor}
                          onChange={(e) => updateConfig("postSessionRegTitleColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegTitleColor}
                          onChange={(e) => updateConfig("postSessionRegTitleColor", e.target.value)}
                          placeholder="#1F2937"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Description Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegDescriptionColor}
                          onChange={(e) => updateConfig("postSessionRegDescriptionColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegDescriptionColor}
                          onChange={(e) => updateConfig("postSessionRegDescriptionColor", e.target.value)}
                          placeholder="#6B7280"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Submit Button Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegButtonColor}
                          onChange={(e) => updateConfig("postSessionRegButtonColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegButtonColor}
                          onChange={(e) => updateConfig("postSessionRegButtonColor", e.target.value)}
                          placeholder="#3B82F6"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Form Background Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegFormBackgroundColor}
                          onChange={(e) => updateConfig("postSessionRegFormBackgroundColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegFormBackgroundColor}
                          onChange={(e) => updateConfig("postSessionRegFormBackgroundColor", e.target.value)}
                          placeholder="#FFFFFF"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Form Border Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegFormBorderColor}
                          onChange={(e) => updateConfig("postSessionRegFormBorderColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegFormBorderColor}
                          onChange={(e) => updateConfig("postSessionRegFormBorderColor", e.target.value)}
                          placeholder="#E5E7EB"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Background Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle>Page Background</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Set the background color or image for the page</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Background Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegBackgroundColor}
                          onChange={(e) => updateConfig("postSessionRegBackgroundColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegBackgroundColor}
                          onChange={(e) => updateConfig("postSessionRegBackgroundColor", e.target.value)}
                          placeholder="#F3F4F6"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Background Image URL</Label>
                      <p className="text-xs text-gray-500 mt-1">Optional background image (leave empty for solid color)</p>
                      <Input
                        value={config.postSessionRegBackgroundImageUrl}
                        onChange={(e) => updateConfig("postSessionRegBackgroundImageUrl", e.target.value)}
                        placeholder="https://example.com/background.jpg"
                        className="mt-2"
                      />
                    </div>
                    {config.postSessionRegBackgroundImageUrl && (
                      <div>
                        <Label>Background Image Opacity (%)</Label>
                        <div className="flex items-center space-x-4 mt-2">
                          <input
                            type="range"
                            min="0"
                            max="100"
                            value={config.postSessionRegBackgroundOpacity}
                            onChange={(e) => updateConfig("postSessionRegBackgroundOpacity", Number(e.target.value))}
                            className="flex-1"
                          />
                          <span className="text-sm font-medium w-12 text-center">{config.postSessionRegBackgroundOpacity}%</span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Preview Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>Preview</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">See how your registration page will look</p>
                  </CardHeader>
                  <CardContent>
                    <div 
                      className="relative rounded-lg overflow-hidden border" 
                      style={{ 
                        backgroundColor: config.postSessionRegBackgroundColor,
                        backgroundImage: config.postSessionRegBackgroundImageUrl ? `url(${config.postSessionRegBackgroundImageUrl})` : 'none',
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                        minHeight: '400px'
                      }}
                    >
                      {config.postSessionRegBackgroundImageUrl && (
                        <div 
                          className="absolute inset-0" 
                          style={{ 
                            backgroundColor: config.postSessionRegBackgroundColor,
                            opacity: (100 - config.postSessionRegBackgroundOpacity) / 100 
                          }}
                        />
                      )}
                      <div className="relative p-8 flex items-center justify-center min-h-[400px]">
                        <div 
                          className="max-w-md w-full rounded-lg shadow-lg p-6" 
                          style={{ 
                            backgroundColor: config.postSessionRegFormBackgroundColor,
                            borderColor: config.postSessionRegFormBorderColor,
                            borderWidth: '1px'
                          }}
                        >
                          <h2 className="text-2xl font-bold mb-2" style={{ color: config.postSessionRegTitleColor }}>
                            {config.postSessionRegTitle || "Complete Your Registration"}
                          </h2>
                          {config.postSessionRegSubtitle && (
                            <p className="text-lg mb-4" style={{ color: config.postSessionRegDescriptionColor }}>
                              {config.postSessionRegSubtitle}
                            </p>
                          )}
                          {config.postSessionRegDescription && (
                            <p className="text-sm mb-6" style={{ color: config.postSessionRegDescriptionColor }}>
                              {config.postSessionRegDescription}
                            </p>
                          )}
                          <div className="space-y-4 mb-6">
                            <div>
                              <div className="text-sm font-medium text-gray-700 mb-1">Name</div>
                              <div className="border border-gray-300 rounded px-3 py-2 text-gray-400 text-sm">John Doe</div>
                            </div>
                            <div>
                              <div className="text-sm font-medium text-gray-700 mb-1">Email</div>
                              <div className="border border-gray-300 rounded px-3 py-2 text-gray-400 text-sm">john@example.com</div>
                            </div>
                          </div>
                          <button 
                            className="w-full py-2 px-4 rounded text-white font-medium"
                            style={{ backgroundColor: config.postSessionRegButtonColor }}
                            disabled
                          >
                            {config.postSessionRegButtonText || "Submit Registration"}
                          </button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {/* Post Session Registration Tab */}
          {activeTab === "post-session-reg" && (
            <>
              {/* Tab Info */}
              <div className="mb-6 p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                <h3 className="text-sm font-semibold text-indigo-900 mb-1">Post Session Registration Page</h3>
                <p className="text-sm text-indigo-700">Configure the registration page shown after participants complete their questionnaire but before final submission. This is used for triggered email flows where participants answer first and register later.</p>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                {/* Page Content Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle>Page Content</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Customize the text and messages shown on the registration page</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Page Title</Label>
                      <p className="text-xs text-gray-500 mt-1">Main heading shown at the top of the registration form</p>
                      <Input
                        value={config.postSessionRegTitle}
                        onChange={(e) => updateConfig("postSessionRegTitle", e.target.value)}
                        placeholder="Complete Your Registration"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Subtitle</Label>
                      <p className="text-xs text-gray-500 mt-1">Secondary heading below the title</p>
                      <Input
                        value={config.postSessionRegSubtitle}
                        onChange={(e) => updateConfig("postSessionRegSubtitle", e.target.value)}
                        placeholder="One more step to finish!"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Description</Label>
                      <p className="text-xs text-gray-500 mt-1">Explanatory text shown above the form fields</p>
                      <textarea
                        value={config.postSessionRegDescription}
                        onChange={(e) => updateConfig("postSessionRegDescription", e.target.value)}
                        placeholder="Please provide your details below to complete your participation."
                        className="w-full mt-2 p-2 border border-gray-300 rounded-md min-h-[80px]"
                      />
                    </div>
                    <div>
                      <Label>Submit Button Text</Label>
                      <p className="text-xs text-gray-500 mt-1">Text displayed on the submit button</p>
                      <Input
                        value={config.postSessionRegButtonText}
                        onChange={(e) => updateConfig("postSessionRegButtonText", e.target.value)}
                        placeholder="Submit Registration"
                        className="mt-2"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Color Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle>Colors & Styling</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Customize colors for text and UI elements</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Title Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegTitleColor}
                          onChange={(e) => updateConfig("postSessionRegTitleColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegTitleColor}
                          onChange={(e) => updateConfig("postSessionRegTitleColor", e.target.value)}
                          placeholder="#1F2937"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Description Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegDescriptionColor}
                          onChange={(e) => updateConfig("postSessionRegDescriptionColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegDescriptionColor}
                          onChange={(e) => updateConfig("postSessionRegDescriptionColor", e.target.value)}
                          placeholder="#6B7280"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Submit Button Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegButtonColor}
                          onChange={(e) => updateConfig("postSessionRegButtonColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegButtonColor}
                          onChange={(e) => updateConfig("postSessionRegButtonColor", e.target.value)}
                          placeholder="#3B82F6"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Form Background Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegFormBackgroundColor}
                          onChange={(e) => updateConfig("postSessionRegFormBackgroundColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegFormBackgroundColor}
                          onChange={(e) => updateConfig("postSessionRegFormBackgroundColor", e.target.value)}
                          placeholder="#FFFFFF"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Form Border Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegFormBorderColor}
                          onChange={(e) => updateConfig("postSessionRegFormBorderColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegFormBorderColor}
                          onChange={(e) => updateConfig("postSessionRegFormBorderColor", e.target.value)}
                          placeholder="#E5E7EB"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Background Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle>Page Background</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Set the background color or image for the page</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Background Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.postSessionRegBackgroundColor}
                          onChange={(e) => updateConfig("postSessionRegBackgroundColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.postSessionRegBackgroundColor}
                          onChange={(e) => updateConfig("postSessionRegBackgroundColor", e.target.value)}
                          placeholder="#F3F4F6"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Background Image URL</Label>
                      <p className="text-xs text-gray-500 mt-1">Optional background image (leave empty for solid color)</p>
                      <Input
                        value={config.postSessionRegBackgroundImageUrl}
                        onChange={(e) => updateConfig("postSessionRegBackgroundImageUrl", e.target.value)}
                        placeholder="https://example.com/background.jpg"
                        className="mt-2"
                      />
                    </div>
                    {config.postSessionRegBackgroundImageUrl && (
                      <div>
                        <Label>Background Image Opacity (%)</Label>
                        <div className="flex items-center space-x-4 mt-2">
                          <input
                            type="range"
                            min="0"
                            max="100"
                            value={config.postSessionRegBackgroundOpacity}
                            onChange={(e) => updateConfig("postSessionRegBackgroundOpacity", Number(e.target.value))}
                            className="flex-1"
                          />
                          <span className="text-sm font-medium w-12 text-center">{config.postSessionRegBackgroundOpacity}%</span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Preview Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>Preview</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">See how your registration page will look</p>
                  </CardHeader>
                  <CardContent>
                    <div 
                      className="relative rounded-lg overflow-hidden border" 
                      style={{ 
                        backgroundColor: config.postSessionRegBackgroundColor,
                        backgroundImage: config.postSessionRegBackgroundImageUrl ? `url(${config.postSessionRegBackgroundImageUrl})` : 'none',
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                        minHeight: '400px'
                      }}
                    >
                      {config.postSessionRegBackgroundImageUrl && (
                        <div 
                          className="absolute inset-0" 
                          style={{ 
                            backgroundColor: config.postSessionRegBackgroundColor,
                            opacity: (100 - config.postSessionRegBackgroundOpacity) / 100 
                          }}
                        />
                      )}
                      <div className="relative p-8 flex items-center justify-center min-h-[400px]">
                        <div 
                          className="max-w-md w-full rounded-lg shadow-lg p-6" 
                          style={{ 
                            backgroundColor: config.postSessionRegFormBackgroundColor,
                            borderColor: config.postSessionRegFormBorderColor,
                            borderWidth: '1px'
                          }}
                        >
                          <h2 className="text-2xl font-bold mb-2" style={{ color: config.postSessionRegTitleColor }}>
                            {config.postSessionRegTitle || "Complete Your Registration"}
                          </h2>
                          {config.postSessionRegSubtitle && (
                            <p className="text-lg mb-4" style={{ color: config.postSessionRegDescriptionColor }}>
                              {config.postSessionRegSubtitle}
                            </p>
                          )}
                          {config.postSessionRegDescription && (
                            <p className="text-sm mb-6" style={{ color: config.postSessionRegDescriptionColor }}>
                              {config.postSessionRegDescription}
                            </p>
                          )}
                          <div className="space-y-4 mb-6">
                            <div>
                              <div className="text-sm font-medium text-gray-700 mb-1">Name</div>
                              <div className="border border-gray-300 rounded px-3 py-2 text-gray-400 text-sm">John Doe</div>
                            </div>
                            <div>
                              <div className="text-sm font-medium text-gray-700 mb-1">Email</div>
                              <div className="border border-gray-300 rounded px-3 py-2 text-gray-400 text-sm">john@example.com</div>
                            </div>
                          </div>
                          <button 
                            className="w-full py-2 px-4 rounded text-white font-medium"
                            style={{ backgroundColor: config.postSessionRegButtonColor }}
                            disabled
                          >
                            {config.postSessionRegButtonText || "Submit Registration"}
                          </button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {/* Thank You Page Tab */}
          {activeTab === "thank-you" && (
            <>
              {/* Tab Info */}
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <h3 className="text-sm font-semibold text-green-900 mb-1">Thank You Page</h3>
                <p className="text-sm text-green-700">Configure the completion message shown after participants successfully submit their responses. This applies globally to Surveys, Polls, and Evaluations.</p>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                {/* Thank You Page Configuration */}
                <Card>
                  <CardHeader>
                    <CardTitle>Thank You Page Configuration</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Customize the thank you message and appearance shown after successful submission</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Thank You Title</Label>
                      <Input
                        value={config.thankYouTitle}
                        onChange={(e) => updateConfig("thankYouTitle", e.target.value)}
                        placeholder="Thank you!"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Main Message</Label>
                      <Input
                        value={config.thankYouMessage}
                        onChange={(e) => updateConfig("thankYouMessage", e.target.value)}
                        placeholder="Your response has been submitted"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Sub Message</Label>
                      <Input
                        value={config.thankYouSubMessage}
                        onChange={(e) => updateConfig("thankYouSubMessage", e.target.value)}
                        placeholder="We appreciate your participation"
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label>Icon Color</Label>
                      <p className="text-xs text-gray-500 mt-1">Color of the checkmark icon</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.thankYouIconColor}
                          onChange={(e) => updateConfig("thankYouIconColor", e.target.value)}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.thankYouIconColor}
                          onChange={(e) => updateConfig("thankYouIconColor", e.target.value)}
                          placeholder="#10B981"
                        />
                      </div>
                    </div>
                    <div className="space-y-3 mt-4">
                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <label className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={config.thankYouShowBanner !== false}
                            onChange={(e) => updateConfig("thankYouShowBanner", e.target.checked)}
                            className="w-4 h-4 text-blue-600"
                          />
                          <div>
                            <span className="text-sm font-medium text-gray-900">Display Top Banner</span>
                            <p className="text-xs text-blue-700 mt-0.5">Show the configured top banner on Thank You page</p>
                          </div>
                        </label>
                      </div>
                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <label className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={config.thankYouShowFooter !== false}
                            onChange={(e) => updateConfig("thankYouShowFooter", e.target.checked)}
                            className="w-4 h-4 text-blue-600"
                          />
                          <div>
                            <span className="text-sm font-medium text-gray-900">Display Footer</span>
                            <p className="text-xs text-blue-700 mt-0.5">Show the configured footer on Thank You page</p>
                          </div>
                        </label>
                      </div>
                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <label className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={config.thankYouShowConfirmation !== false}
                            onChange={(e) => updateConfig("thankYouShowConfirmation", e.target.checked)}
                            className="w-4 h-4 text-blue-600"
                          />
                          <div>
                            <span className="text-sm font-medium text-gray-900">Show email confirmation message</span>
                                                      <p className="text-xs text-gray-600 mt-0.5">Display "A confirmation has been sent to your email"</p>
                        </div>
                      </label>
                      </div>
                    </div>
                    <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                      <label className="flex items-center space-x-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={config.enableTakeEventAgainButton === true}
                          onChange={(e) => updateConfig("enableTakeEventAgainButton", e.target.checked)}
                          className="w-4 h-4 text-green-600"
                        />
                        <div>
                          <span className="text-sm font-medium text-gray-900">Enable "Take Event Again" Button (Kiosk Mode)</span>
                          <p className="text-xs text-gray-600 mt-0.5">Allow multiple participants to use same device (iPad/tablet). Button restarts event for new participant.</p>
                          <p className="text-xs text-orange-600 mt-1">⚠️ Only works for Registration/Anonymous/Preview links. Hidden for email invitations.</p>
                        </div>
                      </label>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {/* CSS & Fonts Tab */}
          {activeTab === "css-fonts" && (
            <>
              <div className="mb-6 p-4 bg-qsights-light border border-purple-200 rounded-lg">
                <h3 className="text-sm font-semibold text-purple-900 mb-1">CSS & Fonts</h3>
                <p className="text-sm text-purple-700">Customize typography and add custom CSS for advanced styling.</p>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                {/* Typography Settings */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Code className="w-4 h-4 text-purple-700" />
                      <CardTitle>CSS & Fonts</CardTitle>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Advanced styling control for your landing pages</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600">Use the options below to customize typography, fonts, and add custom CSS for advanced styling.</p>
                  </CardContent>
                </Card>

                {/* Theme Presets */}
                <Card>
                  <CardHeader>
                    <CardTitle>Theme Presets</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Quick-apply predefined style presets</p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { id: "default", name: "Default", description: "Standard professional styling" },
                        { id: "professional", name: "Professional", description: "Clean corporate look" },
                        { id: "minimal", name: "Minimal", description: "Simple and clean design" },
                        { id: "high-contrast", name: "High Contrast", description: "Accessibility-friendly" },
                      ].map((preset) => (
                        <button
                          key={preset.id}
                          onClick={() => {
                            updateConfig("cssThemePreset", preset.id);
                            // Apply preset values
                            if (preset.id === "professional") {
                              setConfig(prev => ({
                                ...prev,
                                cssThemePreset: preset.id,
                                cssTypography: { ...prev.cssTypography, primaryFontFamily: "inter", fontWeight: "normal", baseFontSize: "15px" },
                                cssHeadings: { ...prev.cssHeadings, headingFontWeight: "semibold", headingColor: "#111827", letterSpacing: "-0.02em" },
                                cssButtons: { ...prev.cssButtons, buttonBorderRadius: "6px", buttonFontSize: "14px" },
                              }));
                            } else if (preset.id === "minimal") {
                              setConfig(prev => ({
                                ...prev,
                                cssThemePreset: preset.id,
                                cssTypography: { ...prev.cssTypography, primaryFontFamily: "system", fontWeight: "normal", baseFontSize: "16px" },
                                cssHeadings: { ...prev.cssHeadings, headingFontWeight: "medium", headingColor: "#374151", letterSpacing: "normal" },
                                cssButtons: { ...prev.cssButtons, buttonBorderRadius: "4px", buttonFontSize: "14px" },
                              }));
                            } else if (preset.id === "high-contrast") {
                              setConfig(prev => ({
                                ...prev,
                                cssThemePreset: preset.id,
                                cssTypography: { ...prev.cssTypography, primaryFontFamily: "system", fontWeight: "medium", baseFontSize: "18px", lineHeight: "1.6" },
                                cssHeadings: { ...prev.cssHeadings, headingFontWeight: "bold", headingColor: "#000000", letterSpacing: "normal" },
                                cssButtons: { ...prev.cssButtons, buttonBorderRadius: "4px", buttonFontSize: "16px" },
                              }));
                            } else {
                              setConfig(prev => ({
                                ...prev,
                                cssThemePreset: preset.id,
                                cssTypography: defaultConfig.cssTypography,
                                cssHeadings: defaultConfig.cssHeadings,
                                cssButtons: defaultConfig.cssButtons,
                              }));
                            }
                            toast({ title: "Theme Applied", description: `${preset.name} theme has been applied.`, duration: 2000 });
                          }}
                          className={`p-3 border-2 rounded-lg text-left transition-all ${
                            config.cssThemePreset === preset.id
                              ? "border-qsights-cyan bg-qsights-light"
                              : "border-gray-200 hover:border-purple-400"
                          }`}
                        >
                          <div className="font-medium text-sm text-gray-900">{preset.name}</div>
                          <div className="text-xs text-gray-500 mt-0.5">{preset.description}</div>
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Typography (Global) */}
                <Card>
                  <CardHeader>
                    <CardTitle>Typography (Global)</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Configure fonts for all event pages</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Primary Font Family</Label>
                      <select
                        value={config.cssTypography?.primaryFontFamily || "system"}
                        onChange={(e) => setConfig(prev => ({
                          ...prev,
                          cssTypography: { ...prev.cssTypography, primaryFontFamily: e.target.value }
                        }))}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                      >
                        <optgroup label="System Fonts">
                          <option value="system">System Default</option>
                          <option value="sans-serif">Sans-Serif</option>
                          <option value="serif">Serif</option>
                          <option value="monospace">Monospace</option>
                        </optgroup>
                        <optgroup label="Google Fonts">
                          <option value="inter">Inter</option>
                          <option value="roboto">Roboto</option>
                          <option value="poppins">Poppins</option>
                          <option value="open-sans">Open Sans</option>
                          <option value="lato">Lato</option>
                          <option value="montserrat">Montserrat</option>
                          <option value="nunito">Nunito</option>
                          <option value="raleway">Raleway</option>
                          <option value="source-sans-pro">Source Sans Pro</option>
                          <option value="ubuntu">Ubuntu</option>
                        </optgroup>
                        <optgroup label="Custom">
                          <option value="custom">Custom Google Font URL</option>
                        </optgroup>
                      </select>
                    </div>
                    
                    {config.cssTypography?.primaryFontFamily === "custom" && (
                      <div>
                        <Label>Custom Google Font URL</Label>
                        <Input
                          value={config.cssTypography?.customGoogleFontUrl || ""}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssTypography: { ...prev.cssTypography, customGoogleFontUrl: e.target.value }
                          }))}
                          placeholder="https://fonts.googleapis.com/css2?family=YourFont:wght@400;500;700&display=swap"
                          className="mt-2"
                        />
                        <p className="text-xs text-gray-500 mt-1">Paste the full Google Fonts embed URL</p>
                      </div>
                    )}
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Font Weight</Label>
                        <select
                          value={config.cssTypography?.fontWeight || "normal"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssTypography: { ...prev.cssTypography, fontWeight: e.target.value }
                          }))}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        >
                          <option value="light">Light (300)</option>
                          <option value="normal">Normal (400)</option>
                          <option value="medium">Medium (500)</option>
                          <option value="semibold">Semibold (600)</option>
                          <option value="bold">Bold (700)</option>
                        </select>
                      </div>
                      <div>
                        <Label>Base Font Size</Label>
                        <select
                          value={config.cssTypography?.baseFontSize || "16px"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssTypography: { ...prev.cssTypography, baseFontSize: e.target.value }
                          }))}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        >
                          <option value="14px">14px (Small)</option>
                          <option value="15px">15px</option>
                          <option value="16px">16px (Default)</option>
                          <option value="17px">17px</option>
                          <option value="18px">18px (Large)</option>
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Line Height</Label>
                      <select
                        value={config.cssTypography?.lineHeight || "1.5"}
                        onChange={(e) => setConfig(prev => ({
                          ...prev,
                          cssTypography: { ...prev.cssTypography, lineHeight: e.target.value }
                        }))}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                      >
                        <option value="1.3">1.3 (Compact)</option>
                        <option value="1.4">1.4</option>
                        <option value="1.5">1.5 (Default)</option>
                        <option value="1.6">1.6</option>
                        <option value="1.75">1.75 (Relaxed)</option>
                      </select>
                    </div>
                    
                    {/* Font Preview */}
                    <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                      <p className="text-xs text-gray-500 mb-2">Font Preview</p>
                      <p 
                        style={{ 
                          fontFamily: config.cssTypography?.primaryFontFamily === "system" ? "system-ui, sans-serif" : config.cssTypography?.primaryFontFamily,
                          fontWeight: config.cssTypography?.fontWeight === "bold" ? 700 : config.cssTypography?.fontWeight === "semibold" ? 600 : config.cssTypography?.fontWeight === "medium" ? 500 : config.cssTypography?.fontWeight === "light" ? 300 : 400,
                          fontSize: config.cssTypography?.baseFontSize || "16px",
                          lineHeight: config.cssTypography?.lineHeight || "1.5"
                        }}
                        className="text-gray-900"
                      >
                        The quick brown fox jumps over the lazy dog. 0123456789
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Heading Styles */}
                <Card>
                  <CardHeader>
                    <CardTitle>Heading Styles</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Configure heading typography</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label>H1 Size</Label>
                        <Input
                          value={config.cssHeadings?.h1Size || "2.25rem"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssHeadings: { ...prev.cssHeadings, h1Size: e.target.value }
                          }))}
                          placeholder="2.25rem"
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label>H2 Size</Label>
                        <Input
                          value={config.cssHeadings?.h2Size || "1.875rem"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssHeadings: { ...prev.cssHeadings, h2Size: e.target.value }
                          }))}
                          placeholder="1.875rem"
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label>H3 Size</Label>
                        <Input
                          value={config.cssHeadings?.h3Size || "1.5rem"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssHeadings: { ...prev.cssHeadings, h3Size: e.target.value }
                          }))}
                          placeholder="1.5rem"
                          className="mt-2"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Heading Font Weight</Label>
                        <select
                          value={config.cssHeadings?.headingFontWeight || "bold"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssHeadings: { ...prev.cssHeadings, headingFontWeight: e.target.value }
                          }))}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        >
                          <option value="normal">Normal (400)</option>
                          <option value="medium">Medium (500)</option>
                          <option value="semibold">Semibold (600)</option>
                          <option value="bold">Bold (700)</option>
                          <option value="extrabold">Extra Bold (800)</option>
                        </select>
                      </div>
                      <div>
                        <Label>Letter Spacing</Label>
                        <select
                          value={config.cssHeadings?.letterSpacing || "normal"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssHeadings: { ...prev.cssHeadings, letterSpacing: e.target.value }
                          }))}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        >
                          <option value="-0.05em">Tight (-0.05em)</option>
                          <option value="-0.02em">Slightly Tight (-0.02em)</option>
                          <option value="normal">Normal</option>
                          <option value="0.02em">Slightly Wide (0.02em)</option>
                          <option value="0.05em">Wide (0.05em)</option>
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Heading Color</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <input
                          type="color"
                          value={config.cssHeadings?.headingColor || "#1F2937"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssHeadings: { ...prev.cssHeadings, headingColor: e.target.value }
                          }))}
                          className="h-10 w-20"
                        />
                        <Input
                          value={config.cssHeadings?.headingColor || "#1F2937"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssHeadings: { ...prev.cssHeadings, headingColor: e.target.value }
                          }))}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Button Styles */}
                <Card>
                  <CardHeader>
                    <CardTitle>Button Styles</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Configure button appearance</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Button Font Family</Label>
                        <select
                          value={config.cssButtons?.buttonFontFamily || "inherit"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssButtons: { ...prev.cssButtons, buttonFontFamily: e.target.value }
                          }))}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        >
                          <option value="inherit">Inherit from Typography</option>
                          <option value="system">System Default</option>
                          <option value="inter">Inter</option>
                          <option value="roboto">Roboto</option>
                        </select>
                      </div>
                      <div>
                        <Label>Button Font Size</Label>
                        <select
                          value={config.cssButtons?.buttonFontSize || "14px"}
                          onChange={(e) => setConfig(prev => ({
                            ...prev,
                            cssButtons: { ...prev.cssButtons, buttonFontSize: e.target.value }
                          }))}
                          className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                        >
                          <option value="12px">12px (Small)</option>
                          <option value="14px">14px (Default)</option>
                          <option value="16px">16px (Large)</option>
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Button Border Radius</Label>
                      <select
                        value={config.cssButtons?.buttonBorderRadius || "8px"}
                        onChange={(e) => setConfig(prev => ({
                          ...prev,
                          cssButtons: { ...prev.cssButtons, buttonBorderRadius: e.target.value }
                        }))}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg"
                      >
                        <option value="0px">Square (0px)</option>
                        <option value="4px">Slightly Rounded (4px)</option>
                        <option value="6px">Rounded (6px)</option>
                        <option value="8px">More Rounded (8px)</option>
                        <option value="12px">Very Rounded (12px)</option>
                        <option value="999px">Pill (999px)</option>
                      </select>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Hover Opacity (%)</Label>
                        <div className="space-y-2 mt-2">
                          <input
                            type="range"
                            min="50"
                            max="100"
                            value={config.cssButtons?.buttonHoverOpacity || 90}
                            onChange={(e) => setConfig(prev => ({
                              ...prev,
                              cssButtons: { ...prev.cssButtons, buttonHoverOpacity: parseInt(e.target.value) }
                            }))}
                            className="w-full"
                          />
                          <div className="text-xs text-gray-500 text-center">{config.cssButtons?.buttonHoverOpacity || 90}%</div>
                        </div>
                      </div>
                      <div>
                        <Label>Disabled Opacity (%)</Label>
                        <div className="space-y-2 mt-2">
                          <input
                            type="range"
                            min="30"
                            max="80"
                            value={config.cssButtons?.buttonDisabledOpacity || 50}
                            onChange={(e) => setConfig(prev => ({
                              ...prev,
                              cssButtons: { ...prev.cssButtons, buttonDisabledOpacity: parseInt(e.target.value) }
                            }))}
                            className="w-full"
                          />
                          <div className="text-xs text-gray-500 text-center">{config.cssButtons?.buttonDisabledOpacity || 50}%</div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Button Preview */}
                    <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                      <p className="text-xs text-gray-500 mb-3">Button Preview</p>
                      <div className="flex items-center gap-4">
                        <button
                          style={{
                            backgroundColor: config.loginButtonColor || "#3B82F6",
                            borderRadius: config.cssButtons?.buttonBorderRadius || "8px",
                            fontSize: config.cssButtons?.buttonFontSize || "14px",
                          }}
                          className="px-4 py-2 text-white font-medium transition-opacity hover:opacity-90"
                        >
                          Normal Button
                        </button>
                        <button
                          style={{
                            backgroundColor: config.loginButtonColor || "#3B82F6",
                            borderRadius: config.cssButtons?.buttonBorderRadius || "8px",
                            fontSize: config.cssButtons?.buttonFontSize || "14px",
                            opacity: (config.cssButtons?.buttonDisabledOpacity || 50) / 100,
                          }}
                          className="px-4 py-2 text-white font-medium cursor-not-allowed"
                          disabled
                        >
                          Disabled
                        </button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* CSS Scope Control */}
                <Card>
                  <CardHeader>
                    <CardTitle>CSS Scope Control</CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Control where styles are applied at runtime</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <p className="text-sm font-medium text-gray-700">Apply to Pages:</p>
                      <div className="space-y-2">
                        {[
                          { key: "applyToLandingPage", label: "Landing Page" },
                          { key: "applyToPostLandingPage", label: "Post Landing Page" },
                          { key: "applyToThankYouPage", label: "Thank You Page" },
                        ].map((item) => (
                          <label key={item.key} className="flex items-center space-x-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={config.cssScopeControl?.[item.key as keyof typeof config.cssScopeControl] !== false}
                              onChange={(e) => setConfig(prev => ({
                                ...prev,
                                cssScopeControl: { ...prev.cssScopeControl, [item.key]: e.target.checked }
                              }))}
                              className="w-4 h-4 text-qsights-cyan rounded"
                            />
                            <span className="text-sm text-gray-700">{item.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-200 pt-4 space-y-3">
                      <p className="text-sm font-medium text-gray-700">Apply to User Types:</p>
                      <div className="space-y-2">
                        {[
                          { key: "applyToLoggedInParticipants", label: "Logged-in Participants" },
                          { key: "applyToAnonymousUsers", label: "Anonymous Users" },
                        ].map((item) => (
                          <label key={item.key} className="flex items-center space-x-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={config.cssScopeControl?.[item.key as keyof typeof config.cssScopeControl] !== false}
                              onChange={(e) => setConfig(prev => ({
                                ...prev,
                                cssScopeControl: { ...prev.cssScopeControl, [item.key]: e.target.checked }
                              }))}
                              className="w-4 h-4 text-qsights-cyan rounded"
                            />
                            <span className="text-sm text-gray-700">{item.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Global CSS Editor (Advanced) */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Code className="w-4 h-4" />
                      Global CSS Editor (Advanced)
                    </CardTitle>
                    <p className="text-sm text-gray-500 mt-1">Add custom CSS for complete control over appearance</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <p className="text-sm text-yellow-800">
                        <strong>⚠️ Advanced users only.</strong> Improper CSS may affect layout. CSS is scoped only to event pages (no admin UI impact).
                      </p>
                    </div>
                    
                    <div>
                      <Label>Custom CSS Code</Label>
                      <textarea
                        value={config.customCss || ""}
                        onChange={(e) => updateConfig("customCss", e.target.value)}
                        placeholder={`/* Example: Custom styles for event pages */
.login-box {
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.btn-primary:hover {
  transform: translateY(-1px);
}

h1, h2, h3 {
  font-family: 'Your Custom Font', sans-serif;
}`}
                        className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg font-mono text-sm resize-none bg-gray-900 text-green-400"
                        rows={12}
                        style={{ tabSize: 2 }}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </div>
      </div>
    </RoleBasedLayout>
  );
}
