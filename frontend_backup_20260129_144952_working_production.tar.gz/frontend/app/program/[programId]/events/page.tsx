"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import AppLayout from "@/components/app-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Tooltip } from "@/components/ui/tooltip";
import { GradientStatCard } from "@/components/ui/gradient-stat-card";
import {
  Search,
  Plus,
  Edit,
  Trash2,
  Eye,
  ChevronLeft,
  ChevronRight,
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  Copy,
  Download,
  BarChart3,
  Users,
  Calendar,
  TrendingUp,
  Mail,
  Palette,
  Link2,
  UserPlus,
  ExternalLink,
  Bell,
  BellRing,
  X,
  QrCode,
  ChevronDown,
  FileSpreadsheet,
} from "lucide-react";
import { activitiesApi, type Activity, fetchWithAuth } from "@/lib/api";
import DeleteConfirmationModal from "@/components/delete-confirmation-modal";
import DuplicateConfirmationModal from "@/components/duplicate-confirmation-modal";
import { toast } from "@/components/ui/toast";
import { QRCodeModal } from "@/components/ui/qr-code-modal";

export default function ActivitiesPage({ params }: { params: { programId: string } }) {
  const router = useRouter();
  const programId = params.programId;
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [selectedTab, setSelectedTab] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<{ role?: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; activityId: string | null; activityName: string | null }>({ isOpen: false, activityId: null, activityName: null });
  const [duplicateModal, setDuplicateModal] = useState<{ isOpen: boolean; activityId: string | null; activityName: string | null }>({ isOpen: false, activityId: null, activityName: null });
  const [linksDropdown, setLinksDropdown] = useState<{ activityId: string | null; links: any | null; loading: boolean }>({ activityId: null, links: null, loading: false });
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [qrModal, setQrModal] = useState<{ isOpen: boolean; url: string; title: string; subtitle: string; color: string }>({ isOpen: false, url: '', title: '', subtitle: '', color: 'blue' });
  const [showExportMenu, setShowExportMenu] = useState(false);

  useEffect(() => {
    loadActivities();
    loadCurrentUser();

    // Listen for global search events
    const handleGlobalSearch = (e: CustomEvent) => {
      if (e.detail.pathname === '/activities') {
        setSearchQuery(e.detail.query);
        setCurrentPage(1);
      }
    };

    const handleGlobalSearchClear = () => {
      setSearchQuery("");
      setCurrentPage(1);
    };

    // Close dropdowns when clicking outside
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.links-dropdown-container')) {
        setLinksDropdown({ activityId: null, links: null, loading: false });
      }
      if (!target.closest('.export-dropdown')) {
        setShowExportMenu(false);
      }
    };

    window.addEventListener('global-search' as any, handleGlobalSearch);
    window.addEventListener('global-search-clear' as any, handleGlobalSearchClear);
    document.addEventListener('click', handleClickOutside);

    return () => {
      window.removeEventListener('global-search' as any, handleGlobalSearch);
      window.removeEventListener('global-search-clear' as any, handleGlobalSearchClear);
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  async function loadCurrentUser() {
    try {
      const response = await fetch('/api/auth/me');
      if (response.ok) {
        const userData = await response.json();
        setCurrentUser(userData.user);
      }
    } catch (error) {
      console.error('Failed to load user:', error);
    }
  }

  async function loadActivities() {
    try {
      setLoading(true);
      setError(null);
      // CRITICAL: Filter activities by programId to prevent showing other programs' data
      const data = await activitiesApi.getAll({ program_id: programId });
      console.log('[ACTIVITIES] Raw API response for program', programId, ':', data);
      console.log('[ACTIVITIES] First activity counts:', data[0] ? {
        id: data[0].id,
        name: data[0].name,
        responses_count: data[0].responses_count,
        authenticated_responses_count: data[0].authenticated_responses_count,
        guest_responses_count: data[0].guest_responses_count,
        participants_count: data[0].participants_count
      } : 'No activities');
      // Sort by updated_at or created_at descending (newest first)
      const sortedData = [...data].sort((a, b) => {
        const dateA = new Date(a.updated_at || a.created_at || 0).getTime();
        const dateB = new Date(b.updated_at || b.created_at || 0).getTime();
        return dateB - dateA;
      });
      setActivities(sortedData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load activities');
      console.error('Error loading activities:', err);
    } finally {
      setLoading(false);
    }
  }

  const handleViewResults = (activityId: string) => {
    router.push(`/activities/${activityId}/results`);
  };

  const handlePreview = (activityId: string) => {
    router.push(`/activities/${activityId}/preview`);
  };

  const handleEdit = (activityId: string) => {
    router.push(`/activities/${activityId}/edit`);
  };

  const handleDuplicate = (activityId: string, activityName: string) => {
    setDuplicateModal({ isOpen: true, activityId, activityName });
  };

  const confirmDuplicate = async () => {
    if (!duplicateModal.activityId) return;
    
    try {
      const activity = activities.find(a => a.id === duplicateModal.activityId);
      if (!activity) return;
      
      const duplicatePayload = {
        name: `${activity.name} (Copy)`,
        description: activity.description,
        type: activity.type,
        status: 'draft' as const,
        program_id: activity.program_id,
        organization_id: activity.organization_id,
        questionnaire_id: activity.questionnaire_id,
        start_date: activity.start_date,
        end_date: activity.end_date,
      };
      
      await activitiesApi.create(duplicatePayload);
      await loadActivities();
      toast({ title: "Success!", description: "Activity duplicated successfully!", variant: "success" });
    } catch (err) {
      console.error('Failed to duplicate activity:', err);
      toast({ title: "Error", description: 'Failed to duplicate activity: ' + (err instanceof Error ? err.message : 'Unknown error'), variant: "error" });
    }
  };

  const handleSendNotification = (activityId: string) => {
    router.push(`/activities/${activityId}/notifications`);
  };

  const handleLandingConfig = (activityId: string) => {
    router.push(`/activities/${activityId}/landing-config`);
  };

  const handleDelete = (activityId: string, activityName: string) => {
    setDeleteModal({ isOpen: true, activityId, activityName });
  };

  const confirmDelete = async () => {
    if (!deleteModal.activityId) return;
    
    try {
      await activitiesApi.delete(deleteModal.activityId);
      await loadActivities();
      toast({ title: "Success!", description: "Activity deleted successfully!", variant: "success" });
    } catch (err) {
      console.error('Failed to delete activity:', err);
      toast({ title: "Error", description: "Failed to delete activity", variant: "error" });
    }
  };

  const handleShowLinks = async (activityId: string) => {
    if (linksDropdown.activityId === activityId) {
      setLinksDropdown({ activityId: null, links: null, loading: false });
      return;
    }
    
    setLinksDropdown({ activityId, links: null, loading: true });
    try {
      const data = await activitiesApi.getActivityLinks(activityId);
      setLinksDropdown({ activityId, links: data.links, loading: false });
    } catch (err) {
      console.error('Failed to fetch links:', err);
      toast({ title: "Error", description: "Failed to fetch activity links", variant: "error" });
      setLinksDropdown({ activityId: null, links: null, loading: false });
    }
  };

  const copyToClipboard = async (url: string, linkType: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedLink(linkType);
      toast({ title: "Copied!", description: `${linkType} copied to clipboard`, variant: "success" });
      setTimeout(() => setCopiedLink(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
      toast({ title: "Error", description: "Failed to copy link", variant: "error" });
    }
  };

  // Export to Excel/CSV
  const exportToExcel = async (format: 'xlsx' | 'csv') => {
    try {
      const XLSX = await import('xlsx');
      
      const data = displayActivities.map((a) => ({
        'Title': a.title,
        'Code': a.code,
        'Type': a.type,
        'Program': a.program,
        'Participants': a.participants,
        'Responses': a.responses,
        'Progress': `${a.progress}%`,
        'Status': a.status,
        'Languages': a.languages.join('; '),
        'Start Date': a.startDate,
        'End Date': a.endDate,
      }));

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Events Report");

      if (format === 'xlsx') {
        XLSX.writeFile(wb, `events-report-${new Date().toISOString().split('T')[0]}.xlsx`);
      } else {
        XLSX.writeFile(wb, `events-report-${new Date().toISOString().split('T')[0]}.csv`);
      }
      
      setShowExportMenu(false);
      toast({ title: "Success", description: `Report exported as ${format.toUpperCase()}`, variant: "success" });
    } catch (err) {
      console.error('Export failed:', err);
      toast({ title: "Error", description: "Failed to export report", variant: "error" });
    }
  };

  // Export to PDF (Updated: 2026-01-29)
  const exportToPDF = async () => {
    try {
      // Dynamically import jspdf and jspdf-autotable (client-side only)
      const jsPDF = (await import('jspdf')).default;
      // Import autotable plugin - this import extends jsPDF prototype
      await import('jspdf-autotable');
      
      const doc = new jsPDF();

      // Header
      doc.setFontSize(20);
      doc.setTextColor(59, 130, 246);
      doc.text('Events Report', 14, 20);
      
      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 28);

      // Summary statistics
      doc.setFontSize(14);
      doc.setTextColor(40, 40, 40);
      doc.text('Summary Statistics', 14, 40);

      const summaryData = [
        ['Total Events', totalActivities.toString()],
        ['Active', activeActivities.toString()],
        ['Scheduled', scheduledActivities.toString()],
        ['Completed', completedActivities.toString()],
      ];

      // @ts-ignore - autoTable extends jsPDF prototype
      doc.autoTable({
        startY: 45,
        head: [['Metric', 'Value']],
        body: summaryData,
        theme: 'grid',
        headStyles: { fillColor: [59, 130, 246] },
      });

      // Event details
      doc.addPage();
      doc.setFontSize(14);
      doc.text('Event Details', 14, 20);

      const tableData = displayActivities.map((a, idx) => [
        (idx + 1).toString(),
        a.title,
        a.type,
        a.participants.toString(),
        a.responses.toString(),
        `${a.progress}%`,
        a.status,
      ]);

      // @ts-ignore - autoTable extends jsPDF prototype
      doc.autoTable({
        startY: 25,
        head: [['#', 'Title', 'Type', 'Participants', 'Responses', 'Progress', 'Status']],
        body: tableData,
        theme: 'striped',
        headStyles: { fillColor: [59, 130, 246] },
        styles: { fontSize: 8 },
      });

      doc.save(`events-report-${new Date().toISOString().split('T')[0]}.pdf`);
      
      setShowExportMenu(false);
      toast({ title: "Success", description: "Report exported as PDF", variant: "success" });
    } catch (err) {
      console.error('PDF export failed:', err);
      toast({ title: "Error", description: "Failed to export PDF", variant: "error" });
    }
  };

  const handleToggleStatus = async (activityId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'live' ? 'closed' : 'live';
    const action = newStatus === 'live' ? 'activate' : 'close';
    
    if (!confirm(`Are you sure you want to ${action} this activity?`)) {
      return;
    }
    
    try {
      await activitiesApi.updateStatus(activityId, newStatus);
      await loadActivities();
      toast({ title: "Success!", description: `Activity ${action}d successfully!`, variant: "success" });
    } catch (err) {
      console.error(`Failed to ${action} activity:`, err);
      toast({ title: "Error", description: `Failed to ${action} activity`, variant: "error" });
    }
  };

  const toggleParticipantReminders = async (activityId: string, currentValue: boolean) => {
    try {
      console.log('[TOGGLE] START - activityId:', activityId, 'currentValue:', currentValue);
      
      // Optimistically update the local state immediately
      setActivities(prevActivities => {
        console.log('[TOGGLE] Before map - activities count:', prevActivities.length);
        const updated = prevActivities.map(activity => {
          const isMatch = activity.id.toString() === activityId;
          if (isMatch) {
            console.log('[TOGGLE] FOUND MATCH!');
            console.log('[TOGGLE] - activity.id:', activity.id);
            console.log('[TOGGLE] - current allow_participant_reminders:', activity.allow_participant_reminders);
            console.log('[TOGGLE] - will change to:', !currentValue);
            return { ...activity, allow_participant_reminders: !currentValue };
          }
          return activity;
        });
        console.log('[TOGGLE] After map - checking updated activity...');
        const updatedActivity = updated.find(a => a.id.toString() === activityId);
        console.log('[TOGGLE] Updated activity allow_participant_reminders:', updatedActivity?.allow_participant_reminders);
        return updated;
      });

      // Update on server
      await fetchWithAuth(`/activities/${activityId}/toggle-reminders`, {
        method: 'PATCH',
        body: JSON.stringify({ allow_participant_reminders: !currentValue })
      });

      console.log('[TOGGLE] Server update successful');

      toast({ 
        title: "Success!", 
        description: `Participant reminders ${!currentValue ? 'enabled' : 'disabled'}`, 
        variant: "success" 
      });
    } catch (err) {
      console.error('Failed to toggle reminders:', err);
      // Revert the optimistic update on error
      setActivities(prevActivities => 
        prevActivities.map(activity => 
          activity.id.toString() === activityId 
            ? { ...activity, allow_participant_reminders: currentValue }
            : activity
        )
      );
      toast({ title: "Error", description: "Failed to toggle reminders", variant: "error" });
    }
  };

  const activities_display = activities.map(a => {
    const participants = a.participants_count || 0;
    const authenticatedParticipants = a.authenticated_participants_count || 0;
    const guestParticipants = a.guest_participants_count || 0;
    const responses = a.responses_count || 0;
    const authenticatedResponses = a.authenticated_responses_count || 0;
    const guestResponses = a.guest_responses_count || 0;
    const participantsResponded = a.participants_responded_count || 0;
    // Progress = (participants who responded / total participants) * 100, capped at 100%
    const rawProgress = participants > 0 ? Math.round((participantsResponded / participants) * 100) : 0;
    const progress = Math.min(rawProgress, 100);
    
    return {
      id: a.id,
      title: a.name || "",
      code: a.id ? String(a.id).substring(0, 8) : "",
      type: a.type || "",
      program: a.program?.name || "N/A",
      programId: a.program_id || null,
      questionnaires: a.questionnaire_id ? 1 : 0,
      participants,
      authenticatedParticipants,
      guestParticipants,
      responses,
      authenticatedResponses,
      guestResponses,
      status: a.status || "",
      startDate: a.start_date ? new Date(a.start_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : "N/A",
      endDate: a.end_date ? new Date(a.end_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : "N/A",
      progress,
      languages: a.languages && a.languages.length > 0 ? a.languages : ["EN"],
      allowGuests: a.allow_guests || false,
      allow_participant_reminders: a.allow_participant_reminders || false,
    };
  });

  const totalActivities = activities.length;
  const activeActivities = activities.filter(a => a.status === 'live').length;
  const scheduledActivities = activities.filter(a => a.status === 'upcoming').length;
  const completedActivities = activities.filter(a => a.status === 'closed' || a.status === 'archived').length;

  // Calculate participant counts across all activities
  const totalEventParticipants = activities.reduce((sum, a) => sum + (a.responses_count || 0), 0);
  const authenticatedEventParticipants = activities.reduce((sum, a) => sum + (a.authenticated_responses_count || 0), 0);
  const anonymousEventParticipants = activities.reduce((sum, a) => sum + (a.guest_responses_count || 0), 0);

  const stats = [
    {
      title: "Total Events",
      value: totalActivities.toString(),
      subtitle: `${activeActivities} active`,
      icon: FileText,
      variant: 'blue' as const,
    },
    {
      title: "Active",
      value: activeActivities.toString(),
      subtitle: totalActivities > 0 ? `${Math.round((activeActivities/totalActivities)*100)}% of total` : "0% of total",
      icon: CheckCircle,
      variant: 'green' as const,
    },
    {
      title: "Total Responses",
      value: `${totalEventParticipants} (${authenticatedEventParticipants}/${anonymousEventParticipants})`,
      subtitle: "(Participant/Anonymous)",
      icon: Users,
      variant: 'yellow' as const,
    },
    {
      title: "Completed",
      value: completedActivities.toString(),
      subtitle: totalActivities > 0 ? `${Math.round((completedActivities/totalActivities)*100)}% completion` : "0% completion",
      icon: TrendingUp,
      variant: 'purple' as const,
    },
  ];

  // Mock data removed - using only real API data

  const tabs = [
    { id: "all", label: "All Events", count: activities.length },
    { id: "survey", label: "Surveys", count: activities.filter(a => a.type === 'survey').length },
    { id: "poll", label: "Polls", count: activities.filter(a => a.type === 'poll').length },
    { id: "assessment", label: "Assessments", count: activities.filter(a => a.type === 'assessment').length },
  ];

  const displayActivities = activities_display;

  const filteredActivities = displayActivities.filter((activity) => {
    const matchesTab =
      selectedTab === "all" ||
      activity.type.toLowerCase() === selectedTab;
    const matchesStatus =
      selectedStatus === "all" || activity.status === selectedStatus;
    const matchesSearch =
      searchQuery === "" ||
      activity.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.program.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesStatus && matchesSearch;
  });

  const totalPages = Math.ceil(filteredActivities.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentActivities = filteredActivities.slice(startIndex, endIndex);

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-qsights-blue mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading events...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (error) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <XCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <p className="text-red-600 font-semibold">{error}</p>
            <button 
              onClick={loadActivities}
              className="mt-4 px-4 py-2 bg-qsights-cyan text-white rounded-lg hover:bg-blue-700"
            >
              Retry
            </button>
          </div>
        </div>
      </AppLayout>
    );
  }

  const getStatusChip = (status: string) => {
    switch (status) {
      case "live":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-green-50 text-green-700 text-xs font-medium rounded-full">
            <CheckCircle className="w-3 h-3" />
            Live
          </span>
        );
      case "upcoming":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-yellow-50 text-yellow-700 text-xs font-medium rounded-full">
            <Clock className="w-3 h-3" />
            Upcoming
          </span>
        );
      case "expired":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-orange-50 text-orange-700 text-xs font-medium rounded-full">
            <XCircle className="w-3 h-3" />
            Expired
          </span>
        );
      case "closed":
      case "archived":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-qsights-light text-purple-700 text-xs font-medium rounded-full">
            <CheckCircle className="w-3 h-3" />
            Closed
          </span>
        );
      case "draft":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-gray-50 text-gray-700 text-xs font-medium rounded-full">
            <FileText className="w-3 h-3" />
            Draft
          </span>
        );
      case "paused":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-orange-50 text-orange-700 text-xs font-medium rounded-full">
            <XCircle className="w-3 h-3" />
            Paused
          </span>
        );
      default:
        return null;
    }
  };

  const getTypeBadge = (type: string) => {
    const colors: { [key: string]: string } = {
      Survey: "bg-blue-100 text-blue-700",
      Poll: "bg-green-100 text-green-700",
      Assessment: "bg-cyan-50 text-purple-700",
    };

    return (
      <span
        className={`px-2.5 py-1 ${
          colors[type] || "bg-gray-100 text-gray-700"
        } text-xs font-medium rounded-full`}
      >
        {type}
      </span>
    );
  };

  const getLanguageBadge = (lang: string) => {
    const colors: { [key: string]: string } = {
      EN: "bg-blue-100 text-blue-700",
      ES: "bg-red-100 text-red-700",
      FR: "bg-cyan-50 text-purple-700",
      DE: "bg-yellow-100 text-yellow-700",
      IT: "bg-green-100 text-green-700",
      PT: "bg-orange-100 text-orange-700",
      ZH: "bg-pink-100 text-pink-700",
      JA: "bg-cyan-50 text-indigo-700",
    };

    return (
      <span
        key={lang}
        className={`px-2 py-0.5 ${
          colors[lang] || "bg-gray-100 text-gray-700"
        } text-xs font-medium rounded`}
      >
        {lang}
      </span>
    );
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return "bg-green-500";
    if (progress >= 50) return "bg-blue-500";
    if (progress >= 25) return "bg-yellow-500";
    return "bg-orange-500";
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Events</h1>
            <p className="text-sm text-gray-500 mt-1">
              Manage surveys, polls, and assessments
            </p>
          </div>
          <div className="flex items-center gap-2">
            {/* Export Dropdown */}
            <div className="relative export-dropdown">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Export
                <ChevronDown className="w-4 h-4" />
              </button>

              {showExportMenu && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                  <div className="py-2">
                    <button
                      onClick={() => exportToExcel('xlsx')}
                      className="w-full px-4 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3"
                    >
                      <FileSpreadsheet className="w-4 h-4 text-green-600" />
                      <div>
                        <div className="font-medium">Export as Excel</div>
                        <div className="text-xs text-gray-500">Download .xlsx file</div>
                      </div>
                    </button>
                    
                    <button
                      onClick={() => exportToExcel('csv')}
                      className="w-full px-4 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3"
                    >
                      <FileText className="w-4 h-4 text-blue-600" />
                      <div>
                        <div className="font-medium">Export as CSV</div>
                        <div className="text-xs text-gray-500">Download .csv file</div>
                      </div>
                    </button>
                    
                    <div className="border-t border-gray-100 my-1"></div>
                    
                    <button
                      onClick={exportToPDF}
                      className="w-full px-4 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3"
                    >
                      <FileText className="w-4 h-4 text-red-600" />
                      <div>
                        <div className="font-medium">Export as PDF</div>
                        <div className="text-xs text-gray-500">Download .pdf file</div>
                      </div>
                    </button>
                  </div>
                </div>
              )}
            </div>
            {currentUser?.role !== 'program-moderator' && (
              <a
                href="/activities/create"
                className="flex items-center gap-2 px-4 py-2 bg-qsights-cyan text-white rounded-lg text-sm font-medium hover:bg-qsights-cyan/90 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Create Event
              </a>
            )}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <GradientStatCard
              key={index}
              title={stat.title}
              value={stat.value}
              subtitle={stat.subtitle}
              icon={stat.icon}
              variant={stat.variant}
            />
          ))}
        </div>

        {/* Tabs */}
        <Card>
          <CardContent className="p-0">
            <div className="border-b border-gray-200">
              <div className="flex items-center overflow-x-auto">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setSelectedTab(tab.id)}
                    className={`px-6 py-4 font-medium text-sm border-b-2 transition-colors whitespace-nowrap ${
                      selectedTab === tab.id
                        ? "border-qsights-blue text-qsights-blue"
                        : "border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300"
                    }`}
                  >
                    {tab.label}
                    <span
                      className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                        selectedTab === tab.id
                          ? "bg-blue-100 text-blue-700"
                          : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {tab.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Filters and Search */}
            <div className="p-6 border-b border-gray-200">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                {/* Search */}
                <div className="relative flex-1 w-full sm:max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search events..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-qsights-blue focus:border-transparent"
                  />
                </div>

                {/* Status Filter */}
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-qsights-blue focus:border-transparent"
                  >
                    <option value="all">All Status</option>
                    <option value="active">Active</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="completed">Completed</option>
                    <option value="draft">Draft</option>
                    <option value="paused">Paused</option>
                  </select>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Activities Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Event
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Program
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Participants
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Responses
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Timeline
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {currentActivities.map((activity) => (
                    <tr
                      key={activity.id}
                      className="hover:bg-gray-50 transition-colors"
                    >
                      {/* Activity */}
                      <td className="px-6 py-4">
                        <div>
                          <p className="text-sm font-semibold text-gray-900">
                            {activity.title}
                          </p>
                          <p className="text-xs text-gray-500 font-mono mt-0.5">
                            {activity.code}
                          </p>
                          <div className="flex items-center gap-1 mt-1 flex-wrap">
                            {activity.languages.map((lang) =>
                              getLanguageBadge(lang)
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Type */}
                      <td className="px-6 py-4">
                        {getTypeBadge(activity.type)}
                      </td>

                      {/* Program */}
                      <td className="px-6 py-4">
                        <p className="text-sm text-gray-900 max-w-xs truncate">
                          {activity.program}
                        </p>
                        <p className="text-xs text-gray-500 mt-0.5">
                          {activity.questionnaires}{" "}
                          {activity.questionnaires === 1
                            ? "questionnaire"
                            : "questionnaires"}
                        </p>
                      </td>

                      {/* Participants */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-gray-400" />
                          <Tooltip
                            content={
                              <div className="text-xs">
                                <div>Authenticated: {activity.authenticatedParticipants.toLocaleString()}</div>
                                <div>Anonymous: {activity.guestParticipants.toLocaleString()}</div>
                              </div>
                            }
                          >
                            <span className="text-sm font-medium text-gray-900 cursor-help">
                              {activity.participants.toLocaleString()}
                            </span>
                          </Tooltip>
                        </div>
                      </td>

                      {/* Responses */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <BarChart3 className="w-4 h-4 text-gray-400" />
                          <Tooltip
                            content={
                              <div className="text-xs">
                                <div>Authenticated: {activity.authenticatedResponses.toLocaleString()}</div>
                                <div>Anonymous: {activity.guestResponses.toLocaleString()}</div>
                              </div>
                            }
                          >
                            <span className="text-sm font-medium text-gray-900 cursor-help">
                              {activity.responses.toLocaleString()}
                            </span>
                          </Tooltip>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="px-6 py-4">
                        {getStatusChip(activity.status)}
                      </td>

                      {/* Timeline */}
                      <td className="px-6 py-4">
                        <div className="flex items-start gap-1 text-xs text-gray-600">
                          <Calendar className="w-3 h-3 text-gray-400 mt-0.5" />
                          <div>
                            <p>{activity.startDate}</p>
                            <p className="text-gray-400">to</p>
                            <p>{activity.endDate}</p>
                          </div>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          {/* Links Dropdown */}
                          <div className="relative links-dropdown-container">
                            <button
                              onClick={(e) => { 
                                e.stopPropagation(); 
                                if (activity.status !== 'draft') {
                                  handleShowLinks(activity.id.toString()); 
                                }
                              }}
                              className={`p-1.5 rounded transition-colors ${
                                activity.status === 'draft' 
                                  ? 'text-gray-300 cursor-not-allowed' 
                                  : linksDropdown.activityId === activity.id.toString() 
                                    ? 'bg-green-100 text-green-600' 
                                    : 'text-green-600 hover:bg-green-50'
                              }`}
                              title={activity.status === 'draft' ? 'Get Links (Not available for draft events)' : 'Get Links'}
                              disabled={activity.status === 'draft'}
                            >
                              <Link2 className="w-4 h-4" />
                            </button>
                            {linksDropdown.activityId === activity.id.toString() && (
                              <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[99999]" onClick={(e) => { e.stopPropagation(); setLinksDropdown({ activityId: null, links: null, loading: false }); }}>
                                <div className="bg-white rounded-xl shadow-2xl w-[420px] max-w-[90vw] links-dropdown-container" onClick={(e) => e.stopPropagation()}>
                                  <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <Link2 className="w-5 h-5 text-qsights-blue" />
                                      <p className="text-base font-semibold text-gray-900">Copy Event Links</p>
                                    </div>
                                    <button onClick={() => setLinksDropdown({ activityId: null, links: null, loading: false })} className="p-1 hover:bg-gray-100 rounded-full transition-colors">
                                      <XCircle className="w-5 h-5 text-gray-400" />
                                    </button>
                                  </div>
                                {linksDropdown.loading ? (
                                  <div className="p-8 text-center">
                                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-qsights-blue mx-auto"></div>
                                    <p className="mt-2 text-sm text-gray-500">Loading links...</p>
                                  </div>
                                ) : linksDropdown.links ? (
                                  <div className="p-4 space-y-3">
                                    {/* Registration Link */}
                                    <div className="border border-gray-200 rounded-lg p-3 hover:border-blue-300 hover:bg-blue-50/50 transition-all">
                                      <div className="flex items-start gap-3">
                                        <div className="p-2 bg-blue-100 rounded-lg">
                                          <UserPlus className="w-5 h-5 text-blue-600" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                          <p className="text-sm font-semibold text-gray-900">Registration Link</p>
                                          <p className="text-xs text-gray-500 mt-0.5">Participants must register before taking survey</p>
                                          <div className="mt-2 flex items-center gap-2">
                                            <input 
                                              type="text" 
                                              readOnly 
                                              value={linksDropdown.links.registration.url} 
                                              className="flex-1 text-xs bg-gray-50 border border-gray-200 rounded px-2 py-1.5 text-gray-600 truncate"
                                            />
                                            <button
                                              onClick={() => setQrModal({ isOpen: true, url: linksDropdown.links.registration.url, title: 'Registration QR', subtitle: 'Scan to register & take survey', color: 'blue' })}
                                              className="p-1.5 rounded text-blue-600 hover:bg-blue-100 transition-colors"
                                              title="View QR Code"
                                            >
                                              <QrCode className="w-4 h-4" />
                                            </button>
                                            <button
                                              onClick={() => copyToClipboard(linksDropdown.links.registration.url, 'Registration Link')}
                                              className={`px-3 py-1.5 rounded text-xs font-medium transition-all flex items-center gap-1 ${
                                                copiedLink === 'Registration Link' 
                                                  ? 'bg-green-500 text-white' 
                                                  : 'bg-blue-600 text-white hover:bg-blue-700'
                                              }`}
                                            >
                                              {copiedLink === 'Registration Link' ? (
                                                <><CheckCircle className="w-3.5 h-3.5" /> Copied!</>
                                              ) : (
                                                <><Copy className="w-3.5 h-3.5" /> Copy</>
                                              )}
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    {/* Preview Link */}
                                    <div className="border border-gray-200 rounded-lg p-3 hover:border-purple-300 hover:bg-qsights-light/50 transition-all">
                                      <div className="flex items-start gap-3">
                                        <div className="p-2 bg-cyan-50 rounded-lg">
                                          <Eye className="w-5 h-5 text-qsights-cyan" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                          <p className="text-sm font-semibold text-gray-900">Preview Link</p>
                                          <p className="text-xs text-gray-500 mt-0.5">For testing only - responses not saved</p>
                                          <div className="mt-2 flex items-center gap-2">
                                            <input 
                                              type="text" 
                                              readOnly 
                                              value={linksDropdown.links.preview.url} 
                                              className="flex-1 text-xs bg-gray-50 border border-gray-200 rounded px-2 py-1.5 text-gray-600 truncate"
                                            />
                                            <button
                                              onClick={() => setQrModal({ isOpen: true, url: linksDropdown.links.preview.url, title: 'Preview QR', subtitle: 'For testing only - responses not saved', color: 'purple' })}
                                              className="p-1.5 rounded text-qsights-cyan hover:bg-cyan-50 transition-colors"
                                              title="View QR Code"
                                            >
                                              <QrCode className="w-4 h-4" />
                                            </button>
                                            <button
                                              onClick={() => copyToClipboard(linksDropdown.links.preview.url, 'Preview Link')}
                                              className={`px-3 py-1.5 rounded text-xs font-medium transition-all flex items-center gap-1 ${
                                                copiedLink === 'Preview Link' 
                                                  ? 'bg-green-500 text-white' 
                                                  : 'bg-qsights-dark text-white hover:bg-qsights-dark/90'
                                              }`}
                                            >
                                              {copiedLink === 'Preview Link' ? (
                                                <><CheckCircle className="w-3.5 h-3.5" /> Copied!</>
                                              ) : (
                                                <><Copy className="w-3.5 h-3.5" /> Copy</>
                                              )}
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    {/* Anonymous Link - Only show if Allow Anonymous Access is enabled */}
                                    {activity.allowGuests && (
                                      <div className="border border-gray-200 rounded-lg p-3 hover:border-orange-300 hover:bg-orange-50/50 transition-all">
                                        <div className="flex items-start gap-3">
                                          <div className="p-2 bg-orange-100 rounded-lg">
                                            <Users className="w-5 h-5 text-orange-600" />
                                          </div>
                                          <div className="flex-1 min-w-0">
                                            <p className="text-sm font-semibold text-gray-900">Anonymous Link</p>
                                            <p className="text-xs text-gray-500 mt-0.5">No registration required - anonymous responses</p>
                                            <div className="mt-2 flex items-center gap-2">
                                              <input 
                                                type="text" 
                                                readOnly 
                                                value={linksDropdown.links.anonymous.url} 
                                                className="flex-1 text-xs bg-gray-50 border border-gray-200 rounded px-2 py-1.5 text-gray-600 truncate"
                                              />
                                              <button
                                                onClick={() => setQrModal({ isOpen: true, url: linksDropdown.links.anonymous.url, title: 'Anonymous QR', subtitle: 'No registration required', color: 'orange' })}
                                                className="p-1.5 rounded text-orange-600 hover:bg-orange-100 transition-colors"
                                                title="View QR Code"
                                              >
                                                <QrCode className="w-4 h-4" />
                                              </button>
                                              <button
                                                onClick={() => copyToClipboard(linksDropdown.links.anonymous.url, 'Anonymous Link')}
                                                className={`px-3 py-1.5 rounded text-xs font-medium transition-all flex items-center gap-1 ${
                                                  copiedLink === 'Anonymous Link' 
                                                    ? 'bg-green-500 text-white' 
                                                    : 'bg-orange-600 text-white hover:bg-orange-700'
                                                }`}
                                              >
                                                {copiedLink === 'Anonymous Link' ? (
                                                  <><CheckCircle className="w-3.5 h-3.5" /> Copied!</>
                                                ) : (
                                                  <><Copy className="w-3.5 h-3.5" /> Copy</>
                                                )}
                                              </button>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                ) : (
                                  <div className="p-8 text-center">
                                    <XCircle className="w-8 h-8 text-red-400 mx-auto" />
                                    <p className="mt-2 text-sm text-red-500">Failed to load links</p>
                                  </div>
                                )}
                                </div>
                              </div>
                            )}
                          </div>
                          {currentUser?.role !== 'program-moderator' && (
                            <>
                              <button
                                onClick={(e) => { 
                                  e.stopPropagation();
                                  console.log('[BTN CLICK] activity.id:', activity.id, 'allow_participant_reminders:', activity.allow_participant_reminders);
                                  toggleParticipantReminders(activity.id.toString(), activity.allow_participant_reminders || false); 
                                }}
                                className={`p-1.5 rounded transition-colors ${
                                  activity.allow_participant_reminders
                                    ? 'bg-cyan-50 text-qsights-cyan' 
                                    : 'text-gray-400 hover:bg-gray-100'
                                }`}
                                title={activity.allow_participant_reminders ? 'Participant Reminders Enabled' : 'Participant Reminders Disabled'}
                              >
                                {(() => {
                                  const icon = activity.allow_participant_reminders ? <BellRing className="w-4 h-4" /> : <Bell className="w-4 h-4" />;
                                  console.log('[BTN RENDER] activity.id:', activity.id, 'allow_participant_reminders:', activity.allow_participant_reminders, 'showing:', activity.allow_participant_reminders ? 'BellRing' : 'Bell');
                                  return icon;
                                })()}
                              </button>
                              <button
                                onClick={() => handleSendNotification(activity.id.toString())}
                                className="p-1.5 text-qsights-cyan hover:bg-qsights-light rounded transition-colors"
                                title="Send Notification"
                              >
                                <Mail className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => handleViewResults(activity.id.toString())}
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            title="View Results"
                          >
                            <BarChart3 className="w-4 h-4" />
                          </button>
                          {currentUser?.role !== 'program-moderator' && (
                            <>
                              <button
                                onClick={() => handleLandingConfig(activity.id.toString())}
                                className="p-1.5 text-pink-600 hover:bg-pink-50 rounded transition-colors"
                                title="Landing Page Configuration"
                              >
                                <Palette className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleEdit(activity.id.toString())}
                                className="p-1.5 text-gray-600 hover:bg-gray-100 rounded transition-colors"
                                title="Edit"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDuplicate(activity.id.toString(), activity.title)}
                                className="p-1.5 text-gray-600 hover:bg-gray-100 rounded transition-colors"
                                title="Duplicate"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDelete(activity.id.toString(), activity.title)}
                                className="p-1.5 text-red-600 hover:bg-red-50 rounded transition-colors"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Showing{" "}
                <span className="font-medium text-gray-900">
                  {(currentPage - 1) * itemsPerPage + 1}
                </span>{" "}
                to{" "}
                <span className="font-medium text-gray-900">
                  {Math.min(currentPage * itemsPerPage, filteredActivities.length)}
                </span>{" "}
                of{" "}
                <span className="font-medium text-gray-900">
                  {filteredActivities.length}
                </span>{" "}
                results
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="px-4 py-2 text-sm font-medium text-gray-900">
                  {currentPage}
                </span>
                <button
                  onClick={() => setCurrentPage((prev) => prev + 1)}
                  disabled={currentPage * itemsPerPage >= filteredActivities.length}
                  className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <DeleteConfirmationModal
        isOpen={deleteModal.isOpen}
        onClose={() => setDeleteModal({ isOpen: false, activityId: null, activityName: null })}
        onConfirm={confirmDelete}
        title="Delete Event?"
        itemName={deleteModal.activityName || undefined}
        itemType="event"
      />

      <DuplicateConfirmationModal
        isOpen={duplicateModal.isOpen}
        onClose={() => setDuplicateModal({ isOpen: false, activityId: null, activityName: null })}
        onConfirm={confirmDuplicate}
        itemName={duplicateModal.activityName || undefined}
      />

      {/* QR Code Modal */}
      <QRCodeModal
        isOpen={qrModal.isOpen}
        onClose={() => setQrModal({ isOpen: false, url: '', title: '', subtitle: '', color: 'blue' })}
        url={qrModal.url}
        title={qrModal.title}
        subtitle={qrModal.subtitle}
        color={qrModal.color}
      />
    </AppLayout>
  );
}
