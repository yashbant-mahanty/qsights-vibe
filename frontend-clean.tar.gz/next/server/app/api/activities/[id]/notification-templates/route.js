"use strict";(()=>{var t={};t.id=1270,t.ids=[1270],t.modules={20399:t=>{t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:t=>{t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},19280:(t,e,i)=>{i.r(e),i.d(e,{originalPathname:()=>h,patchFetch:()=>f,requestAsyncStorage:()=>m,routeModule:()=>g,serverHooks:()=>x,staticGenerationAsyncStorage:()=>y});var o={};i.r(o),i.d(o,{GET:()=>l,POST:()=>c});var a=i(49303),n=i(88716),r=i(60670),s=i(87070),p=i(57277);let d="https://prod.qsights.com/api";async function l(t,{params:e}){try{let i=e.id;try{let e=await fetch(`${d}/activities/${i}/notification-templates`,{headers:{Authorization:t.headers.get("Authorization")||"",Accept:"application/json"}});if(e.ok){let t=await e.json();return s.NextResponse.json(t)}}catch(t){console.log("Backend not available, using defaults")}let o=Object.keys(p.tc),a=o.map(t=>({id:t,notification_type:t,subject:p.tc[t].subject,body_html:p.tc[t].body_html,body_text:p.tc[t].body_text,is_default:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()}));return s.NextResponse.json({data:a,available_types:o,message:"Using default templates (backend not configured)"})}catch(t){return console.error("Error fetching templates:",t),s.NextResponse.json({error:t instanceof Error?t.message:"Failed to fetch templates",message:"Failed to fetch notification templates"},{status:500})}}async function c(t,{params:e}){try{let i=e.id,o=await t.json(),a=await fetch(`${d}/activities/${i}/notification-templates`,{method:"POST",headers:{Authorization:t.headers.get("Authorization")||"","Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(o)});if(!a.ok){let t=await a.json().catch(()=>({message:"Failed to save template"}));throw Error(t.message||"Failed to save template")}let n=await a.json();return s.NextResponse.json(n)}catch(t){return console.error("Error saving template:",t),s.NextResponse.json({error:t instanceof Error?t.message:"Failed to save template",message:"Failed to save notification template"},{status:500})}}let g=new a.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/activities/[id]/notification-templates/route",pathname:"/api/activities/[id]/notification-templates",filename:"route",bundlePath:"app/api/activities/[id]/notification-templates/route"},resolvedPagePath:"/Users/yash/Documents/Projects/QSightsOrg2.0/frontend/app/api/activities/[id]/notification-templates/route.ts",nextConfigOutput:"",userland:o}),{requestAsyncStorage:m,staticGenerationAsyncStorage:y,serverHooks:x}=g,h="/api/activities/[id]/notification-templates/route";function f(){return(0,r.patchFetch)({serverHooks:x,staticGenerationAsyncStorage:y})}},57277:(t,e,i)=>{i.d(e,{tc:()=>o,wT:()=>a});let o={invitation:{subject:"You're Invited: {{activity_name}}",body_html:`<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 8px 8px 0 0; text-align: center;">
    <h1 style="color: white; margin: 0; font-size: 28px;">🎉 You're Invited!</h1>
  </div>
  <div style="background: #ffffff; padding: 40px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 10px;">Hello <strong>{{participant_name}}</strong>,</p>
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 20px;">You have been invited to participate in: <strong>{{activity_name}}</strong></p>
    <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin-bottom: 30px;">Please click the button below to access the activity:</p>
    <div style="text-align: center; margin: 30px 0;"><a href="{{activity_link}}" style="display: inline-block; padding: 14px 40px; background-color: #6366f1; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">View Activity Details</a></div>
    <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin-top: 30px;">If you have any questions, please don't hesitate to reach out.</p>
    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb;"><p style="font-size: 12px; color: #9ca3af; margin: 0;">This activity is valid until <strong>{{end_date}}</strong>. If you have any questions, please contact the administrator.</p></div>
  </div>
</div>`,body_text:`Hello {{participant_name}},

You have been invited to participate in: {{activity_name}}

Please visit the following link to access the activity:
{{activity_link}}

This activity is valid until {{end_date}}. If you have any questions, please contact the administrator.`},reminder:{subject:"Reminder: {{activity_name}}",body_html:`
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 30px; border-radius: 8px 8px 0 0; text-align: center;">
    <h1 style="color: white; margin: 0; font-size: 28px;">🔔 Reminder</h1>
  </div>
  
  <div style="background: #ffffff; padding: 40px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 10px;">
      Hello <strong>{{participant_name}}</strong>,
    </p>
    
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 20px;">
      This is a friendly reminder to complete: <strong>{{activity_name}}</strong>
    </p>
    
    <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin-bottom: 30px;">
      You haven't completed this activity yet. Please click the button below to continue:
    </p>
    
    <div style="text-align: center; margin: 30px 0;">
      <a href="{{activity_link}}" 
         style="display: inline-block; padding: 14px 40px; background-color: #f59e0b; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">
        Continue Activity
      </a>
    </div>
    
    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
      <p style="font-size: 12px; color: #9ca3af; margin: 0;">
        This activity will close on <strong>{{end_date}}</strong>.
      </p>
    </div>
  </div>
</div>
    `.trim(),body_text:`Hello {{participant_name}},

This is a reminder to complete: {{activity_name}}

You haven't completed this activity yet. Please visit the following link to continue:
{{activity_link}}

This activity will close on {{end_date}}.`},"thank-you":{subject:"Thank You for Participating",body_html:`
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; border-radius: 8px 8px 0 0; text-align: center;">
    <h1 style="color: white; margin: 0; font-size: 28px;">✨ Thank You!</h1>
  </div>
  
  <div style="background: #ffffff; padding: 40px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 10px;">
      Hello <strong>{{participant_name}}</strong>,
    </p>
    
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 20px;">
      Thank you for completing: <strong>{{activity_name}}</strong>
    </p>
    
    <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin-bottom: 30px;">
      We appreciate your time and feedback. Your response has been recorded successfully.
    </p>
    
    <div style="text-align: center; margin: 30px 0;">
      <a href="{{activity_link}}" 
         style="display: inline-block; padding: 14px 40px; background-color: #10b981; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">
        View Activity Details
      </a>
    </div>
    
    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
      <p style="font-size: 12px; color: #9ca3af; margin: 0;">
        If you have any questions about your submission, please contact the administrator.
      </p>
    </div>
  </div>
</div>
    `.trim(),body_text:`Hello {{participant_name}},

Thank you for completing: {{activity_name}}

We appreciate your time and feedback. Your response has been recorded successfully.

View activity details: {{activity_link}}

If you have any questions about your submission, please contact the administrator.`},"program-expiry":{subject:"Program Closing Soon: {{activity_name}}",body_html:`
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 30px; border-radius: 8px 8px 0 0; text-align: center;">
    <h1 style="color: white; margin: 0; font-size: 28px;">⏰ Program Closing Soon</h1>
  </div>
  
  <div style="background: #ffffff; padding: 40px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 10px;">
      Hello <strong>{{participant_name}}</strong>,
    </p>
    
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 20px;">
      The program containing <strong>{{activity_name}}</strong> is closing soon.
    </p>
    
    <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin-bottom: 30px;">
      This is your final reminder to complete any pending activities before the program expires on <strong>{{end_date}}</strong>.
    </p>
    
    <div style="text-align: center; margin: 30px 0;">
      <a href="{{activity_link}}" 
         style="display: inline-block; padding: 14px 40px; background-color: #ef4444; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">
        View Activity
      </a>
    </div>
    
    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
      <p style="font-size: 12px; color: #9ca3af; margin: 0;">
        After this date, you will no longer be able to access this activity.
      </p>
    </div>
  </div>
</div>
    `.trim(),body_text:`Hello {{participant_name}},

The program containing {{activity_name}} is closing soon.

This is your final reminder to complete any pending activities before the program expires on {{end_date}}.

View activity: {{activity_link}}

After this date, you will no longer be able to access this activity.`},"activity-summary":{subject:"Activity Summary: {{activity_name}}",body_html:`
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
  <div style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 30px; border-radius: 8px 8px 0 0; text-align: center;">
    <h1 style="color: white; margin: 0; font-size: 28px;">📊 Activity Summary</h1>
  </div>
  
  <div style="background: #ffffff; padding: 40px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 10px;">
      Hello <strong>{{participant_name}}</strong>,
    </p>
    
    <p style="font-size: 16px; color: #374151; line-height: 1.6; margin-bottom: 20px;">
      Here is a summary of: <strong>{{activity_name}}</strong>
    </p>
    
    <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin-bottom: 30px;">
      The activity has concluded. Click below to view the details:
    </p>
    
    <div style="text-align: center; margin: 30px 0;">
      <a href="{{activity_link}}" 
         style="display: inline-block; padding: 14px 40px; background-color: #8b5cf6; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">
        View Activity Details
      </a>
    </div>
    
    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
      <p style="font-size: 12px; color: #9ca3af; margin: 0;">
        Thank you for your participation.
      </p>
    </div>
  </div>
</div>
    `.trim(),body_text:`Hello {{participant_name}},

Here is a summary of: {{activity_name}}

The activity has concluded.

View activity details: {{activity_link}}

Thank you for your participation.`}};function a(t,e){let i=t;return Object.entries({"{{activity_name}}":e.activity_name||"","{{activity_link}}":e.activity_link||"","{{participant_name}}":e.participant_name||"Participant","{{program_name}}":e.program_name||"","{{organization_name}}":e.organization_name||"","{{end_date}}":e.end_date||"N/A","{{start_date}}":e.start_date||"N/A"}).forEach(([t,e])=>{i=i.replace(RegExp(t,"g"),e)}),i}}};var e=require("../../../../../webpack-runtime.js");e.C(t);var i=t=>e(e.s=t),o=e.X(0,[9276,5972],()=>i(19280));module.exports=o})();