import TemplateWrapper from "@/components/template-wrapper";

export default function Home() {
  return <TemplateWrapper />;
}
